#!/usr/bin/env bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════════════════════
# KURO::VISION — Deployment Script
# Upload via SFTP to /tmp/ then: cd /tmp/kuro-vision && sudo bash deploy.sh
# ═══════════════════════════════════════════════════════════════════════════

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
step() { echo -e "\n${GREEN}[STEP $1]${NC} $2"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
ok()   { echo -e "${GREEN}  ✓${NC} $1"; }
fail() { echo -e "${RED}[FAIL]${NC} $1"; exit 1; }

DEPLOY_DIR="$(cd "$(dirname "$0")" && pwd)"
CORE_DIR="/opt/kuro/core"
VISION_DIR="/opt/kuro/vision"
DATA_DIR="/var/lib/kuro"

echo ""
echo -e "${CYAN}  KURO::VISION — Deployment${NC}"
echo "  ════════════════════════════════════"
echo "  Source:  $DEPLOY_DIR"
echo "  Layers:  $CORE_DIR/layers/"
echo "  Python:  $VISION_DIR/"
echo "  Data:    $DATA_DIR/vision/"
echo ""

# ── Step 1: Preflight ─────────────────────────────────────────────────────
step 1 "Preflight checks"
[[ $EUID -ne 0 ]] && fail "Run as root"
command -v node >/dev/null || fail "Node.js not found"
command -v python3 >/dev/null || fail "Python3 not found"
command -v ollama >/dev/null || fail "Ollama not found"
[[ -d "$CORE_DIR" ]] || fail "$CORE_DIR not found — deploy KURO v6.3 first"
ok "All prerequisites met"

# ── Step 2: Create directories ────────────────────────────────────────────
step 2 "Creating directories"
mkdir -p "$VISION_DIR"
mkdir -p "$DATA_DIR/vision/sessions"
ok "Directories ready"

# ── Step 3: Copy Node.js layer modules ────────────────────────────────────
step 3 "Installing vision layer modules"
cp -v "$DEPLOY_DIR/layers/vision_gpu_mutex.cjs"    "$CORE_DIR/layers/"
cp -v "$DEPLOY_DIR/layers/vision_intent.cjs"       "$CORE_DIR/layers/"
cp -v "$DEPLOY_DIR/layers/vision_scene_graph.cjs"  "$CORE_DIR/layers/"
cp -v "$DEPLOY_DIR/layers/vision_evaluator.cjs"    "$CORE_DIR/layers/"
cp -v "$DEPLOY_DIR/layers/vision_storage.cjs"      "$CORE_DIR/layers/"
cp -v "$DEPLOY_DIR/layers/vision_orchestrator.cjs" "$CORE_DIR/layers/"
cp -v "$DEPLOY_DIR/layers/vision_routes.cjs"       "$CORE_DIR/layers/"
ok "7 layer modules installed"

# ── Step 4: Setup Python environment ──────────────────────────────────────
step 4 "Setting up Python environment"
cp "$DEPLOY_DIR/python/flux_service.py" "$VISION_DIR/"
cp "$DEPLOY_DIR/python/requirements.txt" "$VISION_DIR/"

if [[ ! -d "$VISION_DIR/venv" ]]; then
    python3 -m venv "$VISION_DIR/venv"
    ok "Created venv"
else
    ok "Venv exists"
fi

echo "  Installing Python deps (this may take a while)..."
"$VISION_DIR/venv/bin/pip" install --upgrade pip > /dev/null 2>&1
"$VISION_DIR/venv/bin/pip" install -r "$VISION_DIR/requirements.txt" 2>&1 | tail -5
ok "Python deps installed"

# ── Step 5: Pull kuro-eye model ───────────────────────────────────────────
step 5 "Setting up kuro-eye model"
if ollama list 2>/dev/null | grep -q "kuro-eye"; then
    ok "kuro-eye already exists"
else
    echo "  Pulling qwen2.5vl:7b base..."
    ollama pull qwen2.5vl:7b

    cat > /tmp/kuro-eye.modelfile << 'MFEOF'
FROM qwen2.5vl:7b
PARAMETER temperature 0.1
PARAMETER num_predict 500
PARAMETER num_ctx 4096
SYSTEM "You are KURO::EYE, a vision analysis system. Output structured JSON when asked for scene graphs. For evaluation tasks, answer with PASS or FAIL followed by one sentence reason. Be precise."
MFEOF

    ollama create kuro-eye -f /tmp/kuro-eye.modelfile
    rm /tmp/kuro-eye.modelfile
    ok "kuro-eye model created"
fi

# ── Step 6: Install systemd service ───────────────────────────────────────
step 6 "Installing systemd service"
cp "$DEPLOY_DIR/systemd/kuro-vision.service" /etc/systemd/system/
systemctl daemon-reload
ok "Service installed"

# ── Step 7: Set permissions ───────────────────────────────────────────────
step 7 "Setting permissions"
if id kuro &>/dev/null; then
    chown -R kuro:kuro "$VISION_DIR"
    chown -R kuro:kuro "$DATA_DIR/vision"
    ok "Permissions set for kuro user"
else
    warn "kuro user doesn't exist — running as root"
fi

# ── Step 8: Verification ─────────────────────────────────────────────────
step 8 "Verification"
echo "  Layer modules:"
for f in vision_gpu_mutex vision_intent vision_scene_graph vision_evaluator vision_storage vision_orchestrator vision_routes; do
    if [[ -f "$CORE_DIR/layers/${f}.cjs" ]]; then
        ok "$f.cjs"
    else
        warn "MISSING: $f.cjs"
    fi
done

echo "  Python service:"
if [[ -f "$VISION_DIR/flux_service.py" ]]; then ok "flux_service.py"; fi
if [[ -f "$VISION_DIR/venv/bin/python" ]]; then ok "Python venv"; fi

echo "  Models:"
if ollama list 2>/dev/null | grep -q "kuro-eye"; then ok "kuro-eye"; else warn "kuro-eye not found"; fi

echo ""
echo -e "${CYAN}  ════════════════════════════════════${NC}"
echo -e "${GREEN}  KURO::VISION deployed successfully${NC}"
echo ""
echo "  Architecture: Dual RTX 5090"
echo "    GPU 0: kuro-core (permanent)"
echo "    GPU 1: FLUX + kuro-eye (vision dedicated)"
echo ""
echo "  Next steps:"
echo "  ─────────────────────────────────────────────────"
echo ""
echo "  1. Wire routes into server.cjs — add these lines:"
echo ""
echo "     // Near other requires:"
echo "     const mountVisionRoutes = require('./layers/vision_routes.cjs');"
echo ""
echo "     // After other route definitions:"
echo "     mountVisionRoutes(app, logEvent);"
echo ""
echo "  2. Start FLUX service (first run downloads ~12GB model):"
echo "     systemctl start kuro-vision"
echo "     journalctl -u kuro-vision -f"
echo ""
echo "  3. Restart Node backend:"
echo "     pm2 restart kuro-backend"
echo ""
echo "  4. Test:"
echo "     curl http://localhost:3200/health"
echo "     curl -N -X POST http://localhost:3100/api/vision/status"
echo ""
echo "  5. Generate first image:"
echo '     curl -N -X POST http://localhost:3100/api/vision/generate \'
echo '       -H "Content-Type: application/json" \'
echo '       -d '\''{"prompt":"a futuristic glass OS interface floating in space","profile":"lab"}'\'''
echo ""
echo "  6. Ollama GPU config (if not already set):"
echo "     Ensure kuro-core is pinned to GPU 0 and kuro-eye"
echo "     can load on GPU 1. FLUX is pinned via CUDA_VISIBLE_DEVICES=1"
echo "     in kuro-vision.service."
echo ""
