/**
 * KURO::VISION — GPU Concurrency Controller
 * 
 * Architecture: Dual RTX 5090 (2× 32GB VRAM)
 *   GPU 0: kuro-core (permanent, never evicted)
 *   GPU 1: FLUX.1-dev + kuro-eye (dedicated vision)
 * 
 * No model eviction required. This module ensures one vision job at a time
 * on GPU 1 and provides status telemetry.
 * 
 * v6.3 compliance: All state changes audited, no shell exec (uses Ollama HTTP API).
 */

const axios = require('axios');

const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434';

// ─── State ───────────────────────────────────────────────────────────────
let _locked = false;
let _lockHolder = null;
let _lockTime = null;
const LOCK_TIMEOUT_MS = 300000; // 5 min max per vision job

// ─── Ollama Model Status ─────────────────────────────────────────────────

async function listLoadedModels() {
  try {
    const { data } = await axios.get(`${OLLAMA_URL}/api/ps`, { timeout: 5000 });
    return (data.models || []).map(m => ({ name: m.name, size: m.size }));
  } catch (e) {
    console.error('[GPU_CTRL] Failed to list models:', e.message);
    return [];
  }
}

async function preloadModel(modelName) {
  try {
    await axios.post(`${OLLAMA_URL}/api/generate`, {
      model: modelName,
      keep_alive: '10m',
      prompt: ''
    }, { timeout: 60000 });
    return true;
  } catch (e) {
    console.error(`[GPU_CTRL] Preload ${modelName} failed:`, e.message);
    return false;
  }
}

// ─── Acquire / Release ───────────────────────────────────────────────────

async function acquire(requestId, auditFn) {
  if (_locked) {
    if (_lockTime && (Date.now() - _lockTime > LOCK_TIMEOUT_MS)) {
      console.warn(`[GPU_CTRL] Stale lock from ${_lockHolder}, forcing release`);
      await release(_lockHolder, auditFn);
    } else {
      return {
        acquired: false,
        reason: `Vision GPU locked by request ${_lockHolder}`,
        queuePosition: 0
      };
    }
  }

  _locked = true;
  _lockHolder = requestId;
  _lockTime = Date.now();

  // Ensure kuro-eye is warm on GPU 1
  await preloadModel('kuro-eye');

  if (auditFn) {
    auditFn({
      agent: 'vision',
      action: 'gpu_acquire',
      meta: { requestId, mode: 'dual-gpu', gpu: 1 }
    });
  }

  return { acquired: true, gpu: 1, mode: 'dedicated' };
}

async function release(requestId, auditFn) {
  if (!_locked || _lockHolder !== requestId) {
    return { released: false, reason: 'Not lock holder' };
  }

  if (auditFn) {
    auditFn({
      agent: 'vision',
      action: 'gpu_release',
      meta: { requestId, elapsed: Date.now() - _lockTime }
    });
  }

  _locked = false;
  _lockHolder = null;
  _lockTime = null;

  return { released: true };
}

function isLocked() {
  return { locked: _locked, holder: _lockHolder, elapsed: _lockTime ? Date.now() - _lockTime : 0 };
}

module.exports = { acquire, release, isLocked, preloadModel, listLoadedModels };
