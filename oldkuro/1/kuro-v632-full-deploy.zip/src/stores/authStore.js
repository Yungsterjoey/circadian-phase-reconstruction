/**
 * KURO::AUTH Store v1.0
 * Zustand store for auth state — session cookie based
 * Fetches /api/auth/me on init, provides login/signup/logout actions
 */
import { create } from 'zustand';

const API = '';  // Same origin

export const useAuthStore = create((set, get) => ({
  // State
  user: null,           // { id, email, name, tier, emailVerified, ... }
  subscription: null,   // { status, tier, periodEnd, cancelAtPeriodEnd }
  authMethod: null,     // 'session' | 'legacy_token' | null
  loading: true,        // Initial load
  error: null,
  showAuth: false,      // Show login/signup modal
  authTab: 'login',     // 'login' | 'signup'
  showUpgrade: false,   // Show upgrade modal
  upgradeContext: null,  // { feature, requiredTier } — what triggered the modal
  showVerify: false,     // Show OTP verification

  // Derived
  isAuthenticated: () => !!get().user,
  tier: () => get().user?.tier || 'free',
  isVerified: () => !!get().user?.emailVerified,

  // ─── INIT: Check session on load ─────────────────────
  init: async () => {
    try {
      const res = await fetch(`${API}/api/auth/me`, { credentials: 'include' });
      const data = await res.json();
      if (data.authenticated) {
        set({
          user: data.user,
          subscription: data.subscription,
          authMethod: data.authMethod,
          loading: false
        });
      } else {
        set({ user: null, loading: false });
      }
    } catch (e) {
      console.warn('[AUTH] Init check failed:', e.message);
      set({ loading: false });
    }
  },

  // ─── SIGNUP ──────────────────────────────────────────
  signup: async (email, password, name) => {
    set({ error: null });
    try {
      const res = await fetch(`${API}/api/auth/signup`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email, password, name })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Signup failed');
      set({
        user: data.user,
        showAuth: false,
        showVerify: true,
        error: null
      });
      return data;
    } catch (e) {
      set({ error: e.message });
      throw e;
    }
  },

  // ─── LOGIN ───────────────────────────────────────────
  login: async (email, password) => {
    set({ error: null });
    try {
      const res = await fetch(`${API}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Login failed');
      set({
        user: data.user,
        authMethod: 'session',
        showAuth: false,
        showVerify: !data.user.emailVerified,
        error: null
      });
      return data;
    } catch (e) {
      set({ error: e.message });
      throw e;
    }
  },

  // ─── LOGOUT ──────────────────────────────────────────
  logout: async () => {
    try {
      await fetch(`${API}/api/auth/logout`, { method: 'POST', credentials: 'include' });
    } catch (e) {}
    set({ user: null, subscription: null, authMethod: null, showAuth: false });
  },

  // ─── VERIFY EMAIL ────────────────────────────────────
  verifyEmail: async (code) => {
    set({ error: null });
    try {
      const res = await fetch(`${API}/api/auth/verify-email`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ code })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Verification failed');
      set(s => ({
        user: { ...s.user, emailVerified: true },
        showVerify: false,
        error: null
      }));
      return data;
    } catch (e) {
      set({ error: e.message });
      throw e;
    }
  },

  // ─── RESEND OTP ──────────────────────────────────────
  resendOTP: async () => {
    set({ error: null });
    try {
      const res = await fetch(`${API}/api/auth/resend-otp`, {
        method: 'POST', credentials: 'include'
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to resend');
      return data;
    } catch (e) {
      set({ error: e.message });
      throw e;
    }
  },

  // ─── TIER CHECK ──────────────────────────────────────
  // Call before opening a tier-gated feature
  // Returns true if user has access, false + shows modal if not
  checkTier: (requiredTier, feature) => {
    const LEVELS = { free: 0, pro: 1, sovereign: 2 };
    const user = get().user;

    // Not logged in → show auth
    if (!user) {
      set({ showAuth: true, authTab: 'signup' });
      return false;
    }

    const userLevel = LEVELS[user.tier] || 0;
    const requiredLevel = LEVELS[requiredTier] || 0;

    if (userLevel >= requiredLevel) return true;

    // Insufficient tier → show upgrade
    set({ showUpgrade: true, upgradeContext: { feature, requiredTier } });
    return false;
  },

  // ─── STRIPE CHECKOUT ─────────────────────────────────
  startCheckout: async (tier) => {
    try {
      const res = await fetch(`${API}/api/stripe/checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ tier })
      });
      const data = await res.json();
      if (data.url) window.location.href = data.url;
      else throw new Error(data.error || 'Checkout failed');
    } catch (e) {
      set({ error: e.message });
    }
  },

  // ─── MANAGE SUBSCRIPTION ─────────────────────────────
  openBillingPortal: async () => {
    try {
      const res = await fetch(`${API}/api/stripe/portal`, {
        method: 'POST', credentials: 'include'
      });
      const data = await res.json();
      if (data.url) window.location.href = data.url;
    } catch (e) {
      set({ error: e.message });
    }
  },

  // ─── REFRESH USER ────────────────────────────────────
  refreshUser: async () => {
    try {
      const res = await fetch(`${API}/api/auth/me`, { credentials: 'include' });
      const data = await res.json();
      if (data.authenticated) {
        set({ user: data.user, subscription: data.subscription, authMethod: data.authMethod });
      }
    } catch (e) {}
  },

  // ─── UI TOGGLES ──────────────────────────────────────
  openAuth: (tab = 'login') => set({ showAuth: true, authTab: tab, error: null }),
  closeAuth: () => set({ showAuth: false, error: null }),
  closeUpgrade: () => set({ showUpgrade: false, upgradeContext: null }),
  closeVerify: () => set({ showVerify: false }),
  setError: (error) => set({ error }),
  clearError: () => set({ error: null }),
}));
