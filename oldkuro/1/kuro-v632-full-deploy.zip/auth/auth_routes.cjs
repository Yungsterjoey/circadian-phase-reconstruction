/**
 * KURO::AUTH Routes v1.0
 * Signup, login, logout, email verification, account management
 *
 * Session: opaque ID in httpOnly cookie (GPT-01)
 * OTP: 6-digit email verification with attempt limits (GPT-02)
 *
 * Mount: app.use('/api/auth', authRoutes(legacyAuthModule));
 */

const express = require('express');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const { db, stmts, genId, genSessionId, genOTP } = require('./db.cjs');
const { sendOTP, verifyOTP } = require('./email_otp.cjs');
const { auth, resolveUser } = require('./auth_middleware.cjs');

const BCRYPT_ROUNDS = 12;
const SESSION_DURATION = '+24 hours';
const COOKIE_OPTS = {
  httpOnly: true,
  secure: process.env.NODE_ENV !== 'development',
  sameSite: 'strict',
  path: '/',
  maxAge: 24 * 60 * 60 * 1000 // 24h in ms
};

// IP rate limiter for auth endpoints
const authAttempts = new Map();
const AUTH_RATE_LIMIT = 20; // per hour per IP
const AUTH_WINDOW = 60 * 60 * 1000;

function checkAuthRate(ip) {
  const now = Date.now();
  let entry = authAttempts.get(ip);
  if (!entry || now - entry.start > AUTH_WINDOW) {
    entry = { count: 0, start: now };
    authAttempts.set(ip, entry);
  }
  entry.count++;
  return entry.count <= AUTH_RATE_LIMIT;
}

setInterval(() => {
  const now = Date.now();
  for (const [ip, entry] of authAttempts) {
    if (now - entry.start > AUTH_WINDOW) authAttempts.delete(ip);
  }
}, 15 * 60 * 1000);

/**
 * Get client IP from request
 */
function getIP(req) {
  return req.headers['x-forwarded-for']?.split(',')[0]?.trim()
    || req.headers['x-real-ip']
    || req.socket?.remoteAddress
    || 'unknown';
}

/**
 * Set session cookie
 */
function setSessionCookie(res, sessionId) {
  res.cookie('kuro_sid', sessionId, COOKIE_OPTS);
}

/**
 * Create session for user
 */
function createSession(userId, req) {
  const sid = genSessionId();
  const ip = getIP(req);
  const ua = (req.headers['user-agent'] || '').slice(0, 256);
  stmts.createSession.run(sid, userId, SESSION_DURATION, ip, ua);
  stmts.touchLogin.run(userId);
  return sid;
}

/**
 * Validate email format
 */
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}

/**
 * Validate password strength
 */
function isValidPassword(password) {
  return typeof password === 'string' && password.length >= 8 && password.length <= 128;
}

/**
 * Build the router
 */
function createAuthRoutes() {
  const router = express.Router();

  // ─── SIGNUP ──────────────────────────────────────────
  router.post('/signup', async (req, res) => {
    try {
      const ip = getIP(req);
      if (!checkAuthRate(ip)) return res.status(429).json({ error: 'Too many requests. Slow down.' });

      const { email, password, name } = req.body;

      if (!email || !isValidEmail(email)) {
        return res.status(400).json({ error: 'Valid email required' });
      }
      if (!password || !isValidPassword(password)) {
        return res.status(400).json({ error: 'Password must be 8-128 characters' });
      }

      // Check existing
      const existing = stmts.getUserByEmail.get(email.toLowerCase().trim());
      if (existing) {
        return res.status(409).json({ error: 'Email already registered', hint: 'Try logging in instead' });
      }

      // Create user
      const userId = genId();
      const hash = await bcrypt.hash(password, BCRYPT_ROUNDS);
      const user = stmts.createUser.get(userId, email.toLowerCase().trim(), name || null, hash);

      // Send OTP for email verification
      const otpResult = await sendOTP(userId, email.toLowerCase().trim(), ip);

      // Create session (even before email verified — tier-gated features require verification)
      const sid = createSession(userId, req);
      setSessionCookie(res, sid);

      res.status(201).json({
        success: true,
        user: { id: userId, email: user.email, name: user.name, tier: 'free', emailVerified: false },
        otpSent: otpResult.success,
        devCode: otpResult.devCode, // Only present in dev mode
        message: 'Account created. Check your email for a verification code.'
      });
    } catch (e) {
      console.error('[AUTH] Signup error:', e.message);
      if (e.message?.includes('UNIQUE constraint')) {
        return res.status(409).json({ error: 'Email already registered' });
      }
      res.status(500).json({ error: 'Signup failed' });
    }
  });

  // ─── LOGIN ───────────────────────────────────────────
  router.post('/login', async (req, res) => {
    try {
      const ip = getIP(req);
      if (!checkAuthRate(ip)) return res.status(429).json({ error: 'Too many requests. Slow down.' });

      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password required' });
      }

      const user = stmts.getUserByEmail.get(email.toLowerCase().trim());
      if (!user || !user.password_hash) {
        // Timing-safe: still hash something to prevent timing attacks
        await bcrypt.hash('dummy', BCRYPT_ROUNDS);
        return res.status(401).json({ error: 'Invalid email or password' });
      }

      const valid = await bcrypt.compare(password, user.password_hash);
      if (!valid) {
        return res.status(401).json({ error: 'Invalid email or password' });
      }

      const sid = createSession(user.id, req);
      setSessionCookie(res, sid);

      res.json({
        success: true,
        user: {
          id: user.id, email: user.email, name: user.name,
          tier: user.tier, emailVerified: !!user.email_verified
        }
      });
    } catch (e) {
      console.error('[AUTH] Login error:', e.message);
      res.status(500).json({ error: 'Login failed' });
    }
  });

  // ─── LOGOUT ──────────────────────────────────────────
  router.post('/logout', (req, res) => {
    const sid = req.cookies?.kuro_sid;
    if (sid) stmts.deleteSession.run(sid);
    res.clearCookie('kuro_sid', COOKIE_OPTS);
    res.json({ success: true });
  });

  // ─── VERIFY EMAIL (OTP) ──────────────────────────────
  router.post('/verify-email', (req, res) => {
    const sid = req.cookies?.kuro_sid;
    if (!sid) return res.status(401).json({ error: 'Not logged in' });

    const session = stmts.getSession.get(sid);
    if (!session) return res.status(401).json({ error: 'Session expired' });

    const { code } = req.body;
    if (!code || typeof code !== 'string' || code.length !== 6) {
      return res.status(400).json({ error: 'Enter a 6-digit code' });
    }

    const result = verifyOTP(session.user_id, code.trim());
    if (!result.valid) {
      return res.status(400).json({ error: result.error });
    }

    // Mark email verified
    stmts.verifyEmail.run(session.user_id);

    res.json({ success: true, emailVerified: true });
  });

  // ─── RESEND OTP ──────────────────────────────────────
  router.post('/resend-otp', async (req, res) => {
    const sid = req.cookies?.kuro_sid;
    if (!sid) return res.status(401).json({ error: 'Not logged in' });

    const session = stmts.getSession.get(sid);
    if (!session) return res.status(401).json({ error: 'Session expired' });

    if (session.email_verified) {
      return res.json({ success: true, message: 'Email already verified' });
    }

    const ip = getIP(req);
    const result = await sendOTP(session.user_id, session.email, ip);

    if (!result.success) {
      return res.status(429).json({ error: result.error });
    }

    res.json({ success: true, message: 'New code sent', devCode: result.devCode });
  });

  // ─── GET CURRENT USER ────────────────────────────────
  router.get('/me', auth.optional, (req, res) => {
    if (!req.user || req.user.userId === 'anon') {
      return res.json({ authenticated: false });
    }

    const user = stmts.getUserById.get(req.user.userId);
    if (!user) return res.json({ authenticated: false });

    const sub = stmts.getActiveSubscription.get(user.id);

    res.json({
      authenticated: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        tier: user.tier,
        profile: user.profile,
        emailVerified: !!user.email_verified,
        createdAt: user.created_at,
        lastLogin: user.last_login
      },
      subscription: sub ? {
        status: sub.status,
        tier: sub.tier,
        periodEnd: sub.current_period_end,
        cancelAtPeriodEnd: !!sub.cancel_at_period_end
      } : null,
      authMethod: req.user.authMethod
    });
  });

  // ─── REVOKE ALL SESSIONS ─────────────────────────────
  router.post('/sessions/revoke', auth.required, (req, res) => {
    const result = stmts.deleteUserSessions.run(req.user.userId);
    res.clearCookie('kuro_sid', COOKIE_OPTS);
    res.json({ success: true, sessionsRevoked: result.changes });
  });

  // ─── DATA EXPORT (GDPR/APPs compliance) ──────────────
  router.get('/export', auth.required, (req, res) => {
    const userId = req.user.userId;
    const user = stmts.getUserById.get(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const sessions = db.prepare('SELECT id, created_at, ip, user_agent, expires_at FROM sessions WHERE user_id = ?').all(userId);
    const oauthAccounts = db.prepare('SELECT provider, email, id FROM oauth_accounts WHERE user_id = ?').all(userId);
    const passkeys = db.prepare('SELECT id, device_type, created_at FROM passkeys WHERE user_id = ?').all(userId);
    const subscriptions = db.prepare('SELECT * FROM subscriptions WHERE user_id = ?').all(userId);
    const usage = db.prepare('SELECT action, week_num, count FROM usage WHERE user_id = ?').all(userId);

    res.json({
      exportDate: new Date().toISOString(),
      user: {
        id: user.id, email: user.email, name: user.name,
        tier: user.tier, profile: user.profile,
        emailVerified: !!user.email_verified,
        createdAt: user.created_at
      },
      sessions: sessions.length,
      oauthAccounts,
      passkeys: passkeys.map(p => ({ id: p.id, type: p.device_type, created: p.created_at })),
      subscriptions,
      usage
    });
  });

  // ─── DELETE ACCOUNT ──────────────────────────────────
  router.delete('/account', auth.required, (req, res) => {
    const { confirm } = req.body;
    if (confirm !== 'DELETE_MY_ACCOUNT') {
      return res.status(400).json({
        error: 'Confirmation required',
        hint: 'Send { "confirm": "DELETE_MY_ACCOUNT" } to proceed'
      });
    }

    const userId = req.user.userId;

    // Cascade delete (foreign keys handle most of it)
    stmts.deleteUser.run(userId);
    res.clearCookie('kuro_sid', COOKIE_OPTS);

    console.log(`[AUTH] Account deleted: ${userId}`);
    res.json({ success: true, message: 'Account and all data deleted' });
  });

  return router;
}

module.exports = createAuthRoutes;
