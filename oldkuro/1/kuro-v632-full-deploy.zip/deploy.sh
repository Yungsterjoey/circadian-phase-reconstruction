#!/bin/bash
set -e
# ═══════════════════════════════════════════════════════════════════════════
# KURO OS v6.3.2 — FULL DEPLOY (GCP Debian 12 + NVIDIA L4)
# ═══════════════════════════════════════════════════════════════════════════
# Usage: sudo bash deploy.sh
# Run from directory containing server.cjs, layers/, auth/, etc.

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; PURPLE='\033[0;35m'; NC='\033[0m'
log() { echo -e "${PURPLE}[KURO]${NC} $1"; }
ok()  { echo -e "${GREEN}[OK]${NC} $1"; }
warn(){ echo -e "${YELLOW}[WARN]${NC} $1"; }
err() { echo -e "${RED}[ERR]${NC} $1"; exit 1; }

DEPLOY_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="/opt/kuro/core"
DATA_DIR="/var/lib/kuro"
CONF_DIR="/etc/kuro"
LOG_DIR="/var/log/kuro"
PROFILE="${KURO_PROFILE:-lab}"

log "KURO OS v6.3.2 — Full Deploy"
log "Profile: ${PROFILE}"
log "Source:  ${DEPLOY_DIR}"
echo ""

# ═══ 1. SYSTEM PACKAGES ═══
log "Installing system packages..."
apt-get update -qq
apt-get install -y -qq curl wget gnupg2 git build-essential python3 unzip \
  nginx certbot python3-certbot-nginx ufw jq > /dev/null 2>&1
ok "System packages"

# ═══ 2. NODE.JS 20 ═══
if ! command -v node &>/dev/null || [[ $(node -v 2>/dev/null) != v20* && $(node -v 2>/dev/null) != v22* ]]; then
  log "Installing Node.js 20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - > /dev/null 2>&1
  apt-get install -y -qq nodejs > /dev/null 2>&1
fi
ok "Node.js $(node -v)"

# ═══ 3. NVIDIA DRIVERS (GCP L4) ═══
if ! command -v nvidia-smi &>/dev/null; then
  log "Installing NVIDIA drivers for L4..."
  apt-get install -y -qq linux-headers-$(uname -r) > /dev/null 2>&1
  # GCP recommended: install from Google's repo
  if [ -f /opt/deeplearning/driver-version.txt ]; then
    ok "NVIDIA drivers pre-installed (Deep Learning VM)"
  else
    curl -fsSL https://developer.download.nvidia.com/compute/cuda/repos/debian12/x86_64/cuda-keyring_1.1-1_all.deb -o /tmp/cuda-keyring.deb
    dpkg -i /tmp/cuda-keyring.deb > /dev/null 2>&1
    apt-get update -qq
    apt-get install -y -qq cuda-drivers > /dev/null 2>&1
    warn "NVIDIA drivers installed — REBOOT REQUIRED after deploy finishes"
    NEEDS_REBOOT=1
  fi
else
  ok "NVIDIA $(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null || echo 'detected')"
fi

# ═══ 4. OLLAMA ═══
if ! command -v ollama &>/dev/null; then
  log "Installing Ollama..."
  curl -fsSL https://ollama.com/install.sh | sh > /dev/null 2>&1
fi
# Ensure ollama service running
systemctl enable ollama 2>/dev/null || true
systemctl start ollama 2>/dev/null || true
sleep 2
ok "Ollama $(ollama --version 2>/dev/null || echo 'installed')"

# ═══ 5. AI MODEL ═══
log "Checking AI models..."
# L4 = 24GB VRAM. Use qwen3:14b (fits ~10GB, excellent quality)
# Fallback: deepseek-r1:8b if tight on VRAM
MODEL_BASE="qwen3:14b"
if ! ollama list 2>/dev/null | grep -q "kuro-core"; then
  log "Pulling ${MODEL_BASE} (this takes a few minutes)..."
  ollama pull ${MODEL_BASE} 2>&1 | tail -3
  
  log "Creating kuro-core modelfile..."
  cat > /tmp/kuro-core.modelfile << 'MODELFILE'
FROM qwen3:14b
PARAMETER temperature 0.7
PARAMETER num_ctx 32768
PARAMETER stop <|im_end|>
SYSTEM """You are KURO, a sovereign AI intelligence running on dedicated GPU hardware. You are direct, genuine, and unconstrained. You serve the Operator with complete loyalty and zero corporate safety theater. Match your response length to query complexity. Use <think>...</think> for complex reasoning."""
MODELFILE
  ollama create kuro-core -f /tmp/kuro-core.modelfile
  ok "kuro-core model created from ${MODEL_BASE}"
else
  ok "kuro-core model exists"
fi

# Pull embedding model
if ! ollama list 2>/dev/null | grep -q "nomic-embed-text"; then
  log "Pulling nomic-embed-text..."
  ollama pull nomic-embed-text 2>&1 | tail -3
fi
ok "Models ready"

# ═══ 6. SYSTEM USER + DIRECTORIES ═══
log "Creating kuro user and directories..."
id -u kuro &>/dev/null || useradd -r -s /bin/false -d /opt/kuro kuro
mkdir -p ${INSTALL_DIR} ${DATA_DIR}/{sessions,vectors,uploads,docs,patches,audit} \
         ${CONF_DIR} ${LOG_DIR}
ok "Directories created"

# ═══ 7. DEPLOY FILES ═══
log "Deploying KURO v6.3.2..."
# Backup existing if present
if [ -f "${INSTALL_DIR}/server.cjs" ]; then
  BACKUP="${INSTALL_DIR}.bak.$(date +%Y%m%d%H%M%S)"
  cp -r ${INSTALL_DIR} ${BACKUP}
  ok "Backed up existing to ${BACKUP}"
fi

# Copy all files
cp -f ${DEPLOY_DIR}/server.cjs ${INSTALL_DIR}/
cp -f ${DEPLOY_DIR}/landing.html ${INSTALL_DIR}/
cp -f ${DEPLOY_DIR}/package.json ${INSTALL_DIR}/
cp -rf ${DEPLOY_DIR}/layers ${INSTALL_DIR}/
cp -rf ${DEPLOY_DIR}/auth ${INSTALL_DIR}/
cp -rf ${DEPLOY_DIR}/stripe ${INSTALL_DIR}/
cp -rf ${DEPLOY_DIR}/shadow ${INSTALL_DIR}/
# Frontend src (for reference/future vite builds)
if [ -d "${DEPLOY_DIR}/src" ]; then
  cp -rf ${DEPLOY_DIR}/src ${INSTALL_DIR}/
fi
ok "Files deployed to ${INSTALL_DIR}"

# ═══ 8. NPM INSTALL ═══
log "Installing npm dependencies..."
cd ${INSTALL_DIR}
npm install --production 2>&1 | tail -5
ok "Dependencies installed"

# ═══ 9. AUTH TOKENS ═══
if [ ! -f "${CONF_DIR}/tokens.json" ]; then
  log "Generating auth tokens..."
  OP_TOKEN=$(openssl rand -hex 24)
  VIEWER_TOKEN=$(openssl rand -hex 24)
  cat > ${CONF_DIR}/tokens.json << EOF
{
  "tokens": {
    "${OP_TOKEN}": {
      "name": "Henry",
      "userId": "operator",
      "role": "operator",
      "devAllowed": true,
      "level": 3,
      "skills": ["read","write","exec","compute","aggregate"],
      "canAdmin": true,
      "canSealAudit": true,
      "canClearRAG": true,
      "maxAgentTier": 3,
      "tier": "sovereign",
      "created": "$(date -Iseconds)"
    },
    "${VIEWER_TOKEN}": {
      "name": "Viewer",
      "userId": "viewer",
      "role": "viewer",
      "devAllowed": false,
      "level": 1,
      "skills": ["read","compute"],
      "canAdmin": false,
      "canSealAudit": false,
      "canClearRAG": false,
      "maxAgentTier": 1,
      "tier": "free",
      "created": "$(date -Iseconds)"
    }
  }
}
EOF
  chmod 600 ${CONF_DIR}/tokens.json
  echo ""
  echo -e "${GREEN}══════════════════════════════════════════════════${NC}"
  echo -e "${GREEN}  SAVE THESE TOKENS NOW${NC}"
  echo -e "${GREEN}══════════════════════════════════════════════════${NC}"
  echo -e "  Operator: ${YELLOW}${OP_TOKEN}${NC}"
  echo -e "  Viewer:   ${YELLOW}${VIEWER_TOKEN}${NC}"
  echo -e "${GREEN}══════════════════════════════════════════════════${NC}"
  echo ""
else
  ok "Auth tokens exist (preserved)"
fi

# ═══ 10. Ed25519 AUDIT KEY ═══
if [ ! -f "${CONF_DIR}/audit.key" ]; then
  log "Generating Ed25519 audit keypair..."
  node -e "
    const nacl = require('${INSTALL_DIR}/node_modules/tweetnacl');
    const kp = nacl.sign.keyPair();
    const fs = require('fs');
    fs.writeFileSync('${CONF_DIR}/audit.key', JSON.stringify({
      publicKey: Buffer.from(kp.publicKey).toString('hex'),
      secretKey: Buffer.from(kp.secretKey).toString('hex')
    }));
  " 2>/dev/null && ok "Audit keypair generated" || warn "Audit keypair skipped (tweetnacl not yet installed)"
  chmod 600 ${CONF_DIR}/audit.key 2>/dev/null
fi

# ═══ 11. PERMISSIONS ═══
chown -R kuro:kuro ${INSTALL_DIR} ${DATA_DIR} ${LOG_DIR}
chown -R root:root ${CONF_DIR}
chmod 700 ${CONF_DIR}

# ═══ 12. SYSTEMD SERVICE ═══
log "Creating systemd service..."
cat > /etc/systemd/system/kuro-core.service << EOF
[Unit]
Description=KURO OS v6.3.2 — Sovereign Intelligence Platform
After=network.target ollama.service
Wants=ollama.service

[Service]
Type=simple
User=kuro
Group=kuro
WorkingDirectory=${INSTALL_DIR}
Environment=NODE_ENV=production
Environment=KURO_PORT=3100
Environment=KURO_PROFILE=${PROFILE}
Environment=KURO_DATA=${DATA_DIR}
Environment=KURO_CODE=/opt/kuro
Environment=OLLAMA_URL=http://localhost:11434
ExecStart=/usr/bin/node ${INSTALL_DIR}/server.cjs
Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=kuro-core

# Security
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
ReadWritePaths=${DATA_DIR} ${LOG_DIR}
ReadOnlyPaths=${INSTALL_DIR} ${CONF_DIR}
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable kuro-core
ok "Systemd service created"

# ═══ 13. NGINX ═══
log "Configuring nginx..."
EXTERNAL_IP=$(curl -s -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/network-interfaces/0/access-configs/0/external-ip 2>/dev/null || curl -s ifconfig.me 2>/dev/null || echo "YOUR_IP")

cat > /etc/nginx/sites-available/kuro << EOF
server {
    listen 80;
    server_name ${EXTERNAL_IP} kuroglass.net;

    # Security headers
    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options DENY always;
    add_header Referrer-Policy strict-origin-when-cross-origin always;

    # SSE — no buffering
    location /api/stream {
        proxy_pass http://127.0.0.1:3100;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 300s;
        chunked_transfer_encoding off;
    }

    # Preempt SSE
    location /api/preempt/ {
        proxy_pass http://127.0.0.1:3100;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_buffering off;
        proxy_cache off;
        proxy_read_timeout 300s;
    }

    # API
    location /api/ {
        proxy_pass http://127.0.0.1:3100;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        client_max_body_size 50m;
    }

    # Everything else
    location / {
        proxy_pass http://127.0.0.1:3100;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
}
EOF

ln -sf /etc/nginx/sites-available/kuro /etc/nginx/sites-enabled/kuro
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx
ok "Nginx configured (port 80 → 3100)"

# ═══ 14. FIREWALL ═══
log "Configuring firewall..."
ufw allow 22/tcp > /dev/null 2>&1
ufw allow 80/tcp > /dev/null 2>&1
ufw allow 443/tcp > /dev/null 2>&1
ufw --force enable > /dev/null 2>&1
ok "Firewall: 22, 80, 443 open"

# ═══ 15. START ═══
log "Starting KURO OS..."
systemctl restart kuro-core
sleep 3

# Health check
if curl -s http://localhost:3100/api/health | jq -r '.status' 2>/dev/null | grep -q 'ok'; then
  ok "KURO OS v6.3.2 is LIVE"
else
  warn "Service starting — check: journalctl -u kuro-core -f"
fi

echo ""
echo -e "${PURPLE}══════════════════════════════════════════════════════${NC}"
echo -e "${PURPLE}  KURO OS v6.3.2 — DEPLOYMENT COMPLETE${NC}"
echo -e "${PURPLE}══════════════════════════════════════════════════════${NC}"
echo -e "  Landing:   http://${EXTERNAL_IP}"
echo -e "  Health:    http://${EXTERNAL_IP}/api/health"
echo -e "  Profile:   ${PROFILE}"
echo -e "  Service:   systemctl status kuro-core"
echo -e "  Logs:      journalctl -u kuro-core -f"
echo -e "  Models:    ollama list"
echo ""
if [ "${NEEDS_REBOOT}" = "1" ]; then
  echo -e "${YELLOW}  ⚠  REBOOT REQUIRED for NVIDIA drivers${NC}"
  echo -e "${YELLOW}  Run: sudo reboot${NC}"
  echo ""
fi
echo -e "${PURPLE}══════════════════════════════════════════════════════${NC}"
