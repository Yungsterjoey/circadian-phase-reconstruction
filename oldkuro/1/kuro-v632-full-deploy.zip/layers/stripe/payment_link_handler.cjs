/**
 * KURO::STRIPE — Payment Link Handler v1.1
 * Handles cold purchases from landing page (no user_id metadata)
 * Generates token, writes to tokens.json, sends branded HTML email
 */
const crypto = require('crypto');
const fs = require('fs');
const nodemailer = require('nodemailer');

function buildWelcomeEmail(token, tier, email) {
  const tierName = tier.charAt(0).toUpperCase() + tier.slice(1);
  const tierColor = tier === 'sovereign' ? '#c084fc' : '#a855f7';
  const features = tier === 'sovereign' ? [
    'Unlimited AI chat messages',
    'Full KURO OS desktop environment',
    'All AI agents — Insights, Actions, Analysis',
    'DEV mode with code execution',
    'KURO::VISION image generation',
    'Terminal, file explorer, knowledge engine',
    'REST API access + audit log export',
    'Priority support'
  ] : [
    'Unlimited AI chat messages',
    'KURO::VISION image generation',
    'Insights + Actions agents',
    '12-layer cognitive pipeline',
    'Priority inference',
    'Email support'
  ];

  const featureRows = features.map(f =>
    `<tr><td style="padding:4px 0;color:rgba(255,255,255,0.55);font-size:13px;line-height:1.5"><span style="color:${tierColor};margin-right:8px">→</span>${f}</td></tr>`
  ).join('');

  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#000;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Display',system-ui,sans-serif">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#000;padding:32px 16px">
<tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px">

<!-- Header -->
<tr><td style="padding:32px 0 24px;text-align:center">
  <div style="display:inline-block;width:48px;height:48px;background:linear-gradient(135deg,#9333ea,#6366f1);border-radius:12px;line-height:48px;color:#fff;font-weight:700;font-size:22px;text-align:center">K</div>
</td></tr>

<!-- Welcome -->
<tr><td style="text-align:center;padding-bottom:8px">
  <h1 style="margin:0;font-size:24px;font-weight:300;color:#fff;letter-spacing:6px">KURO<span style="color:#a855f7;margin-left:2px">.OS</span></h1>
</td></tr>
<tr><td style="text-align:center;padding-bottom:32px">
  <p style="margin:0;font-size:11px;letter-spacing:3px;color:rgba(255,255,255,0.3);font-weight:500">SOVEREIGN INTELLIGENCE PLATFORM</p>
</td></tr>

<!-- Main Card -->
<tr><td>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:rgba(12,12,16,1);border:1px solid rgba(255,255,255,0.08);border-radius:16px;overflow:hidden">

  <!-- Tier Badge -->
  <tr><td style="padding:28px 28px 0;text-align:center">
    <div style="display:inline-block;padding:5px 16px;border-radius:100px;background:rgba(147,51,234,0.12);border:1px solid rgba(147,51,234,0.2);font-size:11px;font-weight:600;letter-spacing:1.5px;color:${tierColor};text-transform:uppercase">${tierName} Plan</div>
  </td></tr>

  <!-- Welcome Text -->
  <tr><td style="padding:20px 28px 4px">
    <p style="margin:0;color:#fff;font-size:17px;font-weight:600;text-align:center">Welcome to KURO OS</p>
  </td></tr>
  <tr><td style="padding:4px 28px 24px">
    <p style="margin:0;color:rgba(255,255,255,0.4);font-size:13px;text-align:center;line-height:1.5">Your sovereign AI environment is ready. Use the token below to sign in.</p>
  </td></tr>

  <!-- Token Box -->
  <tr><td style="padding:0 28px 24px">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:12px">
      <tr><td style="padding:6px 16px 2px">
        <p style="margin:0;font-size:10px;font-weight:600;letter-spacing:1px;color:rgba(255,255,255,0.25);text-transform:uppercase">Your Access Token</p>
      </td></tr>
      <tr><td style="padding:2px 16px 14px">
        <code style="font-size:15px;font-weight:600;color:#fff;font-family:'SF Mono',Monaco,Consolas,monospace;letter-spacing:0.5px;word-break:break-all">${token}</code>
      </td></tr>
    </table>
  </td></tr>

  <!-- Sign In Button -->
  <tr><td style="padding:0 28px 28px;text-align:center">
    <a href="https://kuroglass.net/#access" style="display:inline-block;padding:12px 36px;background:linear-gradient(135deg,rgba(147,51,234,0.9),rgba(91,33,182,0.9));color:#fff;text-decoration:none;border-radius:10px;font-size:14px;font-weight:600;letter-spacing:0.02em">Sign In to KURO OS</a>
  </td></tr>

  <!-- Divider -->
  <tr><td style="padding:0 28px"><div style="height:1px;background:rgba(255,255,255,0.06)"></div></td></tr>

  <!-- Your Plan Includes -->
  <tr><td style="padding:20px 28px 4px">
    <p style="margin:0;font-size:12px;font-weight:600;color:rgba(255,255,255,0.5);letter-spacing:0.5px">YOUR PLAN INCLUDES</p>
  </td></tr>
  <tr><td style="padding:8px 28px 24px">
    <table role="presentation" cellpadding="0" cellspacing="0">${featureRows}</table>
  </td></tr>

</table>
</td></tr>

<!-- Security Notice -->
<tr><td style="padding:20px 0 0;text-align:center">
  <p style="margin:0;font-size:12px;color:rgba(255,255,255,0.3);line-height:1.6">
    <span style="color:rgba(255,255,255,0.5);font-weight:500">Keep your token safe.</span> It is your key to the platform.<br>
    If you did not make this purchase, contact us immediately.
  </p>
</td></tr>

<!-- Help -->
<tr><td style="padding:16px 0 0;text-align:center">
  <p style="margin:0;font-size:12px;color:rgba(255,255,255,0.25)">
    Need help? <a href="mailto:hello@kuroglass.net" style="color:rgba(168,85,247,0.7);text-decoration:none">hello@kuroglass.net</a>
  </p>
</td></tr>

<!-- Footer -->
<tr><td style="padding:32px 0 0;text-align:center">
  <div style="height:1px;background:rgba(255,255,255,0.04);margin-bottom:20px"></div>
  <p style="margin:0 0 4px;font-size:11px;color:rgba(255,255,255,0.2)">
    KURO OS · Sovereign Intelligence Platform
  </p>
  <p style="margin:0 0 4px;font-size:10px;color:rgba(255,255,255,0.12)">
    Henry George Lowe trading as KURO Technologies · ABN 45 340 322 909
  </p>
  <p style="margin:0 0 4px;font-size:10px;color:rgba(255,255,255,0.12)">
    Melbourne, Victoria, Australia
  </p>
  <p style="margin:0;font-size:10px;color:rgba(255,255,255,0.12)">
    <a href="https://kuroglass.net" style="color:rgba(255,255,255,0.15);text-decoration:none">kuroglass.net</a> ·
    <a href="mailto:hello@kuroglass.net" style="color:rgba(255,255,255,0.15);text-decoration:none">hello@kuroglass.net</a>
  </p>
  <p style="margin:8px 0 0;font-size:9px;color:rgba(255,255,255,0.08)">
    &copy; ${new Date().getFullYear()} KURO Technologies. All rights reserved.
  </p>
</td></tr>

</table>
</td></tr>
</table>
</body>
</html>`;
}

async function handlePaymentLinkPurchase(session) {
  const email = session.customer_details?.email || session.customer_email;
  if (!email) {
    console.error('[STRIPE] Payment Link: no email on session', session.id);
    return;
  }

  const amount = session.amount_total || 0;
  const tier = amount >= 4900 ? 'sovereign' : 'pro';
  const token = 'kuro_' + crypto.randomBytes(16).toString('hex');
  const userId = 'pl_' + crypto.randomBytes(8).toString('hex');

  // Write token to tokens.json
  const tokensPath = '/etc/kuro/tokens.json';
  try {
    const data = JSON.parse(fs.readFileSync(tokensPath, 'utf8'));
    data.tokens[token] = {
      name: email.split('@')[0],
      devAllowed: tier === 'sovereign',
      tier, email, userId,
      created: new Date().toISOString(),
      source: 'payment_link',
      stripeSession: session.id
    };
    fs.writeFileSync(tokensPath, JSON.stringify(data, null, 2));
    console.log(`[STRIPE] Token written for ${email} (${tier})`);
  } catch (e) {
    console.error('[STRIPE] Token write failed:', e.message);
    console.log(`[STRIPE] MANUAL: ${email} | ${token} | ${tier}`);
    return;
  }

  // Send branded HTML email
  try {
    const transport = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: false,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });
    await transport.sendMail({
      from: `"KURO OS" <${process.env.SMTP_FROM || 'hello@kuroglass.net'}>`,
      to: email,
      subject: `Welcome to KURO OS — Your ${tier.charAt(0).toUpperCase() + tier.slice(1)} access is ready`,
      html: buildWelcomeEmail(token, tier, email),
      text: `Welcome to KURO OS\n\nYour access token: ${token}\n\nSign in: https://kuroglass.net\nPlan: ${tier.charAt(0).toUpperCase() + tier.slice(1)}\n\nKeep this token safe.\n\nKURO Technologies\nHenry George Lowe trading as KURO Technologies\nABN 45 340 322 909 · Melbourne, VIC, Australia\nhello@kuroglass.net`
    });
    console.log(`[STRIPE] Token emailed to ${email}`);
  } catch (e) {
    console.error('[STRIPE] Email failed:', e.message);
    console.log(`[STRIPE] MANUAL DELIVERY: ${email} | ${token} | ${tier}`);
  }

  console.log(`[STRIPE] Payment Link: ${email} → ${tier} (token: ${token.slice(0,10)}...)`);
}

module.exports = { handlePaymentLinkPurchase };
