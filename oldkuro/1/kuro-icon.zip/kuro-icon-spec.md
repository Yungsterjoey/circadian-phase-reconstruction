# KURO::ICON — Cubic Liquid Glass 3D Icon Renderer

## Technical Specification v1.0

---

## ONE-PAGE OVERVIEW

**KURO::ICON** is a lightweight, production-grade 3D icon rendering system that replaces flat SVG/emoji icons with physically-plausible "Liquid Glass" micro-objects. Each icon is a rounded, translucent 3D form rendered inline in the DOM — like emoji, but volumetric.

**Renderer**: Custom WebGL2 micro-renderer (~18KB gzipped), no Three.js dependency. WebGPU upgrade path defined but not required for v1.

**Material**: Physically-based glass with real refraction, Beer–Lambert absorption, GGX microfacet specular, Schlick Fresnel, and prefiltered environment lighting. Zero flicker guaranteed via PMREM, temporal clamping, and deterministic sampling.

**Geometry**: All meshes enforce rounded silhouettes — superellipse cubes, filleted edges, smooth normals. GLB format, offline-beveled, LOD-proxied, curvature-baked.

**API**: Web Component `<kuro-icon>` + JS `renderIcon()`. Inline-block, baseline-aligned, SSR-fallback to PNG poster. Respects `prefers-reduced-motion`, `prefers-color-scheme`, theme tokens.

**Performance**: Single shared WebGL2 context, instanced draws, offscreen pause via IntersectionObserver. Target: 60fps with 20+ icons visible on iPhone 13.

---

## 1. ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│                    <kuro-icon> Web Component                 │
│  Attributes: name, size, motion, theme, tint               │
├──────────────┬──────────────┬───────────────────────────────┤
│ Asset Cache  │ Renderer     │ Interaction                   │
│              │              │                               │
│ • MeshCache  │ • SharedGL   │ • HoverTilt                   │
│ • EnvCache   │ • Pipeline   │ • ReducedMotion               │
│ • PosterMap  │ • FrameLoop  │ • IntersectionPause           │
└──────┬───────┴──────┬───────┴───────────────┬───────────────┘
       │              │                       │
       ▼              ▼                       ▼
┌──────────┐  ┌──────────────┐  ┌─────────────────────────────┐
│ GLB Mesh │  │ WebGL2 Ctx   │  │ DOM Integration             │
│ Registry │  │ (shared)     │  │ • inline-block              │
│          │  │              │  │ • vertical-align baseline   │
│ offline  │  │ Framebuffer  │  │ • canvas per icon           │
│ beveled  │  │ pipeline:    │  │ • poster fallback           │
│ LOD 0-2  │  │              │  │                             │
│ curvature│  │ 1. Depth     │  └─────────────────────────────┘
│ baked    │  │ 2. Thickness │
└──────────┘  │ 3. Glass     │
              │ 4. Composite │
              └──────────────┘
```

### Module Responsibilities

| Module | File | Role |
|--------|------|------|
| `KuroIcon` | `kuro-icon.js` | Web Component, lifecycle, attribute observers |
| `IconRenderer` | `renderer.js` | Shared WebGL2 context, pipeline, frame scheduling |
| `GlassMaterial` | `glass-material.js` | Shader programs, uniforms, material params |
| `MeshCache` | `mesh-cache.js` | GLB loader, geometry buffers, LOD selection |
| `EnvCache` | `env-cache.js` | PMREM generation, env map storage, theme switching |
| `FrameLoop` | `frame-loop.js` | rAF scheduler, per-icon render queue, offscreen skip |
| `Interaction` | `interaction.js` | Hover tilt, pointer tracking, motion prefs |
| `Poster` | `poster.js` | SSR/no-JS fallback PNG map |

### Data Flow (per frame)

```
1. FrameLoop tick (single rAF for all icons)
2. For each visible icon:
   a. Bind icon's canvas as render target (via shared context)
   b. Select LOD based on rendered size
   c. Upload uniforms (camera, tilt, theme, size)
   d. Draw pass 1: depth + thickness to FBO
   e. Draw pass 2: glass composite (refraction + reflection + absorption)
   f. Present to canvas
3. Skip offscreen icons (IntersectionObserver)
```

---

## 2. RENDERING APPROACH

### Decision: WebGL2-First, WebGPU Upgrade Path

**Choice**: WebGL2 primary. No WebGPU in v1.

**Justification**:
- **Mobile Safari**: WebGPU landed in Safari 18.2 (late 2024) but real-world adoption on older iPhones is still lagging. WebGL2 has 97%+ global support.
- **Determinism**: WebGL2 shader compilation is well-understood. WebGPU's WGSL pipeline caching behavior varies across implementations.
- **Bundle size**: Custom WebGL2 renderer = ~18KB gzip. Adding WebGPU doubles code paths for marginal gain at icon scale.
- **KURO's audience**: Primary devices are iPhones, iPads, desktop Chrome/Firefox. All have mature WebGL2.

**WebGPU Upgrade Path**: The shader logic (GLSL → WGSL) is a mechanical translation. The pipeline architecture (shared context, dual-pass) maps directly. When WebGPU reaches ≥90% on KURO's audience, swap the backend without changing the component API.

### Why Not Three.js

Three.js solves general 3D app problems. KURO::ICON needs:
- A single material (glass)
- A single geometry type (rounded meshes, <5K tris)
- A single camera (ortho/weak-perspective)
- No scene graph, no physics, no post-processing stack

Three.js minimum bundle (tree-shaken): ~120KB gzip. Custom renderer: ~18KB. For inline icons that must load fast, the 6× reduction matters.

---

## 3. LIQUID GLASS MATERIAL MODEL

### 3.1 Parameters

```glsl
struct GlassMaterial {
  float ior;            // 1.45–1.55 (crown glass range)
  float thickness;      // 0.3–1.0 normalized (drives absorption)
  vec3  absorptionColor;// tint color in linear space
  float absorptionDensity; // Beer–Lambert coefficient (0.5–3.0)
  float roughness;      // 0.05–0.20 (very smooth, not mirror)
  float specularClamp;  // 0.6 max (prevents flicker highlights)
  float fresnelBias;    // 0.04 (dielectric F0)
};
```

### 3.2 Fresnel (Schlick Approximation)

```glsl
float fresnel(float cosTheta, float f0) {
  return f0 + (1.0 - f0) * pow(1.0 - cosTheta, 5.0);
}
```

F0 for glass at IOR 1.50 = ((1.5 - 1.0) / (1.5 + 1.0))² ≈ 0.04.

### 3.3 Absorption (Beer–Lambert)

```glsl
vec3 absorption(vec3 baseColor, float thickness, float density) {
  return exp(-density * thickness * (1.0 - baseColor));
}
```

Gives volumetric tint that darkens with thickness. Maps absorptionColor to how much each channel survives passage through the glass.

### 3.4 Specular (GGX Microfacet)

```glsl
float D_GGX(float NoH, float roughness) {
  float a = roughness * roughness;
  float a2 = a * a;
  float denom = NoH * NoH * (a2 - 1.0) + 1.0;
  return a2 / (PI * denom * denom);
}

float G_Smith(float NoV, float NoL, float roughness) {
  float k = (roughness + 1.0) * (roughness + 1.0) / 8.0;
  float gv = NoV / (NoV * (1.0 - k) + k);
  float gl = NoL / (NoL * (1.0 - k) + k);
  return gv * gl;
}
```

**Specular clamped**: `min(specular, material.specularClamp)` — this is the primary anti-flicker measure. Prevents any single-pixel highlight from exceeding 60% intensity.

### 3.5 Refraction Method

**Dual-pass with thickness buffer** (NOT ray-marching — too expensive per-pixel at icon scale, and jitter patterns cause shimmer).

**Pass 1 — Depth + Thickness**:
- Render front faces to depth buffer
- Render back faces, compute thickness = `backDepth - frontDepth`
- Store thickness in R channel of an FBO texture

**Pass 2 — Glass Composite**:
- For each fragment, sample thickness from Pass 1
- Compute refraction offset: `vec2 offset = refractionDir.xy * thickness * refractionStrength`
- Sample background at `screenUV + offset` (from a pre-captured or CSS-provided background snapshot)
- Apply Beer–Lambert absorption based on thickness
- Blend with specular reflection from prefiltered env map
- Mix via Fresnel

**Stability guarantees**:
- Refraction offset is clamped to ±8 texels maximum → no wild distortion at edges
- Thickness is smoothed via a 3×3 bilateral filter on the thickness buffer → no per-pixel noise
- Background sampling uses bilinear (not nearest) → smooth refraction

### 3.6 Prefiltered Environment Lighting (PMREM)

**Problem**: Raw environment maps cause sparkle/flicker because tiny specular highlights alias differently each frame.

**Solution**: Ship prefiltered PMREM cubemaps at 5 mip levels:
- Mip 0: roughness ≈ 0.0 (sharp reflections, only used for roughness < 0.05)
- Mip 1: roughness ≈ 0.1
- Mip 2: roughness ≈ 0.2
- Mip 3: roughness ≈ 0.5
- Mip 4: roughness ≈ 1.0 (fully diffuse)

For KURO's glass (roughness 0.05–0.20), we sample mip 1–2. These are pre-blurred → **no high-frequency sparkle**.

**Env maps shipped**:
- `kuro-env-dark.ktx2` — dark theme (warm studio lighting, subtle)
- `kuro-env-light.ktx2` — light theme (bright, cooler)
- Generated at build time from deterministic HDR studio setups
- 64×64 per face (tiny — icons don't need high-res reflections)

### 3.7 Chromatic Dispersion (Optional, Safe)

```glsl
// Subtle RGB offset based on view angle and thickness
float dispersionStrength = 0.008; // very subtle
vec2 offsetR = refrOffset * (1.0 + dispersionStrength);
vec2 offsetG = refrOffset;
vec2 offsetB = refrOffset * (1.0 - dispersionStrength);

vec3 refracted = vec3(
  texture(uBackground, uv + offsetR).r,
  texture(uBackground, uv + offsetG).g,
  texture(uBackground, uv + offsetB).b
);
```

**Why safe**: The offset delta between R and B is ≤1.6% of the base refraction. At icon sizes (16–128px), this produces a 0–2 pixel RGB fringe maximum. No rainbow flicker because the offset is deterministic (not noise-based) and scales linearly with view angle.

**Disabled by default** — opt-in via `<kuro-icon dispersion>`.

---

## 4. GEOMETRY PIPELINE

### 4.1 Asset Format

**GLB** (binary glTF) — industry standard, compact, includes vertex data + normals + optional curvature attribute.

### 4.2 Rounding Strategy

**Tier 1 (Preferred): Offline mesh beveling at build time**

```
Source mesh (sharp) → Blender script → Bevel modifier (width: 0.08, segments: 3)
                                     → Shade smooth (angle: 45°)
                                     → Decimate (target: 2000 tris)
                                     → Bake curvature → vertex color (R channel)
                                     → Export GLB with curvature attribute
```

All KURO icon meshes MUST go through this pipeline. No sharp-edged mesh reaches the renderer.

**Tier 2 (Fallback): Curvature-based fake bevel shader**

For runtime-loaded meshes that haven't been pre-beveled:

```glsl
// Approximate rounded edges via screen-space curvature
float edgeFactor = 1.0 - smoothstep(0.0, 0.15, abs(dot(normal, viewDir)));
vec3 softNormal = mix(normal, viewDir, edgeFactor * 0.3);
```

This bends normals at silhouette edges to fake roundness. It's a last resort — silhouette remains sharp, only shading is softened.

**Tier 3 (Build-time SDF remesh)**: For complex meshes, an SDF voxelization + marching cubes remesh with implicit rounding. Too slow for runtime, fine as a build step for meshes that can't be beveled conventionally.

### 4.3 Icon Proxy LOD Generator

Each icon mesh has 3 LODs:

| LOD | Triangle Target | Use Case | Corner Radius |
|-----|----------------|----------|---------------|
| 0 | 2000–4000 | ≥64px rendering | Full detail |
| 1 | 500–1000 | 32–63px rendering | Simplified |
| 2 | 100–250 | 16–31px rendering | Basic rounded form |

LOD selection: `lod = size < 32 ? 2 : size < 64 ? 1 : 0`

**Minimum corner radius enforced**: At LOD 2 (16px), the mesh must have ≥2px apparent corner radius on screen. This is validated in the build pipeline.

### 4.4 Deterministic Icon Framing

Every icon is framed identically for visual consistency:

```javascript
function frameIcon(boundingBox) {
  const maxExtent = Math.max(
    boundingBox.width,
    boundingBox.height,
    boundingBox.depth
  );
  
  // Normalize to unit cube
  const scale = 0.75 / maxExtent; // 75% fill — breathing room
  const center = boundingBox.center;
  
  // Camera: weak perspective (near-ortho with subtle depth)
  const fov = 12; // degrees — very narrow, near-orthographic
  const distance = 1.0 / Math.tan((fov / 2) * DEG2RAD);
  
  // Standard orientation: 15° yaw, -10° pitch (Apple-style 3/4 view)
  const yaw = 15 * DEG2RAD;
  const pitch = -10 * DEG2RAD;
  
  return { scale, center, fov, distance, yaw, pitch };
}
```

This ensures every icon occupies ~75% of its canvas, viewed from a consistent gentle angle, with near-orthographic projection that reads clearly at small sizes.

---

## 5. WEB COMPONENT API

### 5.1 `<kuro-icon>` Custom Element

```html
<!-- Basic usage -->
<kuro-icon name="glasscube" size="24"></kuro-icon>

<!-- With options -->
<kuro-icon 
  name="settings" 
  size="48" 
  motion="hover" 
  theme="dark"
  tint="#a855f7"
  dispersion
></kuro-icon>

<!-- Inline in text (emoji replacement) -->
<p>Welcome to KURO <kuro-icon name="glasscube" size="20"></kuro-icon> OS</p>
```

**Attributes**:

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `name` | string | required | Icon mesh name from registry |
| `size` | number | 24 | Render size in CSS px (16–128) |
| `motion` | `"hover"` / `"idle"` / `"none"` | `"hover"` | Animation mode |
| `theme` | `"auto"` / `"dark"` / `"light"` | `"auto"` | Env map + tint selection |
| `tint` | CSS color | `null` | Glass absorption tint override |
| `dispersion` | boolean | `false` | Enable chromatic dispersion |

### 5.2 JavaScript API

```javascript
import { renderIcon } from '@kuro/icon';

const el = renderIcon({
  name: 'glasscube',
  size: 32,
  motion: 'hover',
  theme: 'auto',
  backgroundHint: '#0a0a0e' // helps refraction look right
});

document.querySelector('.toolbar').appendChild(el);
```

Returns an HTMLElement (the web component instance).

### 5.3 Inline Alignment

```css
kuro-icon {
  display: inline-block;
  vertical-align: -0.125em; /* match emoji baseline offset */
  line-height: 1;
  width: var(--kuro-icon-size, 24px);
  height: var(--kuro-icon-size, 24px);
}
```

### 5.4 SSR / No-JS Fallback

```html
<!-- Server renders this; client upgrades to 3D -->
<kuro-icon name="glasscube" size="24">
  <img 
    src="/icons/glasscube-24.webp" 
    alt="KURO" 
    width="24" 
    height="24" 
    loading="lazy"
  />
</kuro-icon>
```

The `<img>` fallback is visible until the web component hydrates and replaces it with the live canvas. Progressive enhancement.

Poster frames are pre-rendered at build time for sizes 16, 20, 24, 32, 48, 64, 128.

---

## 6. MOTION RULES

### 6.1 Defaults

| Mode | Behavior |
|------|----------|
| `hover` | Static at rest. On pointer enter: smooth tilt toward cursor (max ±12°). On pointer leave: ease back to default orientation over 600ms. |
| `idle` | Continuous gentle rotation: Y-axis at 4°/sec, X-axis ±2° sine wave at 0.3Hz. |
| `none` | Completely static. No animation frames consumed. |

### 6.2 Stability Rules

- **Max angular velocity**: 15°/sec (any axis). Prevents fast highlight sweeps.
- **Max specular movement**: Highlights shift ≤3px per frame at 60fps.
- **Easing**: All transitions use `cubic-bezier(0.33, 0, 0.2, 1)` (Apple spring-like).
- **No noise/jitter**: All motion is deterministic (sin/cos based), no random perturbation.

### 6.3 Accessibility

```javascript
const prefersReduced = matchMedia('(prefers-reduced-motion: reduce)').matches;

if (prefersReduced) {
  // Force motion="none", render single static frame, stop rAF
  icon.setAttribute('motion', 'none');
}
```

Also respects `prefers-contrast: more` — increases glass opacity, reduces refraction strength.

---

## 7. PERFORMANCE

### 7.1 Budgets

| Metric | Budget | Strategy |
|--------|--------|----------|
| Draw calls per icon | 2 | Dual-pass (thickness + composite) |
| Triangles per icon | ≤4000 | LOD system, max LOD 0 |
| Shader ALU per fragment | ≤80 ops | Precomputed env, simple Beer–Lambert |
| Texture memory (shared) | ≤2MB | 2× PMREM 64³ + thickness FBO |
| Texture per icon mesh | ≤64KB | Curvature baked to vertex color |
| JS bundle | ≤18KB gzip | Custom WebGL2, no engine |
| Init time | ≤50ms | Lazy: compile shaders on first icon |

### 7.2 Shared Context Architecture

**One WebGL2 context** for ALL icons on the page. Each icon owns a `<canvas>` element, but rendering happens by:

1. Binding the icon's canvas via `gl.bindFramebuffer` or by using `OffscreenCanvas` transfer
2. Drawing into it from the shared context

This avoids the hard browser limit of ~8–16 WebGL contexts.

**Fallback**: If OffscreenCanvas is unavailable (old Safari), use a single hidden canvas and `drawImage()` to copy results to each icon's visible canvas.

### 7.3 Offscreen Pause

```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    const icon = entry.target;
    if (entry.isIntersecting) {
      frameLoop.activate(icon);
    } else {
      frameLoop.deactivate(icon);
    }
  });
}, { threshold: 0 });
```

Icons scrolled offscreen consume zero GPU cycles.

### 7.4 Frame Scheduling

```javascript
// Single rAF drives all active icons
function tick(time) {
  for (const icon of activeIcons) {
    updateUniforms(icon, time);
    renderIcon(icon); // 2 draw calls
  }
  if (activeIcons.size > 0) {
    requestAnimationFrame(tick);
  }
}
```

rAF stops entirely when no icons are visible → zero idle GPU.

---

## 8. PROTOTYPE CODE SKELETON

### 8.1 Repository Structure

```
kuro-icon/
├── src/
│   ├── kuro-icon.js          # Web Component definition
│   ├── renderer.js           # SharedGL context + pipeline
│   ├── glass-material.js     # Shader source + compilation
│   ├── mesh-cache.js         # GLB loading + buffer management
│   ├── env-cache.js          # PMREM loading + theme switch
│   ├── frame-loop.js         # rAF scheduler
│   ├── interaction.js        # Hover, tilt, motion prefs
│   ├── poster.js             # SSR fallback utilities
│   └── constants.js          # Material defaults, size ranges
├── assets/
│   ├── meshes/               # Pre-beveled GLB files
│   │   ├── glasscube.glb
│   │   ├── settings.glb
│   │   └── ...
│   ├── env/                  # PMREM environment maps
│   │   ├── kuro-env-dark.ktx2
│   │   └── kuro-env-light.ktx2
│   └── posters/              # Pre-rendered fallback images
│       ├── glasscube-24.webp
│       └── ...
├── tools/
│   ├── bevel-meshes.py       # Blender headless beveling script
│   ├── generate-pmrem.js     # PMREM cubemap generator
│   └── render-posters.js     # Static poster renderer
├── dist/                     # Built output
├── demo/
│   └── index.html            # Example page
├── package.json
└── rollup.config.js
```

### 8.2 Key Shader: Stable Glass

See `glass-material.js` in the prototype code files (delivered separately).

### 8.3 Key Shader: Thickness Pass

See `glass-material.js` — the thickness vertex/fragment pair renders back-faces with front-depth subtraction.

---

## 9. QA / "LOOKS REAL" VALIDATION CHECKLIST

### Visual Fidelity

- [ ] **16px**: Icon reads as a rounded, tinted glass shape. No aliased edges.
- [ ] **24px**: Subtle refraction visible. Fresnel rim present. Smooth normals.
- [ ] **48px**: Full glass effect — refraction, absorption gradient, soft specular.
- [ ] **128px**: Publication-quality. Caustic approximation visible. No artifacts.

### Stability

- [ ] **Static**: Zero pixel change between frames when motion="none".
- [ ] **Hover**: Smooth tilt, no highlight popping, no edge shimmer.
- [ ] **Scroll**: No artifacts during rapid scroll. Pause works correctly.
- [ ] **Resize**: Icon re-renders cleanly at new size. No stretched frames.

### Backgrounds

- [ ] **Solid dark (#0a0a0e)**: Glass edge visible via Fresnel.
- [ ] **Solid light (#f5f5fa)**: Absorption tint reads correctly.
- [ ] **Gradient**: Refraction correctly distorts underlying gradient.
- [ ] **Image**: No banding or moire in refracted image content.

### Cross-Device

- [ ] **Desktop Chrome 120+**: Full quality, 60fps.
- [ ] **Desktop Firefox 120+**: Full quality, no shader compile issues.
- [ ] **Mobile Safari 17+**: Smooth, correct fallbacks for any missing features.
- [ ] **Mobile Chrome (Android)**: Acceptable quality on mid-range GPU.
- [ ] **iPad Safari**: Full quality at 120Hz if ProMotion available.

### Accessibility

- [ ] **prefers-reduced-motion**: All animation stops. Static poster shown.
- [ ] **prefers-contrast: more**: Glass opacity increased, clearer shape.
- [ ] **Screen reader**: Icon has aria-label, role="img".

### Performance

- [ ] **20 icons visible**: ≤4ms total GPU time per frame (measured via EXT_disjoint_timer_query).
- [ ] **Offscreen**: Zero draw calls for non-visible icons.
- [ ] **Memory**: ≤8MB total for 50 unique icon meshes + shared resources.

---

## 10. TRADEOFFS

| Decision | Chose | Over | Why |
|----------|-------|------|-----|
| Renderer | Custom WebGL2 | Three.js | 6× smaller bundle, icon-specific |
| Refraction | Dual-pass thickness | Ray-march | Stable, no jitter, fast |
| Env lighting | Prefiltered PMREM | Real-time probe | Deterministic, no sparkle |
| Geometry rounding | Offline bevel | Runtime SDF | Quality, zero runtime cost |
| Context sharing | Single shared GL | Per-icon context | Avoids browser limit |
| Dispersion | Off by default | Always on | Subtle effect, not worth perf at small sizes |
| WebGPU | Upgrade path only | Dual-target v1 | Coverage, complexity, maturity |
| Fallback | Static WebP poster | CSS gradient fake | Authentic, pre-rendered match |

---

## 11. NEXT 7 TASKS — EXECUTION PLAN

**Task 1: Scaffold + Build Pipeline** (Day 1)
- Init repo with Rollup config targeting ESM + IIFE bundles
- Set up asset pipeline directories
- Configure Blender headless script for mesh beveling

**Task 2: Core Renderer + Shared Context** (Day 1–2)
- Implement `renderer.js`: WebGL2 context creation, shared FBO pool
- Implement `frame-loop.js`: rAF scheduler with IntersectionObserver
- Validate single-context multi-canvas rendering on Safari

**Task 3: Glass Shader** (Day 2–3)
- Implement thickness pass (vertex + fragment)
- Implement glass composite pass (refraction + absorption + specular)
- Hardcode a test PMREM (solid color gradient) for development
- Validate: no flicker, no shimmer, specular clamped

**Task 4: Geometry Pipeline** (Day 3–4)
- Implement `mesh-cache.js`: minimal GLB parser (position + normal + curvature)
- Create `glasscube.glb` as first test mesh (Blender: superellipse cube, beveled, curvature baked)
- Implement LOD selection logic
- Implement deterministic framing algorithm

**Task 5: Web Component + DOM Integration** (Day 4–5)
- Implement `<kuro-icon>` custom element with full attribute API
- CSS baseline alignment
- SSR fallback slot mechanism
- Theme auto-detection (`prefers-color-scheme` + KURO tokens)

**Task 6: Interaction + Motion** (Day 5)
- Hover tilt with pointer tracking + clamping
- Idle rotation mode
- `prefers-reduced-motion` handling
- Validate all stability rules (angular velocity caps, highlight movement caps)

**Task 7: Demo Page + QA** (Day 6)
- Build demo page: 3 icons inline in paragraph text, 3 in a toolbar, dark/light toggle
- Run full validation checklist
- Profile on iPhone Safari + desktop Chrome
- Generate poster fallbacks for the demo icons
- Document any remaining issues for v1.1
