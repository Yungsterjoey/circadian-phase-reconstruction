"""
KURO::ICON — Mesh Bevel Pipeline (Blender Headless)

Usage:
  blender --background --python bevel-meshes.py -- --input mesh.glb --output beveled.glb

Processes:
  1. Import GLB
  2. Apply bevel modifier (rounded edges)
  3. Shade smooth
  4. Decimate to target triangle count
  5. Bake curvature to vertex color (R channel)
  6. Export GLB with curvature attribute

Requires: Blender 3.6+
"""

import bpy
import bmesh
import sys
import os
import math

# ─── Parse Args ───
argv = sys.argv
args_start = argv.index("--") + 1 if "--" in argv else len(argv)
args = argv[args_start:]

input_path = None
output_path = None
target_tris = 2000
bevel_width = 0.08
bevel_segments = 3

i = 0
while i < len(args):
    if args[i] == "--input" and i + 1 < len(args):
        input_path = args[i + 1]; i += 2
    elif args[i] == "--output" and i + 1 < len(args):
        output_path = args[i + 1]; i += 2
    elif args[i] == "--tris" and i + 1 < len(args):
        target_tris = int(args[i + 1]); i += 2
    elif args[i] == "--bevel-width" and i + 1 < len(args):
        bevel_width = float(args[i + 1]); i += 2
    else:
        i += 1

if not input_path or not output_path:
    print("Usage: blender --background --python bevel-meshes.py -- --input mesh.glb --output out.glb")
    sys.exit(1)

# ─── Clear Scene ───
bpy.ops.wm.read_factory_settings(use_empty=True)
for obj in bpy.data.objects:
    bpy.data.objects.remove(obj, do_unlink=True)

# ─── Import ───
print(f"[KURO] Importing: {input_path}")
bpy.ops.import_scene.gltf(filepath=input_path)

# Find the mesh object
mesh_obj = None
for obj in bpy.data.objects:
    if obj.type == 'MESH':
        mesh_obj = obj
        break

if not mesh_obj:
    print("[KURO] ERROR: No mesh found in GLB")
    sys.exit(1)

bpy.context.view_layer.objects.active = mesh_obj
mesh_obj.select_set(True)

# ─── Bevel Modifier ───
print(f"[KURO] Applying bevel: width={bevel_width}, segments={bevel_segments}")
bevel = mesh_obj.modifiers.new(name="KuroBevel", type='BEVEL')
bevel.width = bevel_width
bevel.segments = bevel_segments
bevel.limit_method = 'ANGLE'
bevel.angle_limit = math.radians(30)
bevel.miter_outer = 'MITER_ARC'
bevel.use_clamp_overlap = True
bpy.ops.object.modifier_apply(modifier=bevel.name)

# ─── Shade Smooth ───
print("[KURO] Shade smooth (auto-smooth angle: 45°)")
bpy.ops.object.shade_smooth()
mesh_obj.data.use_auto_smooth = True
mesh_obj.data.auto_smooth_angle = math.radians(45)

# ─── Decimate ───
tri_count = len(mesh_obj.data.polygons)
print(f"[KURO] Current tris: {tri_count}, target: {target_tris}")
if tri_count > target_tris:
    ratio = target_tris / tri_count
    dec = mesh_obj.modifiers.new(name="KuroDecimate", type='DECIMATE')
    dec.ratio = min(ratio, 1.0)
    bpy.ops.object.modifier_apply(modifier=dec.name)
    print(f"[KURO] After decimate: {len(mesh_obj.data.polygons)} tris")

# ─── Bake Curvature to Vertex Color ───
print("[KURO] Baking curvature to vertex colors")

# Ensure vertex color layer exists
if not mesh_obj.data.vertex_colors:
    mesh_obj.data.vertex_colors.new(name="Curvature")
color_layer = mesh_obj.data.vertex_colors["Curvature"]

# Compute curvature via bmesh
bm = bmesh.new()
bm.from_mesh(mesh_obj.data)
bm.verts.ensure_lookup_table()
bm.faces.ensure_lookup_table()

# Approximate curvature: measure angle defect at each vertex
# High curvature = sharp bevel edges = bright highlight
vert_curvature = {}
for vert in bm.verts:
    if len(vert.link_faces) < 2:
        vert_curvature[vert.index] = 0.0
        continue
    
    normals = [f.normal for f in vert.link_faces]
    total_deviation = 0.0
    count = 0
    for i_n in range(len(normals)):
        for j_n in range(i_n + 1, len(normals)):
            dot = max(-1.0, min(1.0, normals[i_n].dot(normals[j_n])))
            total_deviation += 1.0 - dot
            count += 1
    
    avg_dev = total_deviation / max(count, 1)
    # Normalize: 0 = flat, 1 = very curved
    curvature = min(1.0, avg_dev * 4.0)
    vert_curvature[vert.index] = curvature

bm.free()

# Write to vertex colors
for poly in mesh_obj.data.polygons:
    for loop_idx in poly.loop_indices:
        vert_idx = mesh_obj.data.loops[loop_idx].vertex_index
        c = vert_curvature.get(vert_idx, 0.0)
        color_layer.data[loop_idx].color = (c, 0.0, 0.0, 1.0)

# ─── Export ───
print(f"[KURO] Exporting: {output_path}")
bpy.ops.export_scene.gltf(
    filepath=output_path,
    export_format='GLB',
    export_colors=True,
    export_normals=True,
    export_apply=True,
)

print(f"[KURO] Done. Final tris: {len(mesh_obj.data.polygons)}")
