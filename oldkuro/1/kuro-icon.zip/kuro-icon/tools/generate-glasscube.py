"""
KURO::ICON — Generate Glass Cube Mesh

Creates a superellipse-based rounded cube (squircle cube) as the
iconic KURO glasscube icon mesh. Exports pre-beveled, curvature-baked GLB.

Usage:
  blender --background --python generate-glasscube.py -- --output assets/meshes/glasscube.glb

The resulting mesh has:
  - Fully rounded edges and corners (no sharp geometry)
  - Smooth normals with auto-smooth
  - Curvature baked to vertex color (R channel)
  - ~2000 triangles
"""

import bpy
import bmesh
import math
import sys

# ─── Parse Args ───
argv = sys.argv
args_start = argv.index("--") + 1 if "--" in argv else len(argv)
args = argv[args_start:]

output_path = "glasscube.glb"
for i, a in enumerate(args):
    if a == "--output" and i + 1 < len(args):
        output_path = args[i + 1]

# ─── Clear ───
bpy.ops.wm.read_factory_settings(use_empty=True)
for obj in bpy.data.objects:
    bpy.data.objects.remove(obj, do_unlink=True)

# ─── Create Rounded Cube ───
# Method: Start with a cube, apply subdivision + cast-to-sphere blend
# to get a superellipse-like rounded form.

bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, 0, 0))
cube = bpy.context.active_object
cube.name = "GlassCube"

# Subdivision for smooth geometry
sub = cube.modifiers.new(name="Sub", type='SUBSURF')
sub.levels = 3
sub.render_levels = 3
sub.subdivision_type = 'CATMULL_CLARK'
bpy.ops.object.modifier_apply(modifier=sub.name)

# Cast modifier to round corners (blend toward sphere)
# Factor < 1.0 keeps it cube-like but rounds corners
cast = cube.modifiers.new(name="Round", type='CAST')
cast.cast_type = 'SPHERE'
cast.factor = 0.15  # subtle rounding — keeps cube identity
bpy.ops.object.modifier_apply(modifier=cast.name)

# Additional bevel for edge definition
bevel = cube.modifiers.new(name="Bevel", type='BEVEL')
bevel.width = 0.04
bevel.segments = 2
bevel.limit_method = 'ANGLE'
bevel.angle_limit = math.radians(25)
bevel.miter_outer = 'MITER_ARC'
bpy.ops.object.modifier_apply(modifier=bevel.name)

# Shade smooth
bpy.ops.object.shade_smooth()
cube.data.use_auto_smooth = True
cube.data.auto_smooth_angle = math.radians(45)

# Decimate to target
tri_count = len(cube.data.polygons)
target = 2000
if tri_count > target:
    dec = cube.modifiers.new(name="Dec", type='DECIMATE')
    dec.ratio = target / tri_count
    bpy.ops.object.modifier_apply(modifier=dec.name)

# ─── Bake Curvature ───
if not cube.data.vertex_colors:
    cube.data.vertex_colors.new(name="Curvature")
color_layer = cube.data.vertex_colors["Curvature"]

bm = bmesh.new()
bm.from_mesh(cube.data)
bm.verts.ensure_lookup_table()
bm.faces.ensure_lookup_table()

vert_curvature = {}
for vert in bm.verts:
    if len(vert.link_faces) < 2:
        vert_curvature[vert.index] = 0.0
        continue
    normals = [f.normal for f in vert.link_faces]
    total_dev = 0.0
    count = 0
    for i_n in range(len(normals)):
        for j_n in range(i_n + 1, len(normals)):
            dot = max(-1.0, min(1.0, normals[i_n].dot(normals[j_n])))
            total_dev += 1.0 - dot
            count += 1
    avg_dev = total_dev / max(count, 1)
    vert_curvature[vert.index] = min(1.0, avg_dev * 5.0)

bm.free()

for poly in cube.data.polygons:
    for loop_idx in poly.loop_indices:
        vert_idx = cube.data.loops[loop_idx].vertex_index
        c = vert_curvature.get(vert_idx, 0.0)
        color_layer.data[loop_idx].color = (c, 0.0, 0.0, 1.0)

# ─── Export ───
print(f"[KURO] Exporting glasscube: {output_path}")
print(f"[KURO] Triangles: {len(cube.data.polygons)}")

bpy.ops.export_scene.gltf(
    filepath=output_path,
    export_format='GLB',
    export_colors=True,
    export_normals=True,
    export_apply=True,
)

print("[KURO] Done — glasscube.glb ready")
