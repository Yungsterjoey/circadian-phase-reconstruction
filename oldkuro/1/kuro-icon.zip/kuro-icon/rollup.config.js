import terser from '@rollup/plugin-terser';

export default {
  input: 'src/kuro-icon.js',
  output: [
    {
      file: 'dist/kuro-icon.esm.js',
      format: 'esm',
      sourcemap: true,
    },
    {
      file: 'dist/kuro-icon.cjs',
      format: 'cjs',
      sourcemap: true,
    },
    {
      file: 'dist/kuro-icon.iife.js',
      format: 'iife',
      name: 'KuroIcon',
      sourcemap: true,
    },
  ],
  plugins: [
    terser({
      compress: {
        passes: 2,
        pure_getters: true,
        unsafe_math: true,
      },
      mangle: {
        properties: {
          regex: /^_/, // only mangle private props
        },
      },
    }),
  ],
};
