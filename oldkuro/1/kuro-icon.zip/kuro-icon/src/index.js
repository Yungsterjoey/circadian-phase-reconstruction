/**
 * KURO::ICON — Package Entry Point
 * 
 * import { renderIcon } from '@kuro/icon';
 * import '@kuro/icon'; // auto-registers <kuro-icon>
 */

export { KuroIconElement, renderIcon } from './kuro-icon.js';
export { IconRenderer } from './renderer.js';
export { GLASS_DEFAULTS, MOTION, FRAME } from './constants.js';
