#!/usr/bin/env bash
set -euo pipefail

# ═══════════════════════════════════════════════════════════════════════════
# KURO OS v6.3 — DEPLOYMENT SCRIPT (HARDENED)
# Sovereign Agent Architecture — Multi-GPU Aware
#
# Target: TensorDock 2×RTX 5090, 16 cores, 64GB RAM, 200GB disk
# Usage:  sudo KURO_PROFILE=enterprise bash deploy.sh
# ═══════════════════════════════════════════════════════════════════════════

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
step() { echo -e "\n${GREEN}[STEP $1]${NC} $2"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
fail() { echo -e "${RED}[FAIL]${NC} $1"; exit 1; }

DEPLOY_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="/opt/kuro/core"
DATA_DIR="/var/lib/kuro"
KEY_DIR="/etc/kuro"
PROFILE="${KURO_PROFILE:-lab}"

echo -e "\n  ${CYAN}KURO OS v6.3 — HARDENED SOVEREIGN AGENT${NC}"
echo "  ════════════════════════════════════════════"
echo "  Profile: $PROFILE"
echo "  Source:  $DEPLOY_DIR"
echo "  Target:  $INSTALL_DIR"
echo "  Data:    $DATA_DIR"
echo ""

# ── Step 1: Preflight ─────────────────────────────────────────────────────
step 1 "Preflight checks"
[[ $EUID -ne 0 ]] && fail "Run as root"
command -v node >/dev/null || fail "Node.js not found"
command -v ollama >/dev/null || fail "Ollama not found"
NODE_VER=$(node -v | sed 's/v//' | cut -d. -f1)
[[ $NODE_VER -lt 18 ]] && fail "Node.js 18+ required (got $NODE_VER)"
echo "  Node: $(node -v), Ollama: $(ollama -v 2>/dev/null || echo 'installed')"

# GPU detection
GPU_COUNT=0
if command -v nvidia-smi &>/dev/null; then
  GPU_COUNT=$(nvidia-smi --query-gpu=count --format=csv,noheader | head -1 | tr -d ' ')
  GPU_INFO=$(nvidia-smi --query-gpu=name,memory.total --format=csv,noheader | head -5)
  TOTAL_VRAM=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits | awk '{s+=$1} END {print s}')
  echo -e "  GPU:  ${GREEN}${GPU_COUNT}× detected${NC} (${TOTAL_VRAM}MB total VRAM)"
  echo "$GPU_INFO" | while IFS= read -r line; do echo "        $line"; done
else
  warn "nvidia-smi not found — GPU acceleration unavailable"
fi

# ── Step 2: System user ───────────────────────────────────────────────────
step 2 "System user"
if ! id -u kuro &>/dev/null; then
  useradd -r -s /usr/sbin/nologin -d /opt/kuro -m kuro
  echo "  Created user: kuro"
else
  echo "  User kuro exists"
fi

# ── Step 3: Directories ──────────────────────────────────────────────────
step 3 "Directories"
for d in "$INSTALL_DIR" "$DATA_DIR"/{db,sessions,uploads,vectors,docs,patches,audit} "$KEY_DIR"; do
  mkdir -p "$d"
done
chown -R kuro:kuro "$DATA_DIR"
chmod 700 "$KEY_DIR"
echo "  Created: $INSTALL_DIR, $DATA_DIR/*, $KEY_DIR"

# ── Step 4a: Audit signing keys ──────────────────────────────────────────
step "4a" "Audit signing keys"
if [[ ! -f "$KEY_DIR/audit.key" ]]; then
  node -e "
const crypto = require('crypto');
const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
const keyData = {
  public: publicKey.export({ format: 'der', type: 'spki' }).toString('base64'),
  private: privateKey.export({ format: 'der', type: 'pkcs8' }).toString('base64'),
  created: new Date().toISOString(),
  algorithm: 'Ed25519'
};
require('fs').writeFileSync('$KEY_DIR/audit.key', JSON.stringify(keyData, null, 2));
"
  chmod 600 "$KEY_DIR/audit.key"
  chown root:root "$KEY_DIR/audit.key"
  echo "  Generated Ed25519 signing key (root-only: $KEY_DIR/audit.key)"
else
  echo "  Signing key exists"
fi

# ── Step 4b: Auth tokens ─────────────────────────────────────────────────
step "4b" "Auth tokens"
if [[ ! -f "$KEY_DIR/tokens.json" ]]; then
  OPERATOR_TOKEN=$(openssl rand -base64 32 | tr -d '/+=' | head -c 32)
  ANALYST_TOKEN=$(openssl rand -base64 32 | tr -d '/+=' | head -c 32)
  VIEWER_TOKEN=$(openssl rand -base64 32 | tr -d '/+=' | head -c 32)
  cat > "$KEY_DIR/tokens.json" << TOKEOF
{
  "_comment": "KURO OS v6.3 token store. Root-only.",
  "created": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "tokens": {
    "$OPERATOR_TOKEN": {
      "name": "Operator",
      "userId": "operator",
      "role": "operator",
      "created": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    },
    "$ANALYST_TOKEN": {
      "name": "Analyst",
      "userId": "analyst",
      "role": "analyst",
      "created": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    },
    "$VIEWER_TOKEN": {
      "name": "Viewer",
      "userId": "viewer",
      "role": "viewer",
      "created": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    }
  }
}
TOKEOF
  chmod 600 "$KEY_DIR/tokens.json"
  chown root:root "$KEY_DIR/tokens.json"
  echo -e "  ${GREEN}Generated auth tokens:${NC}"
  echo "  ┌──────────────────────────────────────────────────"
  echo "  │ OPERATOR: $OPERATOR_TOKEN"
  echo "  │ ANALYST:  $ANALYST_TOKEN"
  echo "  │ VIEWER:   $VIEWER_TOKEN"
  echo "  └──────────────────────────────────────────────────"
  echo -e "  ${RED}SAVE THESE NOW — they won't be shown again.${NC}"
else
  echo "  Token file exists"
fi

# ── Step 5: Dependencies ─────────────────────────────────────────────────
step 5 "Dependencies"
cd "$DEPLOY_DIR"
if [[ -f package.json ]]; then
  npm install --production 2>&1 | tail -1
  echo "  Installed"
else
  warn "No package.json — skipping npm install"
fi

# ── Step 6: Build frontend ───────────────────────────────────────────────
step 6 "Build frontend"
if [[ -f vite.config.js ]] || [[ -f vite.config.ts ]]; then
  npx vite build 2>&1 | tail -3
  [[ -d dist ]] && echo "  Built: dist/" || warn "Build may have failed"
elif [[ -d dist ]]; then
  echo "  Pre-built dist/ found"
else
  warn "No frontend build config — skipping"
fi

# ── Step 7: Backup + Install ─────────────────────────────────────────────
step 7 "Install to $INSTALL_DIR"
if [[ -f "$INSTALL_DIR/server.cjs" ]]; then
  BAK="$INSTALL_DIR/../core.bak.$(date +%Y%m%d_%H%M%S)"
  cp -a "$INSTALL_DIR" "$BAK"
  echo "  Backed up to: $BAK"
fi

cp "$DEPLOY_DIR/server.cjs" "$INSTALL_DIR/"
cp -r "$DEPLOY_DIR/layers" "$INSTALL_DIR/"
[[ -d "$DEPLOY_DIR/shadow" ]] && cp -r "$DEPLOY_DIR/shadow" "$INSTALL_DIR/"
[[ -d "$DEPLOY_DIR/dist" ]] && cp -r "$DEPLOY_DIR/dist" "$INSTALL_DIR/"
[[ -d "$DEPLOY_DIR/node_modules" ]] && cp -r "$DEPLOY_DIR/node_modules" "$INSTALL_DIR/"
[[ -f "$DEPLOY_DIR/package.json" ]] && cp "$DEPLOY_DIR/package.json" "$INSTALL_DIR/"
[[ -d "$DEPLOY_DIR/src" ]] && cp -r "$DEPLOY_DIR/src" "$INSTALL_DIR/"

chown -R kuro:kuro "$INSTALL_DIR"
echo "  Installed: server.cjs, layers/"

# ── Step 8: Multi-GPU Ollama tuning ──────────────────────────────────────
step 8 "Ollama GPU configuration"
if [[ $GPU_COUNT -ge 1 ]]; then
  mkdir -p /etc/systemd/system/ollama.service.d

  # Scale parallel slots and loaded models by GPU count
  NUM_PARALLEL=$((GPU_COUNT * 2))
  MAX_LOADED=$((GPU_COUNT + 1))

  cat > /etc/systemd/system/ollama.service.d/gpu.conf << GPUEOF
[Service]
# KURO OS v6.3 — Multi-GPU Ollama tuning
# GPUs detected: $GPU_COUNT (${TOTAL_VRAM:-unknown}MB total VRAM)
Environment="CUDA_VISIBLE_DEVICES=$(seq -s, 0 $((GPU_COUNT-1)))"
Environment="OLLAMA_NUM_PARALLEL=$NUM_PARALLEL"
Environment="OLLAMA_MAX_LOADED_MODELS=$MAX_LOADED"
Environment="OLLAMA_FLASH_ATTENTION=1"
GPUEOF

  systemctl daemon-reload
  systemctl restart ollama
  sleep 3
  echo "  Ollama configured: ${GPU_COUNT} GPUs, ${NUM_PARALLEL} parallel slots, ${MAX_LOADED} models warm"
  echo "  CUDA_VISIBLE_DEVICES=$(seq -s, 0 $((GPU_COUNT-1)))"
else
  echo "  CPU-only mode (no GPU override)"
fi

# ── Step 9: Model provisioning ───────────────────────────────────────────
step 9 "Model provisioning"
MODELS_NEEDED=("nomic-embed-text")

# Choose brain model based on VRAM
if [[ ${TOTAL_VRAM:-0} -ge 48000 ]]; then
  echo "  VRAM: ${TOTAL_VRAM}MB — provisioning large models"
  # 64GB VRAM: can fit 46B + embed + room for a 2nd model
  MODELS_NEEDED+=("huihui_ai/qwen3-abliterated:32b")
  echo "  Primary brain: qwen3-abliterated:32b (~20GB)"
elif [[ ${TOTAL_VRAM:-0} -ge 20000 ]]; then
  MODELS_NEEDED+=("huihui_ai/qwen3-abliterated:14b")
  echo "  Primary brain: qwen3-abliterated:14b (~10GB)"
else
  MODELS_NEEDED+=("huihui_ai/qwen3-abliterated:8b")
  echo "  Primary brain: qwen3-abliterated:8b (~5GB)"
fi

for m in "${MODELS_NEEDED[@]}"; do
  if ollama list 2>/dev/null | grep -q "$(echo $m | cut -d: -f1)"; then
    echo "  ✓ $m already pulled"
  else
    echo "  Pulling $m ..."
    ollama pull "$m" 2>&1 | tail -1
  fi
done

# Create kuro-core modelfile if it doesn't exist
if ! ollama list 2>/dev/null | grep -q "kuro-core"; then
  echo "  Creating kuro-core modelfile..."
  # Use the largest model we just pulled
  if [[ ${TOTAL_VRAM:-0} -ge 48000 ]]; then
    BASE="huihui_ai/qwen3-abliterated:32b"
  elif [[ ${TOTAL_VRAM:-0} -ge 20000 ]]; then
    BASE="huihui_ai/qwen3-abliterated:14b"
  else
    BASE="huihui_ai/qwen3-abliterated:8b"
  fi

  cat > /tmp/kuro-core.modelfile << MFEOF
FROM $BASE
PARAMETER num_ctx 40960
PARAMETER temperature 0.7
SYSTEM """You are KURO, a sovereign AI intelligence running entirely on-premises. You are direct, capable, and never robotic. Address the user as Operator when appropriate."""
MFEOF
  ollama create kuro-core -f /tmp/kuro-core.modelfile 2>&1 | tail -1
  rm -f /tmp/kuro-core.modelfile
  echo "  ✓ kuro-core created from $BASE"
else
  echo "  ✓ kuro-core exists"
fi

echo "  Models ready: $(ollama list 2>/dev/null | grep -c '^[a-z]') loaded"

# ── Step 10: systemd service ─────────────────────────────────────────────
step 10 "systemd service"
cat > /etc/systemd/system/kuro-core.service << SVCEOF
[Unit]
Description=KURO OS v6.3 — Hardened Sovereign Agent
After=network.target ollama.service
Wants=ollama.service

[Service]
Type=simple
User=kuro
Group=kuro
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/node $INSTALL_DIR/server.cjs

Environment=NODE_ENV=production
Environment=KURO_PORT=3100
Environment=KURO_DATA=$DATA_DIR
Environment=KURO_CODE=/opt/kuro
Environment=KURO_SANDBOX=/opt/kuro
Environment=KURO_AUDIT_KEY=$KEY_DIR/audit.key
Environment=KURO_TOKEN_FILE=$KEY_DIR/tokens.json
Environment=KURO_PROFILE=$PROFILE
Environment=OLLAMA_URL=http://localhost:11434

# Security hardening
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
ReadWritePaths=$DATA_DIR /var/log/kuro
ReadOnlyPaths=$KEY_DIR

Restart=on-failure
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=kuro-core

[Install]
WantedBy=multi-user.target
SVCEOF

systemctl daemon-reload
systemctl enable kuro-core
echo "  Service installed (profile: $PROFILE)"

# ── Step 11: Start ───────────────────────────────────────────────────────
step 11 "Start service"
systemctl restart kuro-core
sleep 3

IP=$(hostname -I | awk '{print $1}')

if systemctl is-active kuro-core &>/dev/null; then
  echo -e "  ${GREEN}kuro-core is running${NC}"
  sleep 2
  HEALTH=$(curl -sf http://localhost:3100/api/health 2>/dev/null || echo '{"status":"pending"}')
  echo "  Health: $HEALTH" | head -c 200
else
  echo -e "  ${RED}Service failed to start${NC}"
  journalctl -u kuro-core --no-pager -n 20
fi

echo -e "\n  ${CYAN}════════════════════════════════════════════${NC}"
echo -e "  ${GREEN}KURO OS v6.3 deployment complete${NC}"
echo "  ────────────────────────────────────────────"
echo "  Profile:  $PROFILE"
echo "  GPUs:     $GPU_COUNT (${TOTAL_VRAM:-0}MB VRAM)"
echo "  Web:      http://${IP}:3100"
echo "  Health:   http://${IP}:3100/api/health"
echo "  Models:   http://${IP}:3100/api/models"
echo "  Audit:    http://${IP}:3100/api/audit/verify"
echo "  Logs:     journalctl -u kuro-core -f"
echo -e "  ${CYAN}════════════════════════════════════════════${NC}\n"
