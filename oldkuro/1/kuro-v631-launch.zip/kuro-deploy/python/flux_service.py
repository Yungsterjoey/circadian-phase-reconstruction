"""
KURO::VISION — FLUX Generation Service
Python sidecar for image generation + text compositing.
Runs on port 3200, called by Node.js orchestrator.

Requires: torch, diffusers, transformers, accelerate, Pillow, flask, optimum-quanto
GPU: ~18GB VRAM for FLUX.1-dev int8

v6.2: Writes only to /var/lib/kuro/vision/. No shell exec.
"""

import os
import sys
import json
import time
import io
import base64
import hashlib
import gc
import threading
from pathlib import Path

from flask import Flask, request, jsonify

app = Flask(__name__)

# ─── Config ───────────────────────────────────────────────────────────────
DATA_DIR = os.environ.get('KURO_DATA_DIR', '/var/lib/kuro')
VISION_DIR = os.path.join(DATA_DIR, 'vision')
os.makedirs(VISION_DIR, exist_ok=True)

_pipe = None
_pipe_lock = threading.Lock()
_loaded = False


# ─── Model Loading ────────────────────────────────────────────────────────
def load_flux():
    global _pipe, _loaded
    if _loaded:
        return True
    with _pipe_lock:
        if _loaded:
            return True
        try:
            import torch
            from diffusers import FluxPipeline

            print("[FLUX] Loading FLUX.1-dev with CPU offload...", flush=True)
            _pipe = FluxPipeline.from_pretrained(
                "black-forest-labs/FLUX.1-dev",
                torch_dtype=torch.bfloat16
            )

            # int8 quantize transformer to fit in ~18GB
            try:
                from optimum.quanto import qint8, freeze
                print("[FLUX] Quantizing transformer to int8...", flush=True)
                _pipe.transformer = qint8(_pipe.transformer)
                freeze(_pipe.transformer)
            except ImportError:
                print("[FLUX] optimum-quanto not available, using CPU offload only", flush=True)

            _pipe.enable_model_cpu_offload()
            _loaded = True
            print("[FLUX] Model loaded and ready", flush=True)
            return True
        except Exception as e:
            print(f"[FLUX] Load failed: {e}", flush=True)
            return False


def unload_flux():
    global _pipe, _loaded
    with _pipe_lock:
        if _pipe:
            del _pipe
            _pipe = None
        _loaded = False
        gc.collect()
        try:
            import torch
            torch.cuda.empty_cache()
        except Exception:
            pass
        print("[FLUX] Unloaded", flush=True)


# ─── Routes ───────────────────────────────────────────────────────────────

@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'ok',
        'model_loaded': _loaded,
        'vision_dir': VISION_DIR
    })


@app.route('/generate', methods=['POST'])
def generate():
    data = request.json or {}
    prompt = data.get('prompt', '')
    negative = data.get('negative_prompt', '')
    width = min(data.get('width', 1024), 2048)
    height = min(data.get('height', 1024), 2048)
    steps = min(data.get('steps', 28), 50)
    guidance = data.get('guidance_scale', 3.5)
    seed = data.get('seed')
    request_id = data.get('request_id', 'unknown')

    if not prompt.strip():
        return jsonify({'error': 'Empty prompt'}), 400

    if not load_flux():
        return jsonify({'error': 'FLUX model failed to load'}), 503

    import torch

    if seed is not None:
        generator = torch.Generator("cpu").manual_seed(int(seed))
    else:
        seed = int(torch.randint(0, 2**32, (1,)).item())
        generator = torch.Generator("cpu").manual_seed(seed)

    t0 = time.time()
    try:
        with _pipe_lock:
            result = _pipe(
                prompt=prompt,
                negative_prompt=negative if negative else None,
                width=width,
                height=height,
                num_inference_steps=steps,
                guidance_scale=guidance,
                generator=generator,
                output_type="pil"
            )

        image = result.images[0]
        elapsed = time.time() - t0

        # Save to fenced path
        ts = int(time.time())
        filename = f"vision_{request_id}_{ts}.png"
        filepath = os.path.join(VISION_DIR, filename)
        image.save(filepath, "PNG")

        # Base64 for inline display
        buf = io.BytesIO()
        image.save(buf, format="PNG")
        b64 = base64.b64encode(buf.getvalue()).decode()
        img_hash = hashlib.sha256(buf.getvalue()).hexdigest()

        return jsonify({
            'success': True,
            'path': filepath,
            'filename': filename,
            'base64': b64,
            'hash': img_hash,
            'seed': seed,
            'elapsed': round(elapsed, 2),
            'dimensions': f"{width}x{height}",
            'steps': steps
        })
    except Exception as e:
        return jsonify({'error': str(e), 'success': False}), 500


@app.route('/composite-text', methods=['POST'])
def composite_text():
    """Overlay pixel-perfect text onto generated image.
    RT-03 fix: deterministic text rendering via Pillow, not diffusion.
    """
    from PIL import Image, ImageDraw, ImageFont

    data = request.json or {}
    img_b64 = data.get('image_base64')
    text_boxes = data.get('text_boxes', [])
    request_id = data.get('request_id', 'unknown')

    if not img_b64 or not text_boxes:
        return jsonify({'error': 'Missing image_base64 or text_boxes', 'success': False}), 400

    try:
        # Decode base image
        img_bytes = base64.b64decode(img_b64)
        image = Image.open(io.BytesIO(img_bytes)).convert('RGBA')
        txt_layer = Image.new('RGBA', image.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(txt_layer)

        for box in text_boxes:
            text = box.get('text', '')
            x = int(box.get('x', 0))
            y = int(box.get('y', 0))
            max_w = int(box.get('max_width', image.width - x))
            font_size = int(box.get('font_size', 32))
            color = box.get('color', '#FFFFFF')
            align = box.get('align', 'left')
            style = box.get('style', 'regular')

            # Load font — try system fonts, fallback to default
            font = None
            font_paths = [
                f'/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
                f'/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
                f'/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
            ]
            if style != 'bold':
                font_paths = [p.replace('-Bold', '') for p in font_paths] + font_paths

            for fp in font_paths:
                if os.path.exists(fp):
                    try:
                        font = ImageFont.truetype(fp, font_size)
                        break
                    except Exception:
                        continue
            if font is None:
                font = ImageFont.load_default()

            # Text wrapping
            words = text.split()
            lines = []
            current_line = ""
            for word in words:
                test = f"{current_line} {word}".strip()
                bbox = draw.textbbox((0, 0), test, font=font)
                tw = bbox[2] - bbox[0]
                if tw <= max_w:
                    current_line = test
                else:
                    if current_line:
                        lines.append(current_line)
                    current_line = word
            if current_line:
                lines.append(current_line)

            # Draw with optional shadow for readability
            line_height = font_size + 4
            for i, line in enumerate(lines):
                lx = x
                ly = y + (i * line_height)

                # Alignment
                bbox = draw.textbbox((0, 0), line, font=font)
                tw = bbox[2] - bbox[0]
                if align == 'center':
                    lx = x + (max_w - tw) // 2
                elif align == 'right':
                    lx = x + max_w - tw

                # Drop shadow for contrast
                draw.text((lx + 2, ly + 2), line, fill='#000000', font=font)
                draw.text((lx, ly), line, fill=color, font=font)

        # Composite
        final = Image.alpha_composite(image, txt_layer).convert('RGB')

        # Save + encode
        ts = int(time.time())
        filename = f"vision_{request_id}_comp_{ts}.png"
        filepath = os.path.join(VISION_DIR, filename)
        final.save(filepath, "PNG")

        buf = io.BytesIO()
        final.save(buf, format="PNG")
        b64 = base64.b64encode(buf.getvalue()).decode()
        img_hash = hashlib.sha256(buf.getvalue()).hexdigest()

        return jsonify({
            'success': True,
            'path': filepath,
            'filename': filename,
            'base64': b64,
            'hash': img_hash
        })
    except Exception as e:
        return jsonify({'error': str(e), 'success': False}), 500


@app.route('/unload', methods=['POST'])
def unload():
    """Called by GPU mutex during release phase."""
    unload_flux()
    return jsonify({'success': True, 'message': 'FLUX unloaded'})


# ─── Entry ────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    port = int(os.environ.get('FLUX_PORT', 3200))
    print(f"[FLUX] Starting on port {port}", flush=True)
    app.run(host='127.0.0.1', port=port, threaded=False)
