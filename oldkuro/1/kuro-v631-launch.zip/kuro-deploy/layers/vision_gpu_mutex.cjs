/**
 * KURO::VISION — GPU Mutex Controller
 * 
 * Problem: kuro-core (~28GB) + vision pipeline (~23GB) cannot coexist on 32GB VRAM.
 * Solution: Exclusive GPU mode — evict kuro-core before vision, restore after.
 * 
 * v6.2 compliance: All state changes audited, no shell exec (uses Ollama HTTP API).
 */

const axios = require('axios');

const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434';

// ─── State ───────────────────────────────────────────────────────────────
let _locked = false;
let _lockHolder = null;
let _lockTime = null;
let _evictedModels = [];
const _queue = [];
const LOCK_TIMEOUT_MS = 300000; // 5 min max per vision job

// ─── Ollama Model Control ────────────────────────────────────────────────

async function listLoadedModels() {
  try {
    const { data } = await axios.get(`${OLLAMA_URL}/api/ps`, { timeout: 5000 });
    return (data.models || []).map(m => m.name);
  } catch (e) {
    console.error('[GPU_MUTEX] Failed to list models:', e.message);
    return [];
  }
}

async function evictModel(modelName) {
  try {
    await axios.post(`${OLLAMA_URL}/api/generate`, {
      model: modelName,
      keep_alive: 0
    }, { timeout: 10000 });
    return true;
  } catch (e) {
    console.error(`[GPU_MUTEX] Evict ${modelName} failed:`, e.message);
    return false;
  }
}

async function preloadModel(modelName) {
  try {
    await axios.post(`${OLLAMA_URL}/api/generate`, {
      model: modelName,
      keep_alive: '5m',
      prompt: ''
    }, { timeout: 60000 });
    return true;
  } catch (e) {
    console.error(`[GPU_MUTEX] Preload ${modelName} failed:`, e.message);
    return false;
  }
}

// ─── Acquire / Release ───────────────────────────────────────────────────

async function acquire(requestId, auditFn) {
  if (_locked) {
    // Check for stale lock
    if (_lockTime && (Date.now() - _lockTime > LOCK_TIMEOUT_MS)) {
      console.warn(`[GPU_MUTEX] Stale lock from ${_lockHolder}, forcing release`);
      await release(_lockHolder, auditFn);
    } else {
      return {
        acquired: false,
        reason: `GPU locked by request ${_lockHolder}`,
        queuePosition: _queue.length
      };
    }
  }

  _locked = true;
  _lockHolder = requestId;
  _lockTime = Date.now();

  // Evict all loaded models (primarily kuro-core)
  const loaded = await listLoadedModels();
  _evictedModels = [...loaded];

  for (const model of loaded) {
    await evictModel(model);
  }

  // Wait for VRAM to clear
  await new Promise(r => setTimeout(r, 2000));

  if (auditFn) {
    auditFn({
      agent: 'vision',
      action: 'gpu_acquire',
      meta: { requestId, evicted: _evictedModels }
    });
  }

  return { acquired: true, evicted: _evictedModels };
}

async function release(requestId, auditFn) {
  if (!_locked || _lockHolder !== requestId) {
    return { released: false, reason: 'Not lock holder' };
  }

  // Evict vision models
  const loaded = await listLoadedModels();
  for (const model of loaded) {
    await evictModel(model);
  }

  await new Promise(r => setTimeout(r, 1500));

  // Restore kuro-core if it was evicted
  const restoreTargets = _evictedModels.filter(m =>
    m.includes('kuro-core') || m.includes('huihui')
  );

  for (const model of restoreTargets) {
    await preloadModel(model);
  }

  if (auditFn) {
    auditFn({
      agent: 'vision',
      action: 'gpu_release',
      meta: { requestId, restored: restoreTargets, elapsed: Date.now() - _lockTime }
    });
  }

  _locked = false;
  _lockHolder = null;
  _lockTime = null;
  _evictedModels = [];

  return { released: true, restored: restoreTargets };
}

function isLocked() {
  return { locked: _locked, holder: _lockHolder, elapsed: _lockTime ? Date.now() - _lockTime : 0 };
}

module.exports = { acquire, release, isLocked, evictModel, preloadModel, listLoadedModels };
