/**
 * KURO OS v6.0 — Desktop Environment
 * Liquid Glass + Window Manager + Dock
 */
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useOSStore } from './stores/osStore';
import DesktopBackground from './components/DesktopBackground';
import KuroChatApp from './components/apps/KuroChatApp';
import PaxSilicaApp from './components/apps/PaxSilicaApp';

const APP_COMPONENTS = {
  KuroChatApp: KuroChatApp,
  PaxSilicaApp: PaxSilicaApp,
};

// ═══════════════════════════════════════════════════════════════════════════
// APP WINDOW — Draggable, resizable glass container
// ═══════════════════════════════════════════════════════════════════════════
function AppWindow({ appId, children }) {
  const win = useOSStore(s => s.windows[appId]);
  const app = useOSStore(s => s.apps.find(a => a.id === appId));
  const { closeApp, minimizeApp, maximizeApp, focusWindow, updateWindowPosition, updateWindowSize } = useOSStore();
  const dragRef = useRef(null);
  const resizeRef = useRef(null);

  const onDragStart = useCallback((e) => {
    if (win?.isMaximized) return;
    e.preventDefault();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    dragRef.current = { startX: clientX - (win?.x || 0), startY: clientY - (win?.y || 0) };
    focusWindow(appId);

    const onMove = (ev) => {
      const cx = ev.touches ? ev.touches[0].clientX : ev.clientX;
      const cy = ev.touches ? ev.touches[0].clientY : ev.clientY;
      updateWindowPosition(appId, cx - dragRef.current.startX, cy - dragRef.current.startY);
    };
    const onEnd = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onEnd);
      document.removeEventListener('touchmove', onMove);
      document.removeEventListener('touchend', onEnd);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onEnd);
    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onEnd);
  }, [appId, win, focusWindow, updateWindowPosition]);

  const onResizeStart = useCallback((e) => {
    if (win?.isMaximized) return;
    e.preventDefault(); e.stopPropagation();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    resizeRef.current = { startX: clientX, startY: clientY, startW: win?.width || 800, startH: win?.height || 600 };
    focusWindow(appId);

    const onMove = (ev) => {
      const cx = ev.touches ? ev.touches[0].clientX : ev.clientX;
      const cy = ev.touches ? ev.touches[0].clientY : ev.clientY;
      const newW = Math.max(400, resizeRef.current.startW + (cx - resizeRef.current.startX));
      const newH = Math.max(300, resizeRef.current.startH + (cy - resizeRef.current.startY));
      updateWindowSize(appId, newW, newH);
    };
    const onEnd = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onEnd);
      document.removeEventListener('touchmove', onMove);
      document.removeEventListener('touchend', onEnd);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onEnd);
    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onEnd);
  }, [appId, win, focusWindow, updateWindowSize]);

  if (!win || !win.isOpen || win.isMinimized) return null;

  const style = win.isMaximized
    ? { position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', zIndex: win.zIndex }
    : { position: 'absolute', top: win.y, left: win.x, width: win.width, height: win.height, zIndex: win.zIndex };

  return (
    <div className="app-window" style={style} onMouseDown={() => focusWindow(appId)} onTouchStart={() => focusWindow(appId)}>
      <div className="window-titlebar" onMouseDown={onDragStart} onTouchStart={onDragStart}>
        <div className="traffic-lights">
          <button className="tl tl-close" onClick={(e) => { e.stopPropagation(); closeApp(appId); }} />
          <button className="tl tl-min" onClick={(e) => { e.stopPropagation(); minimizeApp(appId); }} />
          <button className="tl tl-max" onClick={(e) => { e.stopPropagation(); maximizeApp(appId); }} />
        </div>
        <span className="window-title">{app?.icon} {app?.name || appId}</span>
      </div>
      <div className="window-content">{children}</div>
      {!win.isMaximized && <div className="resize-handle" onMouseDown={onResizeStart} onTouchStart={onResizeStart} />}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS DOCK
// ═══════════════════════════════════════════════════════════════════════════
function GlassDock() {
  const { pinnedApps, apps, windows, openApp, focusWindow, restoreApp, toggleGlassPanel, glassPanelOpen } = useOSStore();
  const pinnedAppData = apps.filter(a => pinnedApps.includes(a.id));

  const handleClick = (appId) => {
    const win = windows[appId];
    if (win?.isOpen) {
      if (win.isMinimized) restoreApp(appId);
      else focusWindow(appId);
    } else {
      openApp(appId);
    }
  };

  return (
    <div className="glass-dock">
      <button className="dock-cube" onClick={toggleGlassPanel}>
        <div className={`cube ${glassPanelOpen ? 'active' : ''}`}>⬡</div>
      </button>
      <div className="dock-sep" />
      {pinnedAppData.map(app => (
        <button key={app.id} className={`dock-item ${windows[app.id]?.isOpen ? 'open' : ''}`} onClick={() => handleClick(app.id)} title={app.name}>
          <span className="dock-icon">{app.icon}</span>
          {windows[app.id]?.isOpen && <div className="dock-indicator" />}
        </button>
      ))}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// GLASS PANEL (App Launcher)
// ═══════════════════════════════════════════════════════════════════════════
function GlassPanel() {
  const { apps, openApp, glassPanelOpen } = useOSStore();
  if (!glassPanelOpen) return null;

  return (
    <div className="glass-panel">
      <div className="panel-header">KURO OS</div>
      <div className="panel-grid">
        {apps.map(app => (
          <button key={app.id} className="panel-app" onClick={() => openApp(app.id)}>
            <span className="panel-icon">{app.icon}</span>
            <span className="panel-label">{app.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════════════════════
export default function App() {
  const { windows, apps } = useOSStore();

  return (
    <div className="kuro-desktop">
      <DesktopBackground />

      {Object.entries(windows).map(([appId, win]) => {
        if (!win.isOpen) return null;
        const app = apps.find(a => a.id === appId);
        if (!app) return null;
        const Component = APP_COMPONENTS[app.component];
        if (!Component) return null;
        return (
          <AppWindow key={appId} appId={appId}>
            <Component />
          </AppWindow>
        );
      })}

      <GlassPanel />
      <GlassDock />

      <style>{`
/* ═══════════════════════════════════════════════════════════════════════════
   KURO OS — LIQUID GLASS THEME
   ═══════════════════════════════════════════════════════════════════════════ */
.kuro-desktop {
  width: 100vw; height: 100vh; overflow: hidden; position: relative;
  background: #000; color: #fff;
  font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', sans-serif;
}

/* WINDOW */
.app-window {
  border-radius: 12px; overflow: hidden; display: flex; flex-direction: column;
  background: rgba(18, 18, 22, 0.85);
  backdrop-filter: blur(40px) saturate(180%); -webkit-backdrop-filter: blur(40px) saturate(180%);
  border: 1px solid rgba(255,255,255,0.08);
  box-shadow: 0 8px 40px rgba(0,0,0,0.5), 0 0 1px rgba(255,255,255,0.1);
}
.window-titlebar {
  height: 42px; display: flex; align-items: center; padding: 0 12px; gap: 8px;
  background: rgba(30,30,34,0.6); cursor: grab; user-select: none; flex-shrink: 0;
  -webkit-user-select: none; -webkit-touch-callout: none;
}
.window-titlebar:active { cursor: grabbing; }
.traffic-lights { display: flex; gap: 7px; align-items: center; }
.tl {
  width: 13px; height: 13px; border-radius: 50%; border: none; cursor: pointer;
  transition: opacity 0.15s; opacity: 0.8;
}
.tl:hover { opacity: 1; }
.tl-close { background: #ff5f57; }
.tl-min { background: #ffbd2e; }
.tl-max { background: #28c840; }
.window-title { font-size: 13px; color: rgba(255,255,255,0.7); flex: 1; text-align: center; }
.window-content { flex: 1; overflow: auto; position: relative; }
.resize-handle {
  position: absolute; bottom: 0; right: 0; width: 20px; height: 20px; cursor: nwse-resize;
}

/* DOCK */
.glass-dock {
  position: fixed; bottom: 12px; left: 50%; transform: translateX(-50%);
  display: flex; align-items: center; gap: 4px; padding: 6px 12px;
  background: rgba(30,30,34,0.7); backdrop-filter: blur(40px); -webkit-backdrop-filter: blur(40px);
  border-radius: 18px; border: 1px solid rgba(255,255,255,0.1); z-index: 9999;
}
.dock-cube {
  width: 44px; height: 44px; display: flex; align-items: center; justify-content: center;
  background: none; border: none; cursor: pointer; font-size: 22px; color: #a855f7;
  transition: transform 0.2s;
}
.dock-cube:hover { transform: scale(1.1); }
.cube.active { color: #d946ef; }
.dock-sep { width: 1px; height: 28px; background: rgba(255,255,255,0.12); margin: 0 4px; }
.dock-item {
  width: 44px; height: 44px; display: flex; flex-direction: column; align-items: center; justify-content: center;
  background: none; border: none; cursor: pointer; border-radius: 12px; position: relative;
  transition: transform 0.15s, background 0.15s;
}
.dock-item:hover { transform: translateY(-4px); background: rgba(255,255,255,0.05); }
.dock-icon { font-size: 24px; }
.dock-indicator {
  position: absolute; bottom: -2px; width: 4px; height: 4px; border-radius: 50%;
  background: #a855f7;
}

/* GLASS PANEL */
.glass-panel {
  position: fixed; bottom: 74px; left: 50%; transform: translateX(-50%);
  width: 320px; padding: 20px;
  background: rgba(20,20,24,0.85); backdrop-filter: blur(50px); -webkit-backdrop-filter: blur(50px);
  border-radius: 16px; border: 1px solid rgba(255,255,255,0.1); z-index: 9998;
  box-shadow: 0 12px 48px rgba(0,0,0,0.5);
}
.panel-header {
  font-size: 14px; font-weight: 600; color: rgba(255,255,255,0.5);
  letter-spacing: 2px; text-align: center; margin-bottom: 16px;
}
.panel-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
.panel-app {
  display: flex; flex-direction: column; align-items: center; gap: 6px;
  background: none; border: none; cursor: pointer; padding: 12px 8px; border-radius: 12px;
  transition: background 0.15s; color: #fff;
}
.panel-app:hover { background: rgba(255,255,255,0.08); }
.panel-icon { font-size: 32px; }
.panel-label { font-size: 11px; color: rgba(255,255,255,0.7); }

/* SCROLLBAR */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.15); border-radius: 3px; }

@media (max-width: 768px) {
  .glass-dock { bottom: 8px; padding: 4px 8px; }
  .dock-cube, .dock-item { width: 38px; height: 38px; }
  .dock-icon { font-size: 20px; }
  .glass-panel { width: calc(100vw - 24px); bottom: 66px; }
}
      `}</style>
    </div>
  );
}
