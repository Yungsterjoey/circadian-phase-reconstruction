/**
 * KURO CHAT v5.2
 * Apple HIG Liquid Glass + NIN Industrial Control Panel
 * Typing Flash Cards + GPT 5.2 Competitive Skills
 */
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Send, Plus, Image, FileText, Settings, ChevronDown, ChevronUp, Brain, Folder, MessageSquare, X, Square, Sparkles, Trash2, Globe, ShoppingBag, Code, Search, Lightbulb, FileCode, ExternalLink, Copy, Check, Zap, Target, Atom, Lock, AlertTriangle, Eye, Mic, Paperclip, RotateCcw, Play } from 'lucide-react';

// ═══════════════════════════════════════════════════════════════════════════
// SKILL DEFINITIONS - GPT 5.2 COMPETITIVE
// ═══════════════════════════════════════════════════════════════════════════
const SKILLS = {
  research: {
    id: 'research',
    name: 'Deep Research',
    icon: Search,
    color: '#5e5ce6',
    desc: 'Multi-source analysis',
    prompt: `DEEP RESEARCH MODE ACTIVATED.
PROTOCOL:
1. Analyze from multiple authoritative perspectives
2. Cross-reference information sources
3. Identify contradictions and consensus
4. Provide confidence levels for claims
5. Use <research>...</research> for analysis process
6. Cite sources as [Source](url) when available
7. Include "Further Reading" section when relevant`
  },
  web: {
    id: 'web',
    name: 'Web Search',
    icon: Globe,
    color: '#30d158',
    desc: 'Real-time information',
    prompt: `WEB SEARCH MODE ACTIVATED.
PROTOCOL:
1. Simulate comprehensive web search
2. Provide current, dated information
3. Format links as [Title](url)
4. Include search snippets in responses
5. Organize by relevance and recency
6. Add "Sources" section at end`
  },
  code: {
    id: 'code',
    name: 'Code',
    icon: Code,
    color: '#ff9f0a',
    desc: 'Production-ready code',
    prompt: `CODE ASSISTANT MODE ACTIVATED.
PROTOCOL:
1. Write clean, documented code
2. Follow language best practices
3. Include error handling
4. Use <artifact type="code" lang="...">...</artifact> for runnable code
5. Explain complex logic inline
6. Suggest optimizations`
  },
  shopping: {
    id: 'shopping',
    name: 'Shopping',
    icon: ShoppingBag,
    color: '#ff375f',
    desc: 'Product comparison',
    prompt: `SHOPPING ASSISTANT MODE ACTIVATED.
PROTOCOL:
1. Compare products objectively
2. Format: **Product** | $Price | ⭐ Rating | [Buy](url)
3. Include pros/cons lists
4. Consider budget constraints
5. Suggest alternatives
6. Note deals and discounts`
  },
  artifact: {
    id: 'artifact',
    name: 'Artifacts',
    icon: FileCode,
    color: '#bf5af2',
    desc: 'Interactive outputs',
    prompt: `ARTIFACT CREATION MODE ACTIVATED.
PROTOCOL:
1. Create self-contained artifacts
2. Use <artifact type="react|html|svg|mermaid" title="...">...</artifact>
3. Include all necessary code
4. Make artifacts interactive when possible
5. Add inline styles for portability`
  },
  reason: {
    id: 'reason',
    name: 'Reason',
    icon: Lightbulb,
    color: '#ffd60a',
    desc: 'Chain-of-thought',
    prompt: `DEEP REASONING MODE ACTIVATED.
PROTOCOL:
1. Break down complex problems systematically
2. Use <think>...</think> for internal deliberation
3. Use <reasoning>...</reasoning> for explicit logic
4. Consider edge cases and alternatives
5. Show confidence in conclusions
6. Acknowledge uncertainty explicitly`
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// TYPING PROMPTS - FLASH CARDS
// ═══════════════════════════════════════════════════════════════════════════
const TYPING_PROMPTS = [
  "Write me a story about finding home...",
  "Create a productivity system for ADHD...",
  "Design a REST API for a social app...",
  "Plan a budget trip to Japan...",
  "Explain machine learning simply...",
  "Write a cover letter for Google...",
  "Compare MacBook Pro vs Air 2024...",
  "Create a 30-day fitness challenge...",
];

// ═══════════════════════════════════════════════════════════════════════════
// TYPING ANIMATION COMPONENT
// ═══════════════════════════════════════════════════════════════════════════
const TypingFlashCard = () => {
  const [text, setText] = useState('');
  const [promptIndex, setPromptIndex] = useState(0);
  const [phase, setPhase] = useState('typing'); // typing | paused | deleting
  
  useEffect(() => {
    const current = TYPING_PROMPTS[promptIndex];
    
    if (phase === 'typing') {
      if (text.length < current.length) {
        const timer = setTimeout(() => {
          setText(current.slice(0, text.length + 1));
        }, 40 + Math.random() * 40);
        return () => clearTimeout(timer);
      } else {
        setPhase('paused');
      }
    }
    
    if (phase === 'paused') {
      const timer = setTimeout(() => setPhase('deleting'), 5500);
      return () => clearTimeout(timer);
    }
    
    if (phase === 'deleting') {
      if (text.length > 0) {
        const timer = setTimeout(() => {
          setText(text.slice(0, -1));
        }, 25);
        return () => clearTimeout(timer);
      } else {
        setPromptIndex((prev) => (prev + 1) % TYPING_PROMPTS.length);
        setPhase('typing');
      }
    }
  }, [text, promptIndex, phase]);
  
  return (
    <div className="typing-flash-card">
      <span className="flash-text">{text}</span>
      <span className="flash-cursor" />
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// TAG EXTRACTION
// ═══════════════════════════════════════════════════════════════════════════
const extractTags = (content) => {
  const tags = { think: '', reasoning: '', research: '', artifact: null, main: content };
  const patterns = [
    { name: 'think', open: '<think>', close: '</think>' },
    { name: 'reasoning', open: '<reasoning>', close: '</reasoning>' },
    { name: 'research', open: '<research>', close: '</research>' },
  ];
  
  let remaining = content;
  for (const { name, open, close } of patterns) {
    const regex = new RegExp(`${open}([\\s\\S]*?)${close}`, 'gi');
    let match;
    while ((match = regex.exec(remaining)) !== null) {
      tags[name] = (tags[name] || '') + match[1].trim() + '\n';
    }
    remaining = remaining.replace(regex, '');
    
    // Handle streaming (unclosed tags)
    const lastOpen = remaining.lastIndexOf(open);
    if (lastOpen !== -1 && remaining.indexOf(close, lastOpen) === -1) {
      tags[name] = (tags[name] || '') + remaining.slice(lastOpen + open.length);
      remaining = remaining.slice(0, lastOpen);
      tags[name + '_streaming'] = true;
    }
  }
  
  // Extract artifacts
  const artifactMatch = remaining.match(/<artifact[^>]*type="([^"]*)"[^>]*(?:title="([^"]*)")?[^>]*>([\s\S]*?)<\/artifact>/i);
  if (artifactMatch) {
    tags.artifact = { type: artifactMatch[1], title: artifactMatch[2] || 'Artifact', content: artifactMatch[3] };
    remaining = remaining.replace(artifactMatch[0], '');
  }
  
  tags.main = remaining.trim();
  return tags;
};

// ═══════════════════════════════════════════════════════════════════════════
// APPLE HIG - LIQUID GLASS TOGGLE (iOS 18 Style)
// ═══════════════════════════════════════════════════════════════════════════
const LiquidToggle = ({ checked, onChange, color = '#34c759' }) => (
  <div 
    className={`liquid-toggle ${checked ? 'on' : ''}`} 
    style={{ '--toggle-active': color }}
    onClick={() => onChange(!checked)}
  >
    <div className="toggle-track">
      <div className="toggle-glow" />
    </div>
    <div className="toggle-knob" />
  </div>
);

// ═══════════════════════════════════════════════════════════════════════════
// APPLE HIG - CIRCULAR STEPPER (watchOS Style)
// ═══════════════════════════════════════════════════════════════════════════
const CircularStepper = ({ value, onChange, options }) => (
  <div className="circular-stepper">
    {options.map((opt, i) => (
      <button
        key={i}
        className={`stepper-node ${value === i ? 'active' : ''} ${i < value ? 'passed' : ''}`}
        onClick={() => onChange(i)}
      >
        <div className="node-ring">
          <div className="node-core" />
        </div>
        <span className="node-label">{opt}</span>
      </button>
    ))}
    <div className="stepper-track">
      <div className="stepper-fill" style={{ width: `${(value / (options.length - 1)) * 100}%` }} />
    </div>
  </div>
);

// ═══════════════════════════════════════════════════════════════════════════
// APPLE HIG - GLASS SLIDER
// ═══════════════════════════════════════════════════════════════════════════
const GlassSlider = ({ value, onChange, label, min = 0, max = 100 }) => {
  const percentage = ((value - min) / (max - min)) * 100;
  
  return (
    <div className="glass-slider">
      <div className="slider-info">
        <span className="slider-label">{label}</span>
        <span className="slider-value">{value}%</span>
      </div>
      <div className="slider-container">
        <div className="slider-track-bg" />
        <div className="slider-track-fill" style={{ width: `${percentage}%` }} />
        <div className="slider-thumb" style={{ left: `${percentage}%` }} />
        <input
          type="range"
          min={min}
          max={max}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
        />
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// THINKING BOX - SF PRO MONO
// ═══════════════════════════════════════════════════════════════════════════
const ThinkingBox = ({ label, content, isStreaming, color, icon: Icon }) => {
  const [expanded, setExpanded] = useState(true);
  if (!content && !isStreaming) return null;
  
  return (
    <div className="think-box" style={{ '--think-color': color }}>
      <button className="think-header" onClick={() => setExpanded(!expanded)}>
        <div className="think-badge">
          <Icon size={12} />
          <span>{label}</span>
        </div>
        <div className={`think-chevron ${expanded ? 'open' : ''}`}>
          <ChevronDown size={14} />
        </div>
      </button>
      <div className={`think-body ${expanded ? 'show' : ''}`}>
        <pre>{content}{isStreaming && <span className="stream-cursor">▌</span>}</pre>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// ARTIFACT CARD
// ═══════════════════════════════════════════════════════════════════════════
const ArtifactCard = ({ artifact }) => {
  const [copied, setCopied] = useState(false);
  
  const copy = () => {
    navigator.clipboard.writeText(artifact.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  return (
    <div className="artifact-card">
      <div className="artifact-bar">
        <FileCode size={14} />
        <span className="artifact-title">{artifact.title}</span>
        <span className="artifact-lang">{artifact.type}</span>
        <button className="artifact-btn" onClick={copy}>
          {copied ? <Check size={14} /> : <Copy size={14} />}
        </button>
      </div>
      <div className="artifact-code">
        <pre><code>{artifact.content}</code></pre>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// MESSAGE BUBBLE
// ═══════════════════════════════════════════════════════════════════════════
const MessageBubble = ({ msg, isStreaming, showThoughts }) => {
  const tags = extractTags(msg.content || '');
  
  return (
    <div className={`message ${msg.role}`}>
      <div className="message-content">
        {msg.role === 'assistant' && showThoughts && (
          <>
            <ThinkingBox label="Thinking" content={tags.think} isStreaming={tags.think_streaming} color="#bf5af2" icon={Brain} />
            <ThinkingBox label="Reasoning" content={tags.reasoning} isStreaming={tags.reasoning_streaming} color="#30d158" icon={Lightbulb} />
            <ThinkingBox label="Research" content={tags.research} isStreaming={tags.research_streaming} color="#5e5ce6" icon={Search} />
          </>
        )}
        {tags.artifact && <ArtifactCard artifact={tags.artifact} />}
        <div className="message-text">
          {tags.main}
          {isStreaming && !Object.keys(tags).some(k => k.endsWith('_streaming') && tags[k]) && tags.main && (
            <span className="stream-cursor">▌</span>
          )}
        </div>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// NIN / ADD ANXIETY - NEURAL CONTROL PANEL
// ═══════════════════════════════════════════════════════════════════════════
const NINPanel = ({ visible, onClose, settings, onChange }) => {
  if (!visible) return null;
  
  const set = (k, v) => onChange({ ...settings, [k]: v });
  
  return (
    <div className="nin-panel">
      <div className="nin-chrome">
        <div className="nin-titlebar">
          <div className="nin-indicator" />
          <span className="nin-title">NEURAL::CONTROL</span>
          <button className="nin-close" onClick={onClose}><X size={14} /></button>
        </div>
      </div>
      
      <div className="nin-content">
        {/* DEPTH SECTION */}
        <div className="nin-section">
          <div className="nin-section-label">
            <span className="nin-hash">#</span>
            <span>COGNITIVE_DEPTH</span>
          </div>
          <CircularStepper
            value={settings.depth}
            onChange={(v) => set('depth', v)}
            options={['NULL', 'LOW', 'MED', 'MAX']}
          />
        </div>
        
        {/* VOLATILITY */}
        <div className="nin-section">
          <div className="nin-section-label">
            <span className="nin-hash">#</span>
            <span>VOLATILITY</span>
          </div>
          <GlassSlider
            value={settings.volatility}
            onChange={(v) => set('volatility', v)}
            label=""
          />
        </div>
        
        <div className="nin-divider" />
        
        {/* DISPLAY FLAGS */}
        <div className="nin-section">
          <div className="nin-section-label">
            <span className="nin-hash">#</span>
            <span>DISPLAY_FLAGS</span>
          </div>
          <div className="nin-toggle-row">
            <span className="nin-toggle-label">show_thinking</span>
            <LiquidToggle checked={settings.showThinking} onChange={(v) => set('showThinking', v)} color="#bf5af2" />
          </div>
          <div className="nin-toggle-row">
            <span className="nin-toggle-label">chain_of_thought</span>
            <LiquidToggle checked={settings.reasoning} onChange={(v) => set('reasoning', v)} color="#30d158" />
          </div>
        </div>
        
        <div className="nin-divider" />
        
        {/* PROTOCOLS */}
        <div className="nin-section">
          <div className="nin-section-label">
            <span className="nin-hash">#</span>
            <span>GHOST_PROTOCOL</span>
          </div>
          <div className="nin-toggle-row">
            <span className="nin-toggle-label">incubation</span>
            <LiquidToggle checked={settings.incubation} onChange={(v) => set('incubation', v)} color="#64d2ff" />
          </div>
          <div className="nin-toggle-row">
            <span className="nin-toggle-label">red_team</span>
            <LiquidToggle checked={settings.redTeam} onChange={(v) => set('redTeam', v)} color="#ff453a" />
          </div>
          <div className="nin-toggle-row">
            <span className="nin-toggle-label">nuclear_fusion</span>
            <LiquidToggle checked={settings.nuclearFusion} onChange={(v) => set('nuclearFusion', v)} color="#ff9f0a" />
          </div>
        </div>
      </div>
      
      <div className="nin-footer">
        <div className="nin-status">
          <div className={`nin-status-led ${settings.depth > 0 ? 'armed' : ''}`} />
          <span>STATUS: {settings.depth > 0 ? 'ARMED' : 'STANDBY'}</span>
        </div>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// SKILLS DROPDOWN - LIQUID GLASS
// ═══════════════════════════════════════════════════════════════════════════
const SkillsDropdown = ({ visible, onClose, activeSkill, onSelect }) => {
  if (!visible) return null;
  
  return (
    <div className="skills-dropdown">
      <div className="skills-grid">
        {Object.values(SKILLS).map(skill => {
          const Icon = skill.icon;
          const isActive = activeSkill === skill.id;
          return (
            <button
              key={skill.id}
              className={`skill-tile ${isActive ? 'active' : ''}`}
              style={{ '--skill-color': skill.color }}
              onClick={() => { onSelect(isActive ? null : skill.id); onClose(); }}
            >
              <div className="skill-icon-wrap"><Icon size={22} /></div>
              <span className="skill-name">{skill.name}</span>
              <span className="skill-desc">{skill.desc}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════════════════
export default function KuroChat() {
  const [conversations, setConversations] = useState(() => {
    try {
      const s = localStorage.getItem('kuro_v52');
      return s ? JSON.parse(s) : [{ id: Date.now(), title: '', messages: [] }];
    } catch { return [{ id: Date.now(), title: '', messages: [] }]; }
  });
  const [activeId, setActiveId] = useState(() => conversations[0]?.id);
  
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showPanel, setShowPanel] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeSkill, setActiveSkill] = useState(null);
  
  const [settings, setSettings] = useState({
    depth: 2,
    volatility: 70,
    showThinking: true,
    reasoning: true,
    incubation: false,
    redTeam: false,
    nuclearFusion: false,
  });
  
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const imgInputRef = useRef(null);
  const abortRef = useRef(null);
  const textareaRef = useRef(null);
  
  const activeConv = conversations.find(c => c.id === activeId) || conversations[0];
  const messages = activeConv?.messages || [];

  useEffect(() => {
    localStorage.setItem('kuro_v52', JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const updateMessages = useCallback((convId, updater) => {
    setConversations(prev => prev.map(c => 
      c.id === convId ? { ...c, messages: typeof updater === 'function' ? updater(c.messages) : updater } : c
    ));
  }, []);

  const createConversation = () => {
    const n = { id: Date.now(), title: '', messages: [] };
    setConversations(prev => [n, ...prev]);
    setActiveId(n.id);
    setSidebarOpen(false);
  };

  const deleteConversation = (id) => {
    setConversations(prev => {
      const f = prev.filter(c => c.id !== id);
      if (f.length === 0) {
        const n = { id: Date.now(), title: '', messages: [] };
        setActiveId(n.id);
        return [n];
      }
      if (id === activeId) setActiveId(f[0].id);
      return f;
    });
  };

  const handleFileSelect = (e, type) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const content = ev.target.result;
      const userMsg = {
        role: 'user',
        content: type === 'vision' ? `[Image: ${file.name}]` : `[File: ${file.name}]\n\`\`\`\n${content}\n\`\`\``,
        images: type === 'vision' ? [content.split(',')[1]] : undefined
      };
      updateMessages(activeId, prev => [...prev, userMsg]);
      if (type === 'vision') sendMessage(userMsg);
    };
    if (type === 'vision') reader.readAsDataURL(file);
    else reader.readAsText(file);
    e.target.value = '';
  };

  const stopStreaming = () => {
    if (abortRef.current) abortRef.current.abort();
    setIsLoading(false);
  };

  const sendMessage = async (presetMsg = null) => {
    const msgToSend = presetMsg || { role: 'user', content: input.trim() };
    if (!presetMsg && !input.trim()) return;
    
    const convId = activeId;
    
    if (!presetMsg) {
      updateMessages(convId, prev => [...prev, msgToSend, { role: 'assistant', content: '' }]);
      setInput('');
    } else {
      updateMessages(convId, prev => [...prev, { role: 'assistant', content: '' }]);
    }
    
    if (messages.length === 0 && msgToSend.content) {
      setConversations(prev => prev.map(c => 
        c.id === convId ? { ...c, title: msgToSend.content.slice(0, 30) } : c
      ));
    }
    
    setIsLoading(true);

    try {
      abortRef.current = new AbortController();
      
      const apiMessages = [...messages, msgToSend].map(m => ({
        role: m.role, content: m.content, images: m.images
      }));

      const response = await fetch('/api/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: apiMessages,
          clientType: 'chat',
          temperature: settings.volatility / 100,
          thinking: settings.showThinking,
          depth: settings.depth,
          reasoning: settings.reasoning,
          incubation: settings.incubation,
          redTeam: settings.redTeam,
          nuclearFusion: settings.nuclearFusion,
          skill: activeSkill,
        }),
        signal: abortRef.current.signal
      });

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          try {
            const data = JSON.parse(line.slice(6));
            if (data.type === 'token') {
              updateMessages(convId, prev => {
                const u = [...prev];
                const last = u[u.length - 1];
                if (last?.role === 'assistant') {
                  u[u.length - 1] = { ...last, content: last.content + data.content };
                }
                return u;
              });
            } else if (data.type === 'done') {
              setIsLoading(false);
            }
          } catch {}
        }
      }
    } catch (e) {
      if (e.name !== 'AbortError') console.error(e);
    }
    setIsLoading(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 200) + 'px';
    }
  }, [input]);

  const activeSkillData = activeSkill ? SKILLS[activeSkill] : null;

  return (
    <div className="kuro-root">
      <input type="file" hidden ref={fileInputRef} accept=".pdf,.txt,.md,.json,.js,.jsx,.ts,.tsx,.py,.c,.cpp,.h,.css,.html" onChange={(e) => handleFileSelect(e, 'file')} />
      <input type="file" hidden ref={imgInputRef} accept="image/*" onChange={(e) => handleFileSelect(e, 'vision')} />

      {/* SIDEBAR */}
      {sidebarOpen && (
        <>
          <div className="sidebar-overlay" onClick={() => setSidebarOpen(false)} />
          <aside className="sidebar">
            <div className="sidebar-head">
              <Brain size={20} />
              <span>KURO</span>
              <button onClick={() => setSidebarOpen(false)}><X size={18} /></button>
            </div>
            <button className="new-btn" onClick={createConversation}>
              <Plus size={16} /><span>New Chat</span>
            </button>
            <div className="chat-list">
              {conversations.map(c => (
                <div key={c.id} className={`chat-item ${c.id === activeId ? 'active' : ''}`} onClick={() => { setActiveId(c.id); setSidebarOpen(false); }}>
                  <MessageSquare size={14} />
                  <span>{c.title || 'New chat'}</span>
                  <button onClick={(e) => { e.stopPropagation(); deleteConversation(c.id); }}><Trash2 size={12} /></button>
                </div>
              ))}
            </div>
          </aside>
        </>
      )}

      {/* MAIN */}
      <main className="main">
        {/* HEADER */}
        <header className="topbar">
          <button className="topbar-btn" onClick={() => setSidebarOpen(true)}><MessageSquare size={18} /></button>
          {activeSkillData && (
            <div className="skill-badge" style={{ '--badge-color': activeSkillData.color }}>
              <activeSkillData.icon size={12} />
              <span>{activeSkillData.name}</span>
              <button onClick={() => setActiveSkill(null)}><X size={12} /></button>
            </div>
          )}
          <div className="topbar-spacer" />
          <button className={`topbar-btn ${showPanel === 'skills' ? 'on' : ''}`} onClick={() => setShowPanel(showPanel === 'skills' ? null : 'skills')}><Sparkles size={18} /></button>
          <button className={`topbar-btn ${showPanel === 'neural' ? 'on' : ''}`} onClick={() => setShowPanel(showPanel === 'neural' ? null : 'neural')}><Settings size={18} /></button>
        </header>

        {/* PANELS */}
        <NINPanel visible={showPanel === 'neural'} onClose={() => setShowPanel(null)} settings={settings} onChange={setSettings} />
        <SkillsDropdown visible={showPanel === 'skills'} onClose={() => setShowPanel(null)} activeSkill={activeSkill} onSelect={setActiveSkill} />

        {/* MESSAGES */}
        <div className="messages">
          {messages.length === 0 ? (
            <div className="empty">
              <h1>How can I help you today?</h1>
              <TypingFlashCard />
            </div>
          ) : (
            messages.map((msg, i) => (
              <MessageBubble 
                key={i} 
                msg={msg} 
                isStreaming={isLoading && i === messages.length - 1 && msg.role === 'assistant'} 
                showThoughts={settings.showThinking} 
              />
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* INPUT */}
        <div className="input-dock">
          <div className="input-bar">
            <button className="bar-btn" onClick={() => imgInputRef.current?.click()}><Image size={18} /></button>
            <button className="bar-btn" onClick={() => fileInputRef.current?.click()}><Paperclip size={18} /></button>
            <textarea 
              ref={textareaRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Message KURO..."
              rows={1}
            />
            {isLoading ? (
              <button className="send-btn stop" onClick={stopStreaming}><Square size={16} /></button>
            ) : (
              <button className="send-btn" onClick={() => sendMessage()} disabled={!input.trim()}><Send size={16} /></button>
            )}
          </div>
        </div>
      </main>

      <style>{`
/* ═══════════════════════════════════════════════════════════════════════════
   SF PRO TYPOGRAPHY + LIQUID GLASS FOUNDATION
   Based on Apple HIG: https://developer.apple.com/design/human-interface-guidelines/
   ═══════════════════════════════════════════════════════════════════════════ */
@import url('https://fonts.cdnfonts.com/css/sf-pro-display');

:root {
  --sf-pro: 'SF Pro Display', 'SF Pro', -apple-system, BlinkMacSystemFont, system-ui, sans-serif;
  --sf-mono: 'SF Mono', 'Menlo', 'Monaco', monospace;
  --glass-bg: rgba(28, 28, 30, 0.72);
  --glass-border: rgba(255, 255, 255, 0.08);
  --glass-blur: 40px;
  --accent: #0a84ff;
  --text-primary: #f5f5f7;
  --text-secondary: rgba(255, 255, 255, 0.55);
  --text-tertiary: rgba(255, 255, 255, 0.3);
}

.kuro-root {
  display: flex;
  height: 100%;
  background: #000;
  color: var(--text-primary);
  font-family: var(--sf-pro);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  overflow: hidden;
}

/* ═══════════════════════════════════════════════════════════════════════════
   SIDEBAR - LIQUID GLASS
   ═══════════════════════════════════════════════════════════════════════════ */
.sidebar-overlay {
  position: fixed; inset: 0;
  background: rgba(0,0,0,0.5);
  backdrop-filter: blur(4px);
  z-index: 100;
}

.sidebar {
  position: fixed; top: 0; left: 0;
  width: 280px; height: 100%;
  background: var(--glass-bg);
  backdrop-filter: blur(var(--glass-blur)) saturate(180%);
  border-right: 0.5px solid var(--glass-border);
  z-index: 200;
  display: flex; flex-direction: column;
  padding: 20px;
}

.sidebar-head {
  display: flex; align-items: center; gap: 10px;
  font-size: 17px; font-weight: 600;
  letter-spacing: -0.4px;
  margin-bottom: 24px;
}
.sidebar-head button {
  margin-left: auto;
  padding: 6px;
  background: transparent;
  border: none;
  color: var(--text-secondary);
  cursor: pointer;
  border-radius: 8px;
}
.sidebar-head button:hover { background: rgba(255,255,255,0.1); }

.new-btn {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  padding: 12px;
  background: rgba(10,132,255,0.12);
  border: 1px solid rgba(10,132,255,0.2);
  border-radius: 12px;
  color: var(--accent);
  font: 500 15px var(--sf-pro);
  cursor: pointer;
  transition: background 0.2s;
}
.new-btn:hover { background: rgba(10,132,255,0.2); }

.chat-list { flex: 1; overflow-y: auto; margin-top: 16px; }
.chat-item {
  display: flex; align-items: center; gap: 10px;
  padding: 12px 14px;
  border-radius: 10px;
  color: var(--text-secondary);
  font-size: 15px;
  cursor: pointer;
  transition: all 0.15s;
}
.chat-item:hover { background: rgba(255,255,255,0.05); }
.chat-item.active { background: rgba(255,255,255,0.1); color: var(--text-primary); }
.chat-item span { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.chat-item button {
  padding: 4px;
  background: transparent;
  border: none;
  color: var(--text-tertiary);
  cursor: pointer;
  opacity: 0;
  border-radius: 6px;
}
.chat-item:hover button { opacity: 1; }
.chat-item button:hover { background: rgba(255,59,48,0.15); color: #ff453a; }

/* ═══════════════════════════════════════════════════════════════════════════
   MAIN STAGE
   ═══════════════════════════════════════════════════════════════════════════ */
.main { flex: 1; display: flex; flex-direction: column; position: relative; }

.topbar {
  position: absolute; top: 16px; left: 16px; right: 16px;
  display: flex; align-items: center; gap: 8px;
  z-index: 50;
}
.topbar-btn {
  padding: 10px;
  background: var(--glass-bg);
  backdrop-filter: blur(20px);
  border: 0.5px solid var(--glass-border);
  border-radius: 12px;
  color: var(--text-secondary);
  cursor: pointer;
  transition: all 0.2s;
}
.topbar-btn:hover { background: rgba(255,255,255,0.08); color: var(--text-primary); }
.topbar-btn.on { background: rgba(10,132,255,0.15); color: var(--accent); border-color: rgba(10,132,255,0.3); }
.topbar-spacer { flex: 1; }

.skill-badge {
  display: flex; align-items: center; gap: 6px;
  padding: 6px 12px;
  background: color-mix(in srgb, var(--badge-color) 12%, transparent);
  border: 1px solid color-mix(in srgb, var(--badge-color) 30%, transparent);
  border-radius: 20px;
  font: 500 12px var(--sf-pro);
  color: var(--badge-color);
}
.skill-badge button {
  padding: 2px;
  background: transparent;
  border: none;
  color: inherit;
  cursor: pointer;
  opacity: 0.6;
}
.skill-badge button:hover { opacity: 1; }

/* ═══════════════════════════════════════════════════════════════════════════
   NIN / ADD ANXIETY CONTROL PANEL
   ═══════════════════════════════════════════════════════════════════════════ */
.nin-panel {
  position: absolute; top: 70px; right: 16px; width: 320px;
  background: rgba(12, 12, 14, 0.96);
  backdrop-filter: blur(40px);
  border: 1px solid rgba(255,255,255,0.06);
  border-radius: 16px;
  z-index: 60;
  overflow: hidden;
  box-shadow: 0 24px 80px rgba(0,0,0,0.6);
}

.nin-chrome {
  background: linear-gradient(180deg, rgba(255,255,255,0.03) 0%, transparent 100%);
  border-bottom: 1px solid rgba(255,255,255,0.04);
}

.nin-titlebar {
  display: flex; align-items: center; gap: 12px;
  padding: 14px 16px;
}

.nin-indicator {
  width: 8px; height: 8px;
  border-radius: 50%;
  background: #ff453a;
  box-shadow: 0 0 12px #ff453a;
  animation: led-pulse 2s ease-in-out infinite;
}
@keyframes led-pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }

.nin-title {
  font: 700 11px var(--sf-mono);
  letter-spacing: 2px;
  color: var(--text-secondary);
}

.nin-close {
  margin-left: auto;
  padding: 6px;
  background: transparent;
  border: none;
  color: var(--text-tertiary);
  cursor: pointer;
  border-radius: 6px;
}
.nin-close:hover { background: rgba(255,255,255,0.08); color: var(--text-primary); }

.nin-content { padding: 8px 0; }

.nin-section { padding: 14px 18px; }

.nin-section-label {
  display: flex; align-items: center; gap: 6px;
  font: 600 10px var(--sf-mono);
  letter-spacing: 1.5px;
  color: var(--text-tertiary);
  margin-bottom: 16px;
}
.nin-hash { color: #ff453a; }

.nin-divider {
  height: 1px;
  background: rgba(255,255,255,0.04);
  margin: 0 18px;
}

.nin-toggle-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 0;
}

.nin-toggle-label {
  font: 500 14px var(--sf-mono);
  color: var(--text-secondary);
}

.nin-footer {
  padding: 12px 18px;
  background: rgba(0,0,0,0.3);
  border-top: 1px solid rgba(255,255,255,0.04);
}

.nin-status {
  display: flex; align-items: center; gap: 8px;
  font: 600 10px var(--sf-mono);
  letter-spacing: 1px;
  color: var(--text-tertiary);
}

.nin-status-led {
  width: 6px; height: 6px;
  border-radius: 50%;
  background: var(--text-tertiary);
}
.nin-status-led.armed {
  background: #30d158;
  box-shadow: 0 0 8px #30d158;
}

/* ═══════════════════════════════════════════════════════════════════════════
   APPLE HIG - LIQUID TOGGLE (iOS 18)
   ═══════════════════════════════════════════════════════════════════════════ */
.liquid-toggle {
  position: relative;
  width: 51px; height: 31px;
  cursor: pointer;
}

.toggle-track {
  position: absolute; inset: 0;
  background: rgba(120, 120, 128, 0.32);
  border-radius: 16px;
  transition: background 0.25s ease;
  overflow: hidden;
}

.liquid-toggle.on .toggle-track {
  background: var(--toggle-active);
}

.toggle-glow {
  position: absolute; inset: 0;
  background: radial-gradient(circle at 70% 50%, rgba(255,255,255,0.2) 0%, transparent 60%);
  opacity: 0;
  transition: opacity 0.25s;
}
.liquid-toggle.on .toggle-glow { opacity: 1; }

.toggle-knob {
  position: absolute;
  top: 2px; left: 2px;
  width: 27px; height: 27px;
  background: #fff;
  border-radius: 50%;
  box-shadow: 0 3px 8px rgba(0,0,0,0.15), 0 1px 1px rgba(0,0,0,0.16), inset 0 0 0 0.5px rgba(0,0,0,0.04);
  transition: transform 0.25s ease;
}
.liquid-toggle.on .toggle-knob { transform: translateX(20px); }

/* ═══════════════════════════════════════════════════════════════════════════
   CIRCULAR STEPPER (watchOS Style)
   ═══════════════════════════════════════════════════════════════════════════ */
.circular-stepper {
  position: relative;
  display: flex; justify-content: space-between;
  padding: 12px 0;
}

.stepper-track {
  position: absolute;
  top: 26px; left: 24px; right: 24px;
  height: 2px;
  background: rgba(255,255,255,0.1);
  border-radius: 1px;
  z-index: 0;
}

.stepper-fill {
  position: absolute;
  top: 0; left: 0; height: 100%;
  background: var(--accent);
  border-radius: 1px;
  transition: width 0.3s ease;
}

.stepper-node {
  position: relative;
  display: flex; flex-direction: column; align-items: center; gap: 8px;
  background: transparent;
  border: none;
  cursor: pointer;
  z-index: 1;
}

.node-ring {
  width: 28px; height: 28px;
  border-radius: 50%;
  background: rgba(0,0,0,0.6);
  border: 2px solid rgba(255,255,255,0.12);
  display: flex; align-items: center; justify-content: center;
  transition: all 0.2s;
}

.node-core {
  width: 8px; height: 8px;
  border-radius: 50%;
  background: rgba(255,255,255,0.2);
  transition: all 0.2s;
}

.stepper-node.passed .node-ring { border-color: var(--accent); }
.stepper-node.passed .node-core { background: var(--accent); }

.stepper-node.active .node-ring {
  border-color: var(--accent);
  box-shadow: 0 0 16px rgba(10,132,255,0.5);
}
.stepper-node.active .node-core {
  width: 12px; height: 12px;
  background: var(--accent);
}

.node-label {
  font: 600 9px var(--sf-mono);
  letter-spacing: 0.5px;
  color: var(--text-tertiary);
  transition: color 0.2s;
}
.stepper-node.active .node-label { color: var(--accent); }

/* ═══════════════════════════════════════════════════════════════════════════
   GLASS SLIDER
   ═══════════════════════════════════════════════════════════════════════════ */
.glass-slider { padding: 8px 0; }

.slider-info {
  display: flex; justify-content: space-between;
  margin-bottom: 12px;
}
.slider-label {
  font: 600 10px var(--sf-mono);
  letter-spacing: 1.5px;
  color: var(--text-tertiary);
}
.slider-value {
  font: 600 13px var(--sf-mono);
  color: var(--accent);
}

.slider-container {
  position: relative;
  height: 4px;
}

.slider-track-bg {
  position: absolute; inset: 0;
  background: rgba(255,255,255,0.1);
  border-radius: 2px;
}

.slider-track-fill {
  position: absolute; top: 0; left: 0; height: 100%;
  background: linear-gradient(90deg, #30d158 0%, #ffd60a 50%, #ff453a 100%);
  border-radius: 2px;
}

.slider-thumb {
  position: absolute; top: 50%;
  width: 20px; height: 20px;
  background: #fff;
  border-radius: 50%;
  transform: translate(-50%, -50%);
  box-shadow: 0 2px 8px rgba(0,0,0,0.3);
}

.slider-container input {
  position: absolute;
  top: -10px; left: 0;
  width: 100%; height: 24px;
  opacity: 0;
  cursor: pointer;
}

/* ═══════════════════════════════════════════════════════════════════════════
   SKILLS DROPDOWN - LIQUID GLASS GRID
   ═══════════════════════════════════════════════════════════════════════════ */
.skills-dropdown {
  position: absolute; top: 70px; right: 60px; width: 320px;
  background: var(--glass-bg);
  backdrop-filter: blur(var(--glass-blur));
  border: 0.5px solid var(--glass-border);
  border-radius: 16px;
  z-index: 60;
  padding: 12px;
}

.skills-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
}

.skill-tile {
  display: flex; flex-direction: column; align-items: center;
  gap: 8px;
  padding: 16px 12px;
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.05);
  border-radius: 14px;
  cursor: pointer;
  transition: all 0.2s;
}
.skill-tile:hover { background: rgba(255,255,255,0.06); }
.skill-tile.active {
  background: color-mix(in srgb, var(--skill-color) 12%, transparent);
  border-color: color-mix(in srgb, var(--skill-color) 35%, transparent);
}

.skill-icon-wrap {
  width: 44px; height: 44px;
  display: flex; align-items: center; justify-content: center;
  background: rgba(255,255,255,0.05);
  border-radius: 12px;
  color: var(--text-secondary);
  transition: all 0.2s;
}
.skill-tile.active .skill-icon-wrap {
  background: color-mix(in srgb, var(--skill-color) 20%, transparent);
  color: var(--skill-color);
}

.skill-name {
  font: 600 13px var(--sf-pro);
  color: var(--text-primary);
}
.skill-tile.active .skill-name { color: var(--skill-color); }

.skill-desc {
  font: 400 11px var(--sf-pro);
  color: var(--text-tertiary);
}

/* ═══════════════════════════════════════════════════════════════════════════
   MESSAGES AREA
   ═══════════════════════════════════════════════════════════════════════════ */
.messages {
  flex: 1; overflow-y: auto;
  padding: 80px 12% 160px;
  display: flex; flex-direction: column; gap: 24px;
}

.empty {
  margin: auto;
  text-align: center;
}
.empty h1 {
  font: 600 34px var(--sf-pro);
  letter-spacing: -0.5px;
  color: var(--text-primary);
  margin-bottom: 12px;
}

/* TYPING FLASH CARD */
.typing-flash-card {
  min-height: 28px;
}
.flash-text {
  font: 400 18px var(--sf-pro);
  color: var(--text-tertiary);
}
.flash-cursor {
  display: inline-block;
  width: 2px; height: 22px;
  background: var(--text-tertiary);
  margin-left: 2px;
  animation: cursor-blink 1s step-end infinite;
  vertical-align: text-bottom;
}
@keyframes cursor-blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }

/* MESSAGE BUBBLES */
.message { display: flex; width: 100%; }
.message.user { justify-content: flex-end; }
.message-content { max-width: 80%; }

.message.user .message-content {
  background: rgba(10,132,255,0.15);
  border: 1px solid rgba(10,132,255,0.25);
  padding: 14px 18px;
  border-radius: 20px 20px 4px 20px;
}

.message-text {
  font: 400 16px/1.6 var(--sf-pro);
  white-space: pre-wrap;
}

.stream-cursor {
  color: var(--accent);
  animation: cursor-blink 0.8s step-end infinite;
}

/* THINKING BOXES */
.think-box {
  margin-bottom: 16px;
  background: color-mix(in srgb, var(--think-color) 6%, transparent);
  border: 1px solid color-mix(in srgb, var(--think-color) 20%, transparent);
  border-radius: 14px;
  overflow: hidden;
}

.think-header {
  display: flex; align-items: center; gap: 10px;
  width: 100%;
  padding: 12px 14px;
  background: transparent;
  border: none;
  cursor: pointer;
  font: 500 13px var(--sf-pro);
  color: var(--think-color);
}

.think-badge {
  display: flex; align-items: center; gap: 6px;
  padding: 4px 10px;
  background: color-mix(in srgb, var(--think-color) 12%, transparent);
  border-radius: 8px;
}

.think-chevron {
  margin-left: auto;
  opacity: 0.5;
  transition: transform 0.2s;
}
.think-chevron.open { transform: rotate(180deg); }

.think-body {
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.3s ease, padding 0.3s ease;
}
.think-body.show {
  max-height: 400px;
  padding: 0 14px 14px;
  overflow-y: auto;
}

.think-body pre {
  margin: 0;
  font: 400 13px/1.5 var(--sf-mono);
  color: var(--text-secondary);
  white-space: pre-wrap;
}

/* ARTIFACT CARD */
.artifact-card {
  margin: 16px 0;
  background: rgba(28,28,30,0.8);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 14px;
  overflow: hidden;
}

.artifact-bar {
  display: flex; align-items: center; gap: 8px;
  padding: 12px 14px;
  background: rgba(255,255,255,0.02);
  border-bottom: 1px solid rgba(255,255,255,0.05);
  font: 500 13px var(--sf-pro);
}

.artifact-title { flex: 1; }

.artifact-lang {
  padding: 3px 8px;
  background: rgba(255,255,255,0.08);
  border-radius: 6px;
  font: 500 11px var(--sf-mono);
  color: var(--text-secondary);
}

.artifact-btn {
  padding: 6px;
  background: transparent;
  border: none;
  color: var(--text-tertiary);
  cursor: pointer;
  border-radius: 6px;
}
.artifact-btn:hover { background: rgba(255,255,255,0.08); color: var(--text-primary); }

.artifact-code {
  padding: 14px;
  max-height: 300px;
  overflow: auto;
}
.artifact-code pre { margin: 0; }
.artifact-code code {
  font: 400 13px/1.5 var(--sf-mono);
  color: var(--text-secondary);
}

/* ═══════════════════════════════════════════════════════════════════════════
   INPUT DOCK - LIQUID GLASS
   ═══════════════════════════════════════════════════════════════════════════ */
.input-dock {
  position: absolute; bottom: 24px; left: 0; right: 0;
  display: flex; justify-content: center;
  padding: 0 16px;
  z-index: 50;
  pointer-events: none;
}

.input-bar {
  pointer-events: auto;
  display: flex; align-items: flex-end; gap: 8px;
  width: 720px; max-width: 100%;
  padding: 8px 12px;
  background: var(--glass-bg);
  backdrop-filter: blur(var(--glass-blur)) saturate(180%);
  border: 0.5px solid rgba(255,255,255,0.12);
  border-radius: 24px;
  box-shadow: 0 8px 40px rgba(0,0,0,0.35);
}

.bar-btn {
  padding: 10px;
  background: transparent;
  border: none;
  color: var(--text-tertiary);
  cursor: pointer;
  border-radius: 10px;
  transition: all 0.15s;
}
.bar-btn:hover { background: rgba(255,255,255,0.08); color: var(--text-primary); }

textarea {
  flex: 1;
  background: transparent;
  border: none;
  color: var(--text-primary);
  padding: 10px 4px;
  font: 400 16px var(--sf-pro);
  resize: none;
  min-height: 24px;
  max-height: 200px;
  outline: none;
}
textarea::placeholder { color: var(--text-tertiary); }

.send-btn {
  width: 40px; height: 40px;
  display: flex; align-items: center; justify-content: center;
  background: var(--accent);
  border: none;
  border-radius: 50%;
  color: #fff;
  cursor: pointer;
  transition: all 0.15s;
  flex-shrink: 0;
}
.send-btn:hover { transform: scale(1.05); }
.send-btn:disabled { opacity: 0.3; cursor: not-allowed; transform: none; }
.send-btn.stop { background: #ff453a; }

/* ═══════════════════════════════════════════════════════════════════════════
   RESPONSIVE
   ═══════════════════════════════════════════════════════════════════════════ */
@media (max-width: 800px) {
  .messages { padding: 80px 16px 160px; }
  .skills-dropdown { right: 16px; left: 16px; width: auto; }
  .nin-panel { left: 16px; right: 16px; width: auto; }
}
      `}</style>
    </div>
  );
}
