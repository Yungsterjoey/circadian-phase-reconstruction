import { useState, useRef, useEffect, useCallback, useMemo } from 'react'
import { Send, Menu, Square, Brain, Layers, X, MessageSquare, Plus, Trash2, ChevronDown, ChevronRight, Image, FileText, Code, Globe, ShoppingBag, Sparkles, XCircle, Cpu, Check, RefreshCw, Shield, Lock, Zap, Flame, Eye, Lightbulb, FlaskConical, Target, Database, Key, Clock, Activity, Server, Search, Atom, Download, Copy, Share2, FileCode, Archive, CheckCircle, AlertTriangle, Radio, Wifi, WifiOff, Network, Settings, Gauge, Terminal, Play, Pause, RotateCcw, AlertCircle, Power, ToggleLeft, ToggleRight, Crosshair, Rocket, Plane, HardDrive, GitBranch } from 'lucide-react'

// ═══════════════════════════════════════════════════════════════════════════
// ONE BRAIN MODEL REGISTRY
// ═══════════════════════════════════════════════════════════════════════════
const MODEL_REGISTRY = {
  'kuro-unified': { name: 'KURO::UNIFIED', tier: 'sovereign', ctx: 32768, desc: 'Qwen3 30B One Brain', icon: Brain, color: '#a855f7' },
  'kuro-coder': { name: 'KURO::CODER', tier: 'sovereign', ctx: 32768, desc: 'Qwen Coder 14B', icon: Code, color: '#f97316' },
  'kuro-vision': { name: 'KURO::VISION', tier: 'sovereign', ctx: 8192, vision: true, desc: 'Visual analysis', icon: Eye, color: '#22c55e' },
};

// ═══════════════════════════════════════════════════════════════════════════
// LAYER CONFIG - INCLUDES AEROSPACE MODULES
// ═══════════════════════════════════════════════════════════════════════════
const LAYER_CONFIG = {
  0: { name: 'Iron Dome', color: '#ef4444', icon: Shield, desc: 'Threat detection' },
  0.25: { name: 'Nephilim Gate', color: '#dc2626', icon: Lock, desc: 'Rate limiting' },
  1: { name: 'IFF Gate', color: '#f97316', icon: Radio, desc: 'Client ID' },
  1.5: { name: 'Babylon Protocol', color: '#ea580c', icon: AlertTriangle, desc: 'Obfuscation' },
  2: { name: 'Edubba Archive', color: '#eab308', icon: Database, desc: 'Pattern recall' },
  3: { name: 'Semantic Router', color: '#22c55e', icon: Network, desc: 'Intent classify' },
  4: { name: 'Memory Engine', color: '#14b8a6', icon: Brain, desc: 'Session context' },
  5: { name: 'Model Router', color: '#06b6d4', icon: Cpu, desc: 'Model selection' },
  6: { name: 'Fire Control', color: '#3b82f6', icon: Target, desc: 'SMASH targeting' },
  6.5: { name: 'Flight Computer', color: '#0ea5e9', icon: Plane, desc: 'State machine' },
  7: { name: 'Reasoning Engine', color: '#6366f1', icon: Lightbulb, desc: 'Prompt assembly' },
  7.5: { name: 'Voter Layer', color: '#7c3aed', icon: GitBranch, desc: 'Actor-Judge verify' },
  8: { name: 'Maat Refiner', color: '#8b5cf6', icon: Gauge, desc: 'Truth weight' },
  8.5: { name: 'Table Rocket', color: '#a855f7', icon: Rocket, desc: 'Code simulation' },
  9: { name: 'Output Enhancer', color: '#c026d3', icon: Sparkles, desc: 'Response polish' },
  9.5: { name: 'KURO Drive', color: '#db2777', icon: HardDrive, desc: 'Neural ERP' },
  10: { name: 'Stream Controller', color: '#d946ef', icon: Activity, desc: 'SSE management' },
  10.5: { name: 'Feedback Loop', color: '#ec4899', icon: RotateCcw, desc: 'Learning' },
  11: { name: 'Mnemosyne Cache', color: '#f472b6', icon: Archive, desc: 'Memory store' },
  11.5: { name: 'Shadow VPN', color: '#22c55e', icon: Wifi, desc: 'Secure tunnel' },
};

const SKILL_ROUTING = {
  image: { primary: 'kuro-sentinel', fallback: 'kuro-core' },
  code: { primary: 'kuro-forge', fallback: 'kuro-cipher' },
  research: { primary: 'kuro-logic', fallback: 'kuro-phantom' },
  web: { primary: 'kuro-shopper', fallback: 'kuro-scout' },
  shopping: { primary: 'kuro-shopper', fallback: 'kuro-scout' },
  file: { primary: 'kuro-core', fallback: 'kuro-phantom' },
  fast: { primary: 'kuro-scout', fallback: 'kuro-shopper' },
  unrestricted: { primary: 'kuro-exe', fallback: 'kuro-core' },
};

const SKILLS = [
  { id: 'image', icon: Image, label: 'Vision', color: '#22c55e' },
  { id: 'code', icon: Code, label: 'Code', color: '#f97316' },
  { id: 'research', icon: Sparkles, label: 'Research', color: '#6366f1' },
  { id: 'web', icon: Globe, label: 'Web', color: '#06b6d4' },
  { id: 'shopping', icon: ShoppingBag, label: 'Shop', color: '#ec4899' },
  { id: 'file', icon: FileText, label: 'Files', color: '#3b82f6' },
  { id: 'fast', icon: Zap, label: 'Fast', color: '#eab308' },
  { id: 'unrestricted', icon: Shield, label: 'Exec', color: '#ef4444' },
];

const DEPTH_PROMPTS = {
  0: '',
  1: '\n\nProvide brief reasoning.',
  2: '\n\nThink step-by-step. Use <reasoning>...</reasoning> tags.',
  3: '\n\nEngage maximum depth. Use <think>...</think> then <reasoning>...</reasoning> tags.'
};

const sanitizeDisplayContent = (text) => {
  if (!text) return '';
  return text
    .replace(/\n\nProvide brief reasoning\.$/g, '')
    .replace(/\n\nThink step-by-step\. Use <reasoning>\.\.\.<\/reasoning> tags\.$/g, '')
    .replace(/\n\nEngage maximum depth\. Use <think>\.\.\.<\/think> then <reasoning>\.\.\.<\/reasoning> tags\.$/g, '')
    .trim();
};

// ═══════════════════════════════════════════════════════════════════════════
// UTILITIES
// ═══════════════════════════════════════════════════════════════════════════
const detectLang = (code) => {
  if (/^import .* from|^export |const .* = \(|=>/m.test(code)) return 'javascript';
  if (/^def |^class |^import |^from .* import/m.test(code)) return 'python';
  if (/<[a-z]+>|className=|style=/i.test(code)) return 'jsx';
  if (/^\s*[\{\[]|":\s*["\d\[\{]/m.test(code)) return 'json';
  return 'text';
};

const extractAllTags = (text, tag) => {
  if (!text) return { contents: [], remaining: text || '', hasOpen: false };
  const contents = [];
  let remaining = text;
  const regex = new RegExp(`<${tag}>([\\s\\S]*?)<\\/${tag}>`, 'gi');
  let match;
  while ((match = regex.exec(text)) !== null) contents.push(match[1].trim());
  remaining = remaining.replace(regex, '');
  const openTag = `<${tag}>`;
  const closeTag = `</${tag}>`;
  const lastOpen = remaining.lastIndexOf(openTag);
  let hasOpen = false;
  if (lastOpen !== -1 && remaining.indexOf(closeTag, lastOpen) === -1) {
    hasOpen = true;
    const streamContent = remaining.slice(lastOpen + openTag.length);
    if (streamContent) contents.push(streamContent);
    remaining = remaining.slice(0, lastOpen);
  }
  return { contents, remaining: remaining.trim(), hasOpen };
};

// ═══════════════════════════════════════════════════════════════════════════
// LAYER CARD STACK - GEMINI FLASH STYLE
// ═══════════════════════════════════════════════════════════════════════════
const LayerCardStack = ({ layers, activeLayer, streaming, onReset }) => {
  const [visibleCards, setVisibleCards] = useState([]);
  const [completedLayers, setCompletedLayers] = useState(new Set());
  const timeoutsRef = useRef([]);
  const processedRef = useRef(new Set());
  
  const clearAllTimeouts = useCallback(() => {
    timeoutsRef.current.forEach(t => clearTimeout(t));
    timeoutsRef.current = [];
  }, []);
  
  useEffect(() => {
    if (streaming && layers.length === 0) {
      clearAllTimeouts();
      setVisibleCards([]);
      setCompletedLayers(new Set());
      processedRef.current = new Set();
    }
  }, [streaming, layers.length, clearAllTimeouts]);
  
  useEffect(() => {
    layers.forEach(layerNum => {
      if (processedRef.current.has(layerNum)) return;
      processedRef.current.add(layerNum);
      
      const cfg = LAYER_CONFIG[layerNum];
      if (!cfg) return;
      
      const cardId = `${layerNum}-${Date.now()}`;
      
      // Flash In
      setVisibleCards(prev => [...prev, { id: cardId, layerNum, phase: 'enter' }]);
      
      // Visible
      const t1 = setTimeout(() => {
        setVisibleCards(prev => prev.map(c => c.id === cardId ? { ...c, phase: 'visible' } : c));
      }, 50);
      
      // Hold then Fade Out
      const t2 = setTimeout(() => {
        setVisibleCards(prev => prev.map(c => c.id === cardId ? { ...c, phase: 'exit' } : c));
        setCompletedLayers(prev => new Set([...prev, layerNum]));
      }, 2000);
      
      // Remove
      const t3 = setTimeout(() => {
        setVisibleCards(prev => prev.filter(c => c.id !== cardId));
      }, 2400);
      
      timeoutsRef.current.push(t1, t2, t3);
    });
  }, [layers]);
  
  useEffect(() => {
    if (activeLayer === null) return;
    const cfg = LAYER_CONFIG[activeLayer];
    if (!cfg || processedRef.current.has(activeLayer)) return;
    
    const cardId = `active-${activeLayer}`;
    const exists = visibleCards.some(c => c.id === cardId);
    if (!exists) {
      setVisibleCards(prev => [...prev, { id: cardId, layerNum: activeLayer, phase: 'enter', isActive: true }]);
      const t = setTimeout(() => {
        setVisibleCards(prev => prev.map(c => c.id === cardId ? { ...c, phase: 'visible' } : c));
      }, 50);
      timeoutsRef.current.push(t);
    }
  }, [activeLayer, visibleCards]);
  
  useEffect(() => {
    if (activeLayer === null) {
      setVisibleCards(prev => prev.filter(c => !c.isActive));
    }
  }, [activeLayer]);
  
  useEffect(() => () => clearAllTimeouts(), [clearAllTimeouts]);
  
  if (visibleCards.length === 0 && !streaming) return null;
  
  return (
    <div className="layer-card-stack">
      {visibleCards.map(card => {
        const cfg = LAYER_CONFIG[card.layerNum];
        if (!cfg) return null;
        const Icon = cfg.icon;
        return (
          <div key={card.id} className={`layer-card ${card.phase} ${card.isActive ? 'active' : ''}`}
            style={{ '--card-color': cfg.color }}>
            <div className="layer-card-dot" />
            <Icon size={12} />
            <span>{cfg.name}</span>
            {card.isActive && <span className="layer-card-pulse">...</span>}
            {!card.isActive && <Check size={12} className="layer-card-check" />}
          </div>
        );
      })}
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// ACTIVE PROTOCOL RAIL
// ═══════════════════════════════════════════════════════════════════════════
const ActiveProtocolRail = ({ settings, protocolsRan, streaming }) => {
  const activeProtocols = useMemo(() => {
    const active = [];
    if (settings.incubation) active.push({ id: 'incubation', label: 'Incubation', icon: FlaskConical, color: '#06b6d4', ran: protocolsRan.incubation });
    if (settings.redTeam) active.push({ id: 'redTeam', label: 'Red Team', icon: Target, color: '#ef4444', ran: protocolsRan.redTeam });
    if (settings.nuclearFusion) active.push({ id: 'nuclearFusion', label: 'Nuclear Fusion', icon: Atom, color: '#f97316', ran: protocolsRan.nuclearFusion });
    if (settings.nephilimGate) active.push({ id: 'nephilimGate', label: 'Nephilim', icon: Lock, color: '#dc2626', ran: protocolsRan.nephilimGate });
    if (settings.babylonProtocol) active.push({ id: 'babylonProtocol', label: 'Babylon', icon: AlertTriangle, color: '#ea580c', ran: protocolsRan.babylonProtocol });
    return active;
  }, [settings, protocolsRan]);
  
  if (activeProtocols.length === 0) return null;
  
  return (
    <div className="protocol-rail">
      {activeProtocols.map(p => {
        const Icon = p.icon;
        return (
          <div key={p.id} className={`protocol-pill ${p.ran ? 'ran' : ''} ${streaming ? 'streaming' : ''}`}
            style={{ '--pill-color': p.color }}>
            <Icon size={12} />
            <span>{p.label}</span>
            {p.ran && <Check size={10} className="pill-check" />}
            {streaming && !p.ran && <span className="pill-dot" />}
          </div>
        );
      })}
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// INDUSTRIAL COMPONENTS
// ═══════════════════════════════════════════════════════════════════════════
const VUMeter = ({ value = 0, max = 100, label, color = '#ef4444' }) => {
  const segments = 20;
  const activeCount = Math.round((value / max) * segments);
  return (
    <div className="vu-meter">
      {label && <span className="vu-label">{label}</span>}
      <div className="vu-track">
        {Array.from({ length: segments }).map((_, i) => (
          <div key={i} className={`vu-seg ${i < activeCount ? 'active' : ''}`} 
            style={{ '--seg-color': i > segments * 0.7 ? '#ef4444' : i > segments * 0.5 ? '#eab308' : color }} />
        ))}
      </div>
      <span className="vu-val">{value}</span>
    </div>
  );
};

const IndustrialSwitch = ({ on, onChange, label, icon: Icon, color = '#22c55e', disabled }) => (
  <button type="button" className={`ind-switch ${on ? 'on' : ''} ${disabled ? 'disabled' : ''}`} 
    style={{ '--sw-color': color }} onClick={() => !disabled && onChange?.(!on)}>
    <div className="sw-indicator"><div className="sw-light" /></div>
    {Icon && <Icon size={14} />}
    <span>{label}</span>
    <div className="sw-toggle"><div className="sw-thumb" /></div>
  </button>
);

const DepthSelector = ({ value, onChange }) => {
  const levels = [
    { val: 0, label: 'None', color: '#6b7280' },
    { val: 1, label: 'Light', color: '#22c55e' },
    { val: 2, label: 'Deep', color: '#3b82f6' },
    { val: 3, label: 'Max', color: '#ef4444' },
  ];
  return (
    <div className="depth-selector">
      {levels.map(l => (
        <button key={l.val} className={`depth-btn ${value === l.val ? 'active' : ''}`}
          style={{ '--d-color': l.color }} onClick={() => onChange(l.val)}>{l.label}</button>
      ))}
    </div>
  );
};

const CogPill = ({ type, content, isStreaming, defaultExpanded = true }) => {
  const [expanded, setExpanded] = useState(defaultExpanded);
  const ref = useRef(null);
  
  useEffect(() => {
    if (ref.current && isStreaming) ref.current.scrollTop = ref.current.scrollHeight;
  }, [content, isStreaming]);
  
  if (!content && !isStreaming) return null;
  
  const configs = {
    think: { icon: Brain, color: '#a855f7', title: 'Thinking', glyph: '◆' },
    reasoning: { icon: Lightbulb, color: '#22c55e', title: 'Reasoning', glyph: '◇' },
    incubation: { icon: FlaskConical, color: '#06b6d4', title: 'Incubation', glyph: '◈' },
    critique: { icon: Target, color: '#ef4444', title: 'Red Team', glyph: '◉' },
    fusion: { icon: Atom, color: '#f97316', title: 'Nuclear Fusion', glyph: '⊛' },
    plan: { icon: Database, color: '#f59e0b', title: 'Plan', glyph: '◎' },
    fireControl: { icon: Flame, color: '#f97316', title: 'Fire Control', glyph: '⊕' },
  };
  const cfg = configs[type] || configs.think;
  const Icon = cfg.icon;
  
  return (
    <div className="cog-pill" style={{ '--pill-color': cfg.color }}>
      <button className="pill-head" onClick={() => setExpanded(!expanded)}>
        <span className="pill-glyph">{cfg.glyph}</span>
        <Icon size={12} />
        <span>{cfg.title}</span>
        {isStreaming && <span className="pill-live">LIVE</span>}
        <ChevronDown size={12} className={`pill-chev ${expanded ? '' : 'collapsed'}`} />
      </button>
      {expanded && (
        <div className="pill-body" ref={ref}>
          {content}
          {isStreaming && <span className="stream-indicator">▊</span>}
        </div>
      )}
    </div>
  );
};

const FilePill = ({ file }) => {
  const [expanded, setExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const handleCopy = () => { navigator.clipboard.writeText(file.content); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  const handleDownload = () => {
    const blob = new Blob([file.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = file.name; a.click(); URL.revokeObjectURL(url);
  };
  return (
    <div className="file-pill">
      <button className="pill-head" onClick={() => setExpanded(!expanded)}>
        <FileCode size={14} /><span className="file-name">{file.name}</span>
        <div className="pill-actions">
          <button onClick={e => { e.stopPropagation(); handleCopy(); }}>{copied ? <CheckCircle size={12} /> : <Copy size={12} />}</button>
          <button onClick={e => { e.stopPropagation(); handleDownload(); }}><Download size={12} /></button>
        </div>
        <ChevronDown size={12} className={`pill-chev ${expanded ? '' : 'collapsed'}`} />
      </button>
      {expanded && <div className="pill-body code"><pre><code>{file.content}</code></pre></div>}
    </div>
  );
};

const CodePill = ({ code, language }) => {
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(true);
  const lang = language || detectLang(code);
  const colors = { javascript: '#f7df1e', python: '#3776ab', jsx: '#61dafb', json: '#888', text: '#888' };
  return (
    <div className="code-pill" style={{ '--code-color': colors[lang] || colors.text }}>
      <button className="pill-head" onClick={() => setExpanded(!expanded)}>
        <Code size={14} /><span className="lang-tag">{lang.toUpperCase()}</span>
        <button className="action-btn" onClick={e => { e.stopPropagation(); navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 2000); }}>
          {copied ? <CheckCircle size={12} /> : <Copy size={12} />}
        </button>
        <ChevronDown size={12} className={`pill-chev ${expanded ? '' : 'collapsed'}`} />
      </button>
      {expanded && <div className="pill-body code"><pre><code>{code}</code></pre></div>}
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// MESSAGE BUBBLE (PATCHED FOR CRASHES & CURSOR)
// ═══════════════════════════════════════════════════════════════════════════
const MessageBubble = ({ msg, isStreaming, settings, onArtifact }) => {
  const displayContent = msg.role === 'user' ? sanitizeDisplayContent(msg.content) : msg.content;
  let content = displayContent || '';
  
  const thinkData = extractAllTags(content, 'think'); content = thinkData.remaining;
  const reasonData = extractAllTags(content, 'reasoning'); content = reasonData.remaining;
  const planData = extractAllTags(content, 'plan'); content = planData.remaining;
  const incubData = extractAllTags(content, 'incubation'); content = incubData.remaining;
  const critData = extractAllTags(content, 'critique'); content = critData.remaining;
  const fusionData = extractAllTags(content, 'fusion'); content = fusionData.remaining;
  
  const thinkContent = thinkData.contents.join('\n\n');
  const reasonContent = reasonData.contents.join('\n\n');
  const planContent = planData.contents.join('\n\n');
  const incubationContent = incubData.contents.join('\n\n') || msg.protocols?.incubation || '';
  const critiqueContent = critData.contents.join('\n\n') || msg.protocols?.redTeam || '';
  const fusionContent = fusionData.contents.join('\n\n') || msg.protocols?.fusion || '';
  const fireControlContent = msg.protocols?.fireControl || '';
  
  const fileRegex = /<file\s+path=["']([^"']+)["'][^>]*>([\s\S]*?)<\/file>/gi;
  const files = []; let match;
  while ((match = fileRegex.exec(content)) !== null) files.push({ name: match[1].split('/').pop(), path: match[1], content: match[2].trim() });
  content = content.replace(fileRegex, '');
  
  const codeRegex = /```(\w+)?\n([\s\S]*?)```/g;
  const codeBlocks = [];
  while ((match = codeRegex.exec(content)) !== null) codeBlocks.push({ language: match[1] || 'text', code: match[2].trim() });
  content = content.replace(codeRegex, '');
  
  const isThinking = thinkData.hasOpen || reasonData.hasOpen || planData.hasOpen;
  
  return (
    <div className={`msg ${msg.role}`}>
      {msg.role === 'user' ? (
        <div className="msg-body">
          {msg.attachments?.length > 0 && (
            <div className="msg-attachments">
              {msg.attachments.map((a, i) => (
                <div key={i} className="attachment">
                  <img src={a.data || a.url} alt="attachment" />
                </div>
              ))}
            </div>
          )}
          {msg.skill && (
            <div className="skill-badge" style={{ '--skill-color': SKILLS.find(s => s.id === msg.skill)?.color || '#a855f7' }}>
              {msg.skill.toUpperCase()}
            </div>
          )}
          <span>{displayContent}</span>
        </div>
      ) : (
        <div className="msg-body">
          {settings?.showThinking && (thinkContent || isStreaming && thinkData.hasOpen) && (
            <CogPill type="think" content={thinkContent} isStreaming={isStreaming && thinkData.hasOpen} defaultExpanded={false} />
          )}
          {(reasonContent || isStreaming && reasonData.hasOpen) && (
            <CogPill type="reasoning" content={reasonContent} isStreaming={isStreaming && reasonData.hasOpen} />
          )}
          {planContent && <CogPill type="plan" content={planContent} />}
          {incubationContent && <CogPill type="incubation" content={incubationContent} />}
          {critiqueContent && <CogPill type="critique" content={critiqueContent} />}
          {fusionContent && <CogPill type="fusion" content={fusionContent} />}
          {fireControlContent && <CogPill type="fireControl" content={fireControlContent} />}
          {files.map((f, i) => <FilePill key={i} file={f} />)}
          {codeBlocks.map((b, i) => <CodePill key={i} code={b.code} language={b.language} />)}
          <div className="msg-main">
            {content.trim()}
            {/* Terminal cursor removed - visual feedback via Layer Cards */}
          </div>
          {!isStreaming && content.trim() && (
            <div className="msg-actions">
              <button onClick={() => navigator.clipboard.writeText(msg.content)}><Copy size={12} /><span>Copy</span></button>
              <button onClick={() => onArtifact?.(msg)}><Archive size={12} /><span>Artifact</span></button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// LAYER STACK
// ═══════════════════════════════════════════════════════════════════════════
const LayerStack = ({ layers, activeLayer, blocked }) => {
  if (blocked) return <div className="layer-blocked"><AlertTriangle size={14} /> Blocked by {blocked}</div>;
  const layerNums = Object.keys(LAYER_CONFIG).map(parseFloat).sort((a, b) => a - b);
  return (
    <div className="layer-stack">
      {layerNums.map(num => {
        const cfg = LAYER_CONFIG[num]; const Icon = cfg.icon;
        const isActive = activeLayer === num; const isComplete = layers.includes(num);
        return (
          <div key={num} className={`layer-row ${isActive ? 'active' : ''} ${isComplete ? 'complete' : ''}`} style={{ '--layer-color': cfg.color }}>
            <div className="layer-dot" /><Icon size={12} /><span className="layer-name">{cfg.name}</span>
            <span className="layer-stat">{isComplete ? <Check size={10} /> : isActive ? '...' : ''}</span>
          </div>
        );
      })}
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// NEURAL ENGINE PANEL
// ═══════════════════════════════════════════════════════════════════════════
const NeuralEnginePanel = ({ visible, onClose, settings, onChange, layers, activeLayer, blocked, currentModel, streaming }) => {
  const [tab, setTab] = useState('controls');
  if (!visible) return null;
  const modelData = MODEL_REGISTRY[currentModel] || MODEL_REGISTRY['kuro-core'];
  const ModelIcon = modelData.icon;
  
  return (
    <div className="neural-panel">
      <div className="panel-head"><Brain size={14} /><span>Neural Engine</span><button onClick={onClose}><X size={14} /></button></div>
      <div className="panel-tabs">
        <button className={tab === 'controls' ? 'active' : ''} onClick={() => setTab('controls')}><Settings size={12} /> Controls</button>
        <button className={tab === 'pipeline' ? 'active' : ''} onClick={() => setTab('pipeline')}><Layers size={12} /> Pipeline</button>
        <button className={tab === 'protocols' ? 'active' : ''} onClick={() => setTab('protocols')}><Shield size={12} /> Protocols</button>
      </div>
      <div className="panel-body">
        {tab === 'controls' && (
          <>
            <div className="panel-section">
              <div className="sec-label">DISPLAY</div>
              <IndustrialSwitch on={settings.showThinking} onChange={v => onChange({ ...settings, showThinking: v })} label="Thinking" icon={Brain} color="#a855f7" />
              <IndustrialSwitch on={settings.showLayers} onChange={v => onChange({ ...settings, showLayers: v })} label="Layers" icon={Layers} color="#22c55e" />
              <IndustrialSwitch on={settings.autoModel} onChange={v => onChange({ ...settings, autoModel: v })} label="Auto Model" icon={Cpu} color="#06b6d4" />
            </div>
            <div className="panel-section">
              <div className="sec-label">DEPTH</div>
              <DepthSelector value={settings.reasoningLevel} onChange={v => onChange({ ...settings, reasoningLevel: v })} />
            </div>
            <div className="panel-section">
              <div className="sec-label">VOLATILITY <span className="val">{settings.volatility}</span></div>
              <VUMeter value={settings.volatility} max={100} color="#f97316" />
              <input type="range" className="ind-slider" min={0} max={100} value={settings.volatility} onChange={e => onChange({ ...settings, volatility: parseInt(e.target.value) })} />
            </div>
          </>
        )}
        {tab === 'pipeline' && (
          <div className="panel-section">
            <LayerStack layers={layers} activeLayer={activeLayer} blocked={blocked} />
            <div className="active-brain"><ModelIcon size={16} style={{ color: modelData.color }} /><span>{modelData.name}</span>{streaming && <span className="brain-live">ACTIVE</span>}</div>
          </div>
        )}
        {tab === 'protocols' && (
          <>
            <div className="panel-section">
              <div className="sec-label">SECURITY</div>
              <IndustrialSwitch on={settings.nuclearFusion} onChange={v => onChange({ ...settings, nuclearFusion: v })} label="Nuclear Fusion" icon={Atom} color="#ef4444" />
              <IndustrialSwitch on={settings.redTeam} onChange={v => onChange({ ...settings, redTeam: v })} label="Red Team" icon={Target} color="#f97316" />
              <IndustrialSwitch on={settings.incubation} onChange={v => onChange({ ...settings, incubation: v })} label="Incubation" icon={FlaskConical} color="#06b6d4" />
            </div>
            <div className="panel-section">
              <div className="sec-label">SHADOW</div>
              <IndustrialSwitch on={settings.nephilimGate} onChange={v => onChange({ ...settings, nephilimGate: v })} label="Nephilim Gate" icon={Lock} color="#dc2626" />
              <IndustrialSwitch on={settings.babylonProtocol} onChange={v => onChange({ ...settings, babylonProtocol: v })} label="Babylon Protocol" icon={AlertTriangle} color="#ea580c" />
              <IndustrialSwitch on={settings.mnemosyneCache} onChange={v => onChange({ ...settings, mnemosyneCache: v })} label="Mnemosyne Cache" icon={Archive} color="#f472b6" />
            </div>
          </>
        )}
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// MODEL SELECTOR
// ═══════════════════════════════════════════════════════════════════════════
const ModelSelector = ({ visible, onClose, current, onSelect }) => {
  if (!visible) return null;
  const tiers = { sovereign: [], specialist: [], utility: [] };
  Object.entries(MODEL_REGISTRY).forEach(([id, m]) => tiers[m.tier]?.push({ id, ...m }));
  return (
    <div className="model-panel">
      <div className="panel-head"><Cpu size={14} /><span>Select Brain</span><button onClick={() => window.location.reload()}><RefreshCw size={14} /></button><button onClick={onClose}><X size={14} /></button></div>
      <div className="panel-body">
        <input type="text" className="search-input" placeholder="Search..." />
        {Object.entries(tiers).map(([tier, models]) => models.length > 0 && (
          <div key={tier} className="tier-group">
            <div className="tier-label">{tier.toUpperCase()}</div>
            {models.map(m => { const Icon = m.icon; return (
              <button key={m.id} className={`model-row ${current === m.id ? 'active' : ''}`} style={{ '--m-color': m.color }} onClick={() => { onSelect(m.id); onClose(); }}>
                <div className="model-icon"><Icon size={18} /></div>
                <div className="model-meta"><span className="model-name">{m.name}</span><span className="model-desc">{m.desc}</span></div>
                <span className="model-ctx">{m.ctx >= 32768 ? '32K' : m.ctx >= 16384 ? '16K' : '8K'}</span>
                {current === m.id && <Check size={14} />}
              </button>
            ); })}
          </div>
        ))}
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// SKILLS MENU
// ═══════════════════════════════════════════════════════════════════════════
const SkillsMenu = ({ visible, onClose, active, onSelect }) => {
  if (!visible) return null;
  return (
    <div className="skills-panel">
      <div className="panel-head"><Sparkles size={14} /><span>Skills</span><button onClick={onClose}><X size={14} /></button></div>
      <div className="skills-grid">
        {SKILLS.map(s => (
          <button key={s.id} className={`skill-btn ${active === s.id ? 'active' : ''}`} style={{ '--s-color': s.color }} onClick={() => { onSelect(active === s.id ? null : s.id); onClose(); }}>
            <s.icon size={20} /><span>{s.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// MAIN EXECUTIONER APP
// ═══════════════════════════════════════════════════════════════════════════
export default function PaxSilica() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [currentModel, setCurrentModel] = useState('kuro-core');
  const [activeSkill, setActiveSkill] = useState(null);
  const [attachments, setAttachments] = useState([]);
  const [layers, setLayers] = useState([]);
  const [activeLayer, setActiveLayer] = useState(null);
  const [blocked, setBlocked] = useState(null);
  const [sessionId] = useState(() => crypto.randomUUID());
  const [showSidebar, setShowSidebar] = useState(false);
  const [showPanel, setShowPanel] = useState(null);
  const [protocolsRan, setProtocolsRan] = useState({});
  const [settings, setSettings] = useState({
    showThinking: true,
    showLayers: true,
    autoModel: true,
    reasoningLevel: 2,
    volatility: 70,
    nuclearFusion: false,
    redTeam: false,
    incubation: false,
    nephilimGate: false,
    babylonProtocol: false,
    mnemosyneCache: false,
  });
  
  const messagesRef = useRef(null);
  const inputRef = useRef(null);
  const abortRef = useRef(null);

  useEffect(() => {
    if (messagesRef.current) messagesRef.current.scrollTop = messagesRef.current.scrollHeight;
  }, [messages]);

  useEffect(() => {
    if (settings.autoModel && activeSkill && SKILL_ROUTING[activeSkill]) {
      setCurrentModel(SKILL_ROUTING[activeSkill].primary);
    }
  }, [activeSkill, settings.autoModel]);

  const send = useCallback(async () => {
    const displayContent = input.trim();
    if (!displayContent && !attachments.length) return;
    
    // Store ONLY display content in state (no DEPTH_PROMPTS)
    const userMsg = { 
      role: 'user', 
      content: displayContent,  // Display content only
      skill: activeSkill, 
      attachments: attachments.length ? [...attachments] : undefined 
    };
    
    setMessages(m => [...m, userMsg]);
    setInput('');
    setAttachments([]);
    setStreaming(true);
    setLayers([]);
    setActiveLayer(null);
    setBlocked(null);
    setProtocolsRan({});
    
    const assistantMsg = { role: 'assistant', content: '', protocols: {} };
    setMessages(m => [...m, assistantMsg]);
    
    try {
      abortRef.current = new AbortController();
      const token = localStorage.getItem('kuro_token') || '';
      
      // Build API content at send-time (DEPTH_PROMPTS applied here only)
      const apiContent = displayContent + (settings.reasoningLevel > 0 ? DEPTH_PROMPTS[settings.reasoningLevel] : '');
      
      // Build messages for API with augmented content for current message
      const apiMessages = [...messages, { role: 'user', content: apiContent }]
        .map(m => ({ role: m.role, content: m.content }));
      
      const body = {
        messages: apiMessages,
        model: currentModel,
        skill: activeSkill,
        sessionId,
        clientType: 'executioner', // PAX SILICA - Full telemetry
        temperature: settings.volatility / 100,
        thinking: settings.showThinking,
        reasoning: settings.reasoningLevel > 0,
        incubation: settings.incubation,
        nuclearFusion: settings.nuclearFusion,
        redTeam: settings.redTeam,
        nephilimGate: settings.nephilimGate,
        babylonProtocol: settings.babylonProtocol,
        images: attachments.filter(a => a.type === 'image').map(a => a.data),
      };
      
      const response = await fetch('/api/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-KURO-Token': token },
        body: JSON.stringify(body),
        signal: abortRef.current.signal,
      });
      
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          try {
            const data = JSON.parse(line.slice(6));
            
            if (data.type === 'layer') {
              if (data.status === 'active') setActiveLayer(data.layer);
              else if (data.status === 'complete') {
                setLayers(l => [...l, data.layer]);
                setActiveLayer(null);
              }
            }
            else if (data.type === 'blocked') setBlocked(data.layer || 'Iron Dome');
            else if (data.type === 'model') setCurrentModel(data.model);
            else if (data.type === 'protocol') {
              setProtocolsRan(p => ({ ...p, [data.protocol]: true }));
              setMessages(m => {
                const updated = [...m];
                const last = updated[updated.length - 1];
                if (last?.role === 'assistant') {
                  last.protocols = { ...last.protocols, [data.protocol]: data.simulation || data.critique || data.result || '' };
                }
                return updated;
              });
            }
            else if (data.type === 'token') {
              setMessages(m => {
                const updated = [...m];
                const last = updated[updated.length - 1];
                if (last?.role === 'assistant') last.content = (last.content || '') + data.content;
                return updated;
              });
            }
            else if (data.type === 'error') {
              setMessages(m => {
                const updated = [...m];
                const last = updated[updated.length - 1];
                if (last?.role === 'assistant') last.content += `\n\n⚠️ Error: ${data.message}`;
                return updated;
              });
            }
          } catch {}
        }
      }
    } catch (e) {
      if (e.name !== 'AbortError') {
        setMessages(m => {
          const updated = [...m];
          const last = updated[updated.length - 1];
          if (last?.role === 'assistant') last.content += `\n\n⚠️ Connection error: ${e.message}`;
          return updated;
        });
      }
    }
    
    setStreaming(false);
    setActiveLayer(null);
  }, [input, attachments, messages, currentModel, activeSkill, sessionId, settings]);

  const stop = () => { abortRef.current?.abort(); setStreaming(false); };
  const handleKeyDown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };
  const handleFile = (e) => {
    const file = e.target.files?.[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setAttachments(a => [...a, { type: file.type.startsWith('image/') ? 'image' : 'file', name: file.name, data: reader.result }]);
    reader.readAsDataURL(file); e.target.value = '';
  };
  const removeAttachment = (i) => setAttachments(a => a.filter((_, idx) => idx !== i));
  const togglePanel = (name) => setShowPanel(showPanel === name ? null : name);
  
  const modelData = MODEL_REGISTRY[currentModel] || MODEL_REGISTRY['kuro-core'];
  const ModelIcon = modelData.icon;

  return (
    <div className="exe">
      {/* Sidebar */}
      {showSidebar && (
        <>
          <div className="overlay" onClick={() => setShowSidebar(false)} />
          <div className="sidebar">
            <div className="sidebar-head"><span>Conversations</span><button onClick={() => setShowSidebar(false)}><X size={16} /></button></div>
            <button className="new-btn" onClick={() => { setMessages([]); setShowSidebar(false); }}><Plus size={14} /> New Chat</button>
            <div className="conv-list"><div className="empty-conv">No conversations yet</div></div>
          </div>
        </>
      )}
      
      {/* Main Area */}
      <div className="main">
        {/* Toolbar */}
        <div className="toolbar">
          <button className="tb-btn" onClick={() => setShowSidebar(true)}><Menu size={18} /></button>
          <button className="model-badge" style={{ '--m-color': modelData.color }} onClick={() => togglePanel('model')}>
            <ModelIcon size={14} /><span>{modelData.name.split('::')[1]}</span>
          </button>
          <div className="tb-spacer" />
          <button className={`tb-btn ${showPanel === 'skills' ? 'active' : ''}`} onClick={() => togglePanel('skills')}><Sparkles size={18} /></button>
          <button className={`tb-btn ${showPanel === 'neural' ? 'active' : ''}`} onClick={() => togglePanel('neural')}><Brain size={18} /></button>
        </div>
        
        {/* Active Protocol Rail */}
        <ActiveProtocolRail settings={settings} protocolsRan={protocolsRan} streaming={streaming} />
        
        {/* Layer Card Stack */}
        {settings.showLayers && (
          <LayerCardStack layers={layers} activeLayer={activeLayer} streaming={streaming} />
        )}
        
        {/* Panels */}
        <NeuralEnginePanel visible={showPanel === 'neural'} onClose={() => setShowPanel(null)} settings={settings} onChange={setSettings}
          layers={layers} activeLayer={activeLayer} blocked={blocked} currentModel={currentModel} streaming={streaming} />
        <ModelSelector visible={showPanel === 'model'} onClose={() => setShowPanel(null)} current={currentModel} onSelect={setCurrentModel} />
        <SkillsMenu visible={showPanel === 'skills'} onClose={() => setShowPanel(null)} active={activeSkill} onSelect={setActiveSkill} />
        
        {/* Messages */}
        <div className="messages" ref={messagesRef}>
          {messages.length === 0 ? (
            <div className="empty">
              <div className="logo-box"><Database size={48} strokeWidth={1} /></div>
              <div className="title">PAX SILICA :: UNIFIED</div>
              <div className="hint">Sovereign Intelligence Platform</div>
            </div>
          ) : (
            messages.map((m, i) => (
              <MessageBubble key={i} msg={m} isStreaming={streaming && i === messages.length - 1 && m.role === 'assistant'} settings={settings} onArtifact={() => {}} />
            ))
          )}
        </div>
        
        {/* Input Area */}
        <div className="input-area">
          {activeSkill && (
            <div className="active-skill" style={{ '--skill-color': SKILLS.find(s => s.id === activeSkill)?.color || '#a855f7' }}>
              {(() => { const S = SKILLS.find(s => s.id === activeSkill); return S ? <S.icon size={12} /> : null; })()}
              <span>{activeSkill}</span><button onClick={() => setActiveSkill(null)}><X size={10} /></button>
            </div>
          )}
          {attachments.length > 0 && (
            <div className="attachments">
              {attachments.map((a, i) => (
                <div key={i} className="att-preview">
                  {a.type === 'image' ? <img src={a.data} alt="" /> : <FileText size={20} />}
                  <button onClick={() => removeAttachment(i)}><X size={10} /></button>
                </div>
              ))}
            </div>
          )}
          <div className="input-row">
            <label className="ctrl-btn"><input type="file" hidden onChange={handleFile} accept="image/*,.pdf,.txt,.md,.json" /><Image size={16} /></label>
            <textarea ref={inputRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKeyDown} placeholder="Enter directive..." rows={1} />
            {streaming ? (
              <button className="send-btn stop" onClick={stop}><Square size={16} /></button>
            ) : (
              <button className="send-btn" onClick={send} disabled={!input.trim() && !attachments.length}><Send size={16} /></button>
            )}
          </div>
        </div>
      </div>

      <style>{`
/* ═══════════════════════════════════════════════════════════════════════════
   KURO OS v8.5.1 - Patched
   ═══════════════════════════════════════════════════════════════════════════ */
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}
input,textarea{-webkit-user-select:text;user-select:text}

.exe{display:flex;height:100%;background:#000;color:rgba(240,238,235,0.92);font-family:-apple-system,BlinkMacSystemFont,'SF Pro',system-ui,sans-serif;position:relative;overflow:hidden;padding-top:env(safe-area-inset-top);padding-left:env(safe-area-inset-left);padding-right:env(safe-area-inset-right)}
.main{flex:1;display:flex;flex-direction:column;min-width:0}

/* Toolbar */
.toolbar{display:flex;align-items:center;gap:8px;padding:8px 12px;background:rgba(18,18,22,0.95);border-bottom:1px solid rgba(255,255,255,0.06)}
.tb-btn{padding:10px;border-radius:10px;background:transparent;border:none;color:rgba(255,255,255,0.5);cursor:pointer;min-width:44px;min-height:44px;display:flex;align-items:center;justify-content:center;transition:all .2s;touch-action:manipulation}
.tb-btn:hover,.tb-btn.active{background:rgba(168,85,247,0.15);color:#a855f7}
.tb-spacer{flex:1}
.model-badge{display:flex;align-items:center;gap:8px;padding:8px 14px;background:rgba(255,255,255,0.03);border:1px solid var(--m-color,rgba(255,255,255,0.1));border-radius:20px;color:var(--m-color,#a855f7);font-size:12px;font-weight:600;cursor:pointer;transition:all .2s;touch-action:manipulation}
.model-badge:hover{background:rgba(255,255,255,0.06)}

/* Protocol Rail */
.protocol-rail{display:flex;gap:8px;padding:6px 12px;background:rgba(12,12,16,0.8);border-bottom:1px solid rgba(255,255,255,0.04);overflow-x:auto;-webkit-overflow-scrolling:touch}
.protocol-pill{display:flex;align-items:center;gap:6px;padding:6px 12px;background:rgba(255,255,255,0.03);border:1px solid var(--pill-color,rgba(255,255,255,0.1));border-radius:16px;color:var(--pill-color);font-size:11px;font-weight:500;white-space:nowrap;transition:all .3s}
.protocol-pill.ran{background:rgba(34,197,94,0.1);border-color:rgba(34,197,94,0.3)}
.protocol-pill.streaming:not(.ran){animation:protocolPulse 1.5s ease-in-out infinite}
@keyframes protocolPulse{0%,100%{opacity:1;box-shadow:0 0 0 0 var(--pill-color)}50%{opacity:.8;box-shadow:0 0 8px 2px var(--pill-color)}}
.pill-check{color:#22c55e}
.pill-dot{width:6px;height:6px;background:var(--pill-color);border-radius:50%;animation:dotPulse 1s infinite}
@keyframes dotPulse{0%,100%{opacity:1}50%{opacity:.3}}

/* Layer Card Stack - Gemini Flash Style */
.layer-card-stack{display:flex;flex-wrap:wrap;gap:6px;padding:8px 12px;min-height:40px}
.layer-card{display:flex;align-items:center;gap:6px;padding:6px 10px;background:rgba(255,255,255,0.03);border:1px solid var(--card-color,rgba(255,255,255,0.1));border-radius:8px;color:var(--card-color);font-size:11px;font-weight:500;opacity:0;transform:translateY(-4px) scale(0.95);transition:all .3s cubic-bezier(.4,0,.2,1)}
.layer-card.enter{opacity:0;transform:translateY(-4px) scale(0.95)}
.layer-card.visible{opacity:1;transform:translateY(0) scale(1)}
.layer-card.exit{opacity:0;transform:translateY(4px) scale(0.95)}
.layer-card.active{border-style:dashed;animation:cardActive 1s ease-in-out infinite}
@keyframes cardActive{0%,100%{box-shadow:0 0 0 0 var(--card-color)}50%{box-shadow:0 0 12px 2px var(--card-color)}}
.layer-card-dot{width:6px;height:6px;border-radius:50%;background:var(--card-color)}
.layer-card-pulse{animation:pulseDots 1s infinite}
@keyframes pulseDots{0%{opacity:1}50%{opacity:.3}100%{opacity:1}}
.layer-card-check{color:#22c55e}

/* Panels */
.neural-panel,.model-panel,.skills-panel{position:absolute;top:56px;right:10px;width:320px;max-width:calc(100vw - 20px);background:rgba(12,12,16,0.98);border:1px solid rgba(255,255,255,0.08);border-radius:16px;z-index:100;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,0.8);animation:panelIn .25s cubic-bezier(.16,1,.3,1)}
@keyframes panelIn{from{opacity:0;transform:translateY(-8px) scale(.98)}to{opacity:1;transform:none}}
.panel-head{display:flex;align-items:center;gap:8px;padding:12px 14px;background:rgba(255,255,255,0.02);border-bottom:1px solid rgba(255,255,255,0.06);font-size:13px;font-weight:600}
.panel-head button{padding:8px;background:transparent;border:none;color:rgba(255,255,255,0.4);cursor:pointer;border-radius:8px;margin-left:auto;transition:all .15s;touch-action:manipulation}
.panel-head button:hover{background:rgba(255,255,255,0.08);color:#fff}
.panel-head button+button{margin-left:0}
.panel-tabs{display:flex;border-bottom:1px solid rgba(255,255,255,0.06)}
.panel-tabs button{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;padding:10px;background:transparent;border:none;color:rgba(255,255,255,0.4);font-size:11px;cursor:pointer;transition:all .15s;touch-action:manipulation}
.panel-tabs button.active{color:#a855f7;background:rgba(168,85,247,0.1);border-bottom:2px solid #a855f7}
.panel-body{max-height:calc(100vh - 200px);overflow-y:auto;-webkit-overflow-scrolling:touch}
.panel-section{padding:12px 14px;border-bottom:1px solid rgba(255,255,255,0.04)}
.panel-section:last-child{border-bottom:none}
.sec-label{display:flex;align-items:center;justify-content:space-between;font-size:10px;color:rgba(160,155,150,0.6);text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px}
.sec-label .val{color:#b794f6;font-weight:600}

/* Industrial Switch */
.ind-switch{display:flex;align-items:center;gap:10px;width:100%;padding:10px 12px;margin-bottom:6px;background:rgba(20,20,24,0.8);border:1px solid rgba(255,255,255,0.06);border-radius:8px;color:rgba(200,195,190,0.75);font-size:12px;cursor:pointer;transition:all .2s;touch-action:manipulation}
.ind-switch:active{transform:scale(0.98)}
.ind-switch.disabled{opacity:.4;cursor:not-allowed}
.ind-switch span{flex:1;text-align:left}
.sw-indicator{width:8px;height:8px;border-radius:50%;background:#333;box-shadow:inset 0 1px 2px rgba(0,0,0,0.5)}
.sw-light{width:100%;height:100%;border-radius:50%;transition:all .3s}
.ind-switch.on .sw-light{background:var(--sw-color);box-shadow:0 0 8px var(--sw-color)}
.sw-toggle{width:36px;height:20px;background:rgba(255,255,255,0.1);border-radius:10px;position:relative;transition:all .3s}
.ind-switch.on .sw-toggle{background:var(--sw-color)}
.sw-thumb{position:absolute;top:2px;left:2px;width:16px;height:16px;background:#fff;border-radius:50%;box-shadow:0 1px 3px rgba(0,0,0,0.3);transition:transform .25s cubic-bezier(.34,1.56,.64,1)}
.ind-switch.on .sw-thumb{transform:translateX(16px)}

/* Depth Selector */
.depth-selector{display:flex;gap:4px}
.depth-btn{flex:1;padding:10px 8px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);border-radius:8px;color:rgba(200,195,190,0.6);font-size:11px;font-weight:500;cursor:pointer;transition:all .2s;touch-action:manipulation}
.depth-btn:active{transform:scale(0.96)}
.depth-btn.active{background:var(--d-color);color:#000;border-color:var(--d-color);font-weight:700}

/* VU Meter */
.vu-meter{display:flex;align-items:center;gap:8px;margin-bottom:8px}
.vu-label{font-size:10px;color:rgba(160,155,150,0.6);width:60px}
.vu-track{display:flex;gap:2px;flex:1}
.vu-seg{width:100%;height:12px;background:rgba(255,255,255,0.08);border-radius:1px;transition:all .1s}
.vu-seg.active{background:var(--seg-color);box-shadow:0 0 4px var(--seg-color)}
.vu-val{font-size:11px;color:rgba(200,195,190,0.75);width:30px;text-align:right}

/* Industrial Slider */
.ind-slider{width:100%;height:6px;-webkit-appearance:none;background:rgba(255,255,255,0.1);border-radius:3px;outline:none}
.ind-slider::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;background:linear-gradient(135deg,#fff,#ccc);border-radius:50%;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.4);transition:transform .15s}
.ind-slider::-webkit-slider-thumb:active{transform:scale(1.1)}

/* Layer Stack (panel) */
.layer-stack{display:flex;flex-direction:column;gap:2px;max-height:300px;overflow-y:auto}
.layer-row{display:flex;align-items:center;gap:6px;padding:6px 8px;border-radius:6px;font-size:10px;transition:all .2s}
.layer-row.active{background:rgba(255,255,255,0.05)}
.layer-dot{width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,0.2);transition:all .3s}
.layer-row.active .layer-dot{background:var(--layer-color);box-shadow:0 0 8px var(--layer-color);animation:layerPulse 1s infinite}
.layer-row.complete .layer-dot{background:var(--layer-color)}
@keyframes layerPulse{0%,100%{opacity:1}50%{opacity:.5}}
.layer-name{flex:1;color:rgba(200,195,190,0.7)}
.layer-stat{color:rgba(160,155,150,0.5)}
.layer-blocked{background:rgba(239,68,68,0.1);color:#ef4444;display:flex;align-items:center;gap:8px;padding:10px;border-radius:8px;font-size:12px}
.active-brain{display:flex;align-items:center;gap:8px;padding:10px;margin-top:10px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);border-radius:8px;font-size:12px}
.brain-live{padding:2px 6px;background:#22c55e;color:#000;border-radius:4px;font-size:9px;font-weight:700;animation:livePulse 1.5s ease-in-out infinite}
@keyframes livePulse{0%,100%{opacity:1}50%{opacity:.6}}

/* Model Selector */
.search-input{width:calc(100% - 24px);margin:12px;padding:10px 12px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:10px;color:#fff;font-size:13px;outline:none}
.search-input:focus{border-color:rgba(168,85,247,0.5)}
.tier-group{padding:0 12px 12px}
.tier-label{font-size:10px;color:rgba(160,155,150,0.5);text-transform:uppercase;letter-spacing:.5px;margin:8px 0}
.model-row{display:flex;align-items:center;gap:10px;width:100%;padding:10px;margin:4px 0;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);border-radius:10px;cursor:pointer;transition:all .2s;touch-action:manipulation}
.model-row:active{transform:scale(0.98)}
.model-row:hover{background:rgba(255,255,255,0.05)}
.model-row.active{background:rgba(168,85,247,0.1);border-color:var(--m-color)}
.model-icon{width:32px;height:32px;border-radius:8px;background:rgba(255,255,255,0.05);display:flex;align-items:center;justify-content:center;color:var(--m-color)}
.model-meta{flex:1;text-align:left}
.model-name{display:block;font-size:12px;font-weight:600;color:#fff}
.model-desc{display:block;font-size:10px;color:rgba(160,155,150,0.6)}
.model-ctx{font-size:10px;color:rgba(160,155,150,0.5);padding:2px 6px;background:rgba(255,255,255,0.05);border-radius:4px}

/* Skills Grid */
.skills-panel{width:280px}
.skills-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:12px}
.skill-btn{display:flex;flex-direction:column;align-items:center;gap:6px;padding:12px 6px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.05);border-radius:10px;color:rgba(200,195,190,0.7);font-size:10px;cursor:pointer;transition:all .2s;touch-action:manipulation}
.skill-btn:active{transform:scale(0.95)}
.skill-btn:hover{background:rgba(255,255,255,0.05);color:var(--s-color);border-color:var(--s-color)}
.skill-btn.active{background:rgba(168,85,247,0.15);border-color:var(--s-color);color:var(--s-color)}

/* Messages */
.messages{flex:1;overflow-y:auto;padding:16px;-webkit-overflow-scrolling:touch}
.empty{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;text-align:center;color:rgba(160,155,150,0.6)}
.logo-box{width:80px;height:80px;border:1px solid rgba(168,85,247,0.3);border-radius:16px;display:flex;align-items:center;justify-content:center;color:#a855f7;margin-bottom:16px;animation:logoPulse 3s ease-in-out infinite}
@keyframes logoPulse{0%,100%{box-shadow:0 0 20px rgba(168,85,247,0.2)}50%{box-shadow:0 0 40px rgba(168,85,247,0.4)}}
.empty .title{font-size:14px;font-weight:600;letter-spacing:2px;color:rgba(200,195,190,0.8)}
.empty .hint{font-size:12px;margin-top:4px}

.msg{margin-bottom:14px;animation:msgIn .3s cubic-bezier(.16,1,.3,1)}
@keyframes msgIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.msg.user .msg-body{background:rgba(139,92,246,0.15);border:1px solid rgba(139,92,246,0.25);border-radius:16px 16px 4px 16px;padding:12px 14px;margin-left:40px}
.msg.assistant .msg-body{background:rgba(30,30,38,0.8);border:1px solid rgba(255,255,255,0.06);border-radius:16px 16px 16px 4px;padding:12px 14px;margin-right:40px}
.msg-main{white-space:pre-wrap;line-height:1.6;font-size:14px}
.msg-attachments{display:flex;gap:8px;margin-bottom:8px}
.msg-attachments .attachment{width:60px;height:60px;border-radius:8px;overflow:hidden}
.msg-attachments img{width:100%;height:100%;object-fit:cover}
.skill-badge{display:inline-block;padding:4px 8px;margin-bottom:6px;border:1px solid var(--skill-color);border-radius:10px;font-size:10px;font-weight:600;color:var(--skill-color);text-transform:uppercase}

/* Cog Pills */
.cog-pill{margin-bottom:10px;background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06);border-left:3px solid var(--pill-color);border-radius:8px;overflow:hidden}
.pill-head{display:flex;align-items:center;gap:6px;width:100%;padding:8px 12px;background:transparent;border:none;color:var(--pill-color);font-size:11px;font-weight:500;cursor:pointer;text-align:left;transition:all .15s;touch-action:manipulation}
.pill-head:hover{background:rgba(255,255,255,0.02)}
.pill-glyph{font-size:10px;opacity:.7}
.pill-head>span{flex:1}
.pill-live{padding:2px 6px;background:var(--pill-color);color:#000;border-radius:4px;font-size:8px;font-weight:700;animation:livePulse 1.5s ease-in-out infinite}
.pill-chev{transition:transform .2s;color:rgba(255,255,255,0.3)}
.pill-chev.collapsed{transform:rotate(-90deg)}
.pill-body{padding:10px 12px;border-top:1px solid rgba(255,255,255,0.05);font-size:12px;line-height:1.6;max-height:250px;overflow-y:auto;color:rgba(200,195,190,0.85);white-space:pre-wrap}
.pill-body.code{background:rgba(0,0,0,0.3);font-family:'SF Mono',Monaco,Consolas,monospace;font-size:11px}
.pill-body pre{margin:0;white-space:pre-wrap}

/* File & Code Pills */
.file-pill,.code-pill{margin-bottom:10px;background:rgba(168,85,247,0.04);border:1px solid rgba(168,85,247,0.15);border-radius:8px;overflow:hidden}
.file-pill .pill-head,.code-pill .pill-head{color:#c084fc}
.pill-actions{display:flex;align-items:center;gap:4px}
.pill-actions button,.action-btn{padding:6px;background:transparent;border:none;color:inherit;cursor:pointer;opacity:.6;border-radius:6px;transition:all .15s;touch-action:manipulation}
.pill-actions button:hover,.action-btn:hover{opacity:1;background:rgba(255,255,255,0.08)}
.lang-tag{padding:2px 6px;background:rgba(255,255,255,0.08);border-radius:4px;font-size:9px;font-weight:600;color:var(--code-color)}
.file-name{flex:1;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* Message Actions */
.msg-actions{display:flex;gap:6px;margin-top:10px;padding-top:10px;border-top:1px solid rgba(255,255,255,0.05)}
.msg-actions button{display:flex;align-items:center;gap:4px;padding:6px 10px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);border-radius:6px;color:rgba(160,155,150,0.6);font-size:10px;cursor:pointer;transition:all .15s;touch-action:manipulation}
.msg-actions button:hover{background:rgba(255,255,255,0.06);color:#fff}

/* Input Area */
.input-area{padding:12px 14px;padding-bottom:max(12px,env(safe-area-inset-bottom));background:rgba(18,18,22,0.95);border-top:1px solid rgba(255,255,255,0.06)}
.active-skill{display:inline-flex;align-items:center;gap:6px;padding:6px 10px;margin-bottom:8px;border:1px solid var(--skill-color);border-radius:10px;color:var(--skill-color);font-size:10px;font-weight:500;text-transform:uppercase}
.active-skill button{padding:2px;background:transparent;border:none;color:inherit;cursor:pointer;touch-action:manipulation}
.attachments{display:flex;gap:8px;margin-bottom:8px}
.att-preview{position:relative;width:56px;height:56px;border-radius:8px;overflow:hidden;background:rgba(255,255,255,0.05)}
.att-preview img{width:100%;height:100%;object-fit:cover}
.att-preview button{position:absolute;top:2px;right:2px;padding:4px;background:rgba(0,0,0,0.7);border:none;border-radius:50%;color:#fff;cursor:pointer;touch-action:manipulation}
.input-row{display:flex;align-items:flex-end;gap:8px}
.ctrl-btn{padding:12px;border-radius:12px;background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);color:rgba(160,155,150,0.6);cursor:pointer;transition:all .2s;touch-action:manipulation}
.ctrl-btn:hover{background:rgba(168,85,247,0.15);color:#b794f6;border-color:rgba(168,85,247,0.3)}
.ctrl-btn input{display:none}
.input-row textarea{flex:1;padding:12px 14px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:18px;color:#fff;font-size:14px;resize:none;outline:none;max-height:120px;transition:all .2s}
.input-row textarea:focus{border-color:rgba(168,85,247,0.5);background:rgba(255,255,255,0.05)}
.input-row textarea::placeholder{color:rgba(160,155,150,0.5)}
.send-btn{padding:12px;background:linear-gradient(135deg,#a855f7,#6366f1);border:none;border-radius:50%;color:#fff;cursor:pointer;transition:all .2s;touch-action:manipulation}
.send-btn:hover:not(:disabled){transform:scale(1.05);box-shadow:0 0 20px rgba(168,85,247,0.4)}
.send-btn:active{transform:scale(.95)}
.send-btn:disabled{opacity:.4;cursor:not-allowed}
.send-btn.stop{background:#ef4444}

/* Sidebar */
.overlay{position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:200;animation:fadeIn .2s}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
.sidebar{position:fixed;top:0;left:0;bottom:0;width:280px;background:rgba(12,12,16,0.98);border-right:1px solid rgba(255,255,255,0.08);z-index:201;display:flex;flex-direction:column;animation:slideIn .25s cubic-bezier(.16,1,.3,1)}
@keyframes slideIn{from{transform:translateX(-100%)}to{transform:none}}
.sidebar-head{display:flex;align-items:center;justify-content:space-between;padding:16px;font-size:14px;font-weight:600;border-bottom:1px solid rgba(255,255,255,0.06)}
.sidebar-head button{padding:8px;background:transparent;border:none;color:rgba(255,255,255,0.5);cursor:pointer;touch-action:manipulation}
.new-btn{display:flex;align-items:center;justify-content:center;gap:8px;margin:12px;padding:12px;background:rgba(168,85,247,0.15);border:1px solid rgba(168,85,247,0.3);border-radius:10px;color:#b794f6;font-size:13px;font-weight:500;cursor:pointer;transition:all .2s;touch-action:manipulation}
.new-btn:hover{background:rgba(168,85,247,0.25)}
.conv-list{flex:1;overflow-y:auto;padding:8px}
.empty-conv{padding:20px;text-align:center;color:rgba(160,155,150,0.5);font-size:12px}

/* Responsive */
@media(max-width:600px){
  .neural-panel,.model-panel,.skills-panel{right:8px;left:8px;width:auto;max-width:none}
  .msg.user .msg-body,.msg.assistant .msg-body{margin-left:0;margin-right:0}
  .skills-grid{grid-template-columns:repeat(4,1fr)}
}
@media(prefers-reduced-motion:reduce){
  *,.neural-panel,.model-panel,.skills-panel,.msg,.cog-pill,.layer-card{animation:none !important;transition-duration:.01ms !important}
  .stream-indicator,.pill-live,.brain-live,.layer-dot,.pill-dot{animation:none}
}
      `}</style>
    </div>
  );
}
